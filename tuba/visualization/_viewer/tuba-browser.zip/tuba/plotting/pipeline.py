"""
tuba.plotting.pipeline — Core visualization pipeline.

Converts Tuba model data and FEA results into PyVista meshes
for rendering. Handles:
  - Loading .rmed files via meshio
  - Building line meshes directly from TubaModel geometry
  - Inflating 1D lines into 3D tubes
  - Mapping scalar fields to tube surfaces
"""

from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
from typing import TYPE_CHECKING, Optional

import numpy as np

from tuba.geometry.section_mesh import beam_local_frame, section_loops, straight_section_surface_mesh

if TYPE_CHECKING:
    from tuba.model import TubaModel
    from tuba.solver.base import FEAResults

try:
    import pyvista as pv

    _HAS_PYVISTA = True
except ImportError:
    _HAS_PYVISTA = False

try:
    import meshio

    _HAS_MESHIO = True
except ImportError:
    _HAS_MESHIO = False


def _require_pyvista():
    if not _HAS_PYVISTA:
        raise ImportError(
            "PyVista is required for visualization. "
            "Install it with: pip install 'tuba[viz]'"
        )


# ---------------------------------------------------------------------------
# Loading .rmed results
# ---------------------------------------------------------------------------


def load_rmed(path: str) -> "pv.UnstructuredGrid":
    """Read a Code_Aster ``.rmed`` result file and return a PyVista mesh.

    Uses *meshio* to parse the MED format, then converts to a PyVista
    :class:`~pyvista.UnstructuredGrid`.  All point and cell data arrays
    present in the file are preserved.
    """
    _require_pyvista()
    if not _HAS_MESHIO:
        raise ImportError("meshio is required to read .rmed files: pip install meshio")

    try:
        mesh_io = meshio.read(str(path), file_format="med")
    except (KeyError, TypeError):
        # Code_Aster pipe studies can contain section-point ELGA supports such
        # as ``SP_PIPE SE3`` and fields present on only one MED cell block.
        # meshio 5.3 cannot represent either case.  Read the same MED datasets
        # while retaining every supported nodal/ELNO array and deliberately
        # skipping only unsupported integration-point supports.
        mesh_io = _read_code_aster_med_fields(path)

    points = mesh_io.points
    if points.shape[1] == 2:
        points = np.column_stack([points, np.zeros(len(points))])

    cells, cell_types, supported_blocks = [], [], []
    vtk_cell_types = {
        "line": 3,       # VTK_LINE
        "line3": 21,     # VTK_QUADRATIC_EDGE
        "triangle": 5,
        "quad": 9,
    }
    for block_index, cell_block in enumerate(mesh_io.cells):
        ct = cell_block.type
        data = cell_block.data
        vtk_type = vtk_cell_types.get(ct)
        if vtk_type is None:
            continue  # skip unsupported
        supported_blocks.append((block_index, cell_block))
        for conn in data:
            cells.append(np.concatenate([[len(conn)], conn]))
            cell_types.append(vtk_type)

    if not cells:
        raise ValueError(f"RMED mesh {path!r} does not contain supported cells for visualization.")

    cells_arr = np.concatenate(cells)
    grid = pv.UnstructuredGrid(cells_arr, np.array(cell_types), points)

    # Transfer point data
    for name, arr in mesh_io.point_data.items():
        grid.point_data[name] = arr

    # Transfer cell data
    for name, blocks in mesh_io.cell_data.items():
        selected = [
            np.asarray(blocks[index])
            for index, _block in supported_blocks
            if blocks[index] is not None
        ]
        if not selected:
            continue
        if any(array.shape[1:] != selected[0].shape[1:] for array in selected[1:]):
            # Mixed MED element families can expose different ELNO/Gauss
            # cardinalities.  Such arrays cannot be represented as one VTK
            # cell field without discarding their element-local meaning.
            continue
        combined = np.concatenate(selected)
        if len(combined) == grid.n_cells:
            grid.cell_data[name] = combined.reshape(len(combined), -1)

    displacement = _latest_result_array(mesh_io.point_data, "DEPL")
    if displacement is not None and displacement.ndim == 2 and displacement.shape[1] >= 3:
        grid.point_data["DEPL"] = displacement[:, :3]
        grid.point_data["DEPL_magnitude"] = np.linalg.norm(displacement[:, :3], axis=1)

    stress_blocks = _latest_result_array(mesh_io.cell_data, "SIEQ")
    if stress_blocks is not None:
        point_stress = np.full(len(points), np.nan)
        for (block_index, cell_block) in supported_blocks:
            if stress_blocks[block_index] is None:
                continue
            block = np.asarray(stress_blocks[block_index])
            if block.ndim < 3:
                continue
            for connection, values in zip(cell_block.data, block[:, :, 0]):
                for point_index, value in zip(connection, values):
                    current = point_stress[point_index]
                    point_stress[point_index] = value if np.isnan(current) else max(current, value)
        if np.isfinite(point_stress).any():
            grid.point_data["VMIS"] = point_stress

    return grid


def _read_code_aster_med_fields(path: str):
    """Read supported MED geometry/results when meshio rejects Aster supports.

    This compatibility reader intentionally uses meshio's MED value decoders,
    so profiles and Fortran-order result arrays retain their established
    semantics.  Unsupported Code_Aster integration-point supports are omitted;
    no substitute or zero-valued solver data is created.
    """
    import h5py
    from meshio.med import _med

    with h5py.File(path, "r") as med_file:
        meshes = med_file["ENS_MAA"]
        if len(meshes) != 1:
            raise ValueError(f"RMED must contain exactly one mesh, found {len(meshes)}.")
        mesh = meshes[next(iter(meshes))]
        dimension = mesh.attrs["ESP"]
        if "NOE" not in mesh:
            if len(mesh) != 1:
                raise ValueError(f"RMED mesh must contain exactly one time step, found {len(mesh)}.")
            mesh = mesh[next(iter(mesh))]

        coordinates = mesh["NOE"]["COO"]
        point_count = coordinates.attrs["NBR"]
        points = coordinates[()].reshape((point_count, dimension), order="F")

        cells = []
        cell_types = []
        cell_data = {}
        for med_type, cell_group in mesh["MAI"].items():
            cell_type = _med.med_to_meshio_type[med_type]
            connectivity = cell_group["NOD"]
            cell_count = connectivity.attrs["NBR"]
            cells.append(
                meshio.CellBlock(
                    cell_type,
                    connectivity[()].reshape(cell_count, -1, order="F") - 1,
                )
            )
            cell_types.append(cell_type)
            if "FAM" in cell_group:
                cell_data.setdefault("cell_tags", []).append(cell_group["FAM"][()])

        point_data = {}
        if "FAM" in mesh["NOE"]:
            point_data["point_tags"] = mesh["NOE"]["FAM"][()]

        profiles = med_file["PROFILS"] if "PROFILS" in med_file else None
        for field_name, field in med_file.get("CHA", {}).items():
            steps = sorted(field.keys())
            names = [field_name]
            if len(steps) > 1:
                names = [
                    f"{field_name}[{index}] - {field[step].attrs['PDT']:g}"
                    for index, step in enumerate(steps)
                ]
            for name, step in zip(names, steps):
                med_data = field[step]
                for support in med_data:
                    if support == "NOE":
                        point_data[name] = _med._read_nodal_data(med_data, profiles)
                        continue
                    med_cell_type = support.partition(".")[2]
                    cell_type = _med.med_to_meshio_type.get(med_cell_type)
                    if cell_type not in cell_types:
                        continue
                    values = cell_data.setdefault(name, [None] * len(cell_types))
                    values[cell_types.index(cell_type)] = _med._read_cell_data(
                        med_data[support], profiles
                    )

    return SimpleNamespace(
        points=points,
        cells=cells,
        point_data=point_data,
        cell_data=cell_data,
    )


def _latest_result_array(data: dict, field: str):
    matches = [(name, value) for name, value in data.items() if field in name.upper()]
    if not matches:
        return None

    def step(item):
        name = item[0]
        try:
            return int(name.rsplit("[", 1)[1].split("]", 1)[0])
        except (IndexError, ValueError):
            return -1

    return max(matches, key=step)[1]


# ---------------------------------------------------------------------------
# Build mesh from TubaModel + FEAResults
# ---------------------------------------------------------------------------


def _get_bend_points(model: "TubaModel", elem: "Element", n_segments: int = 16) -> np.ndarray:
    """Calculate intermediate coordinates along the 3D circular bend arc."""
    p1 = model.nodes[elem.n1].coords
    if elem.bend_geometry is None:
        raise ValueError(f"Cannot visualize pipe bend {elem.id!r} without explicit bend_geometry.")
    from tuba.model import sample_bend_geometry

    return sample_bend_geometry(p1, elem.bend_geometry, n_segments=n_segments)


def build_mesh_from_model(
    model: "TubaModel",
    results: Optional["FEAResults"] = None,
) -> "pv.PolyData":
    """Construct a PyVista **line** mesh (centreline) from a :class:`TubaModel`.

    This is the "mesh mode" view: the raw centreline with curved bends and no
    section thickness. Its counterpart is :func:`build_3d_mesh_from_model`,
    which extrudes each element's true section profile ("geometry mode"). Both
    are public entry points — pick mesh mode for a fast schematic, geometry
    mode to see real pipe/beam shapes.
    """
    _require_pyvista()

    # Pre-populate points list with basic nodes
    node_ids = list(model.nodes.keys())
    points_list = [model.nodes[nid].coords for nid in node_ids]
    
    # Store indices for basic nodes
    node_idx = {nid: i for i, nid in enumerate(node_ids)}
    
    # Results data lists
    disp_list = []
    vmis_list = []
    forc_list = []
    
    if results is not None:
        for nid in node_ids:
            nr = results.node_results.get(nid)
            disp_list.append(nr.displacement[:3] if nr is not None else np.zeros(3))
            
            # Average Von Mises for this node
            v_val = 0.0
            v_cnt = 0
            for elem in model.elements:
                er = results.element_results.get(elem.id)
                if er is not None:
                    if elem.n1 == nid:
                        v_val += er.von_mises_n1
                        v_cnt += 1
                    elif elem.n2 == nid:
                        v_val += er.von_mises_n2
                        v_cnt += 1
            vmis_list.append(v_val / max(v_cnt, 1))
            
            forc_list.append(nr.reaction_force[:3] if (nr is not None and nr.reaction_force is not None) else np.zeros(3))

    all_edges = []
    
    for elem in model.elements:
        if elem.type == "pipe_bend" and elem.bend_radius:
            # Generate curved points
            n_segs = 16
            arc_pts = _get_bend_points(model, elem, n_segments=n_segs)
            
            pts_idxs = [node_idx[elem.n1]]
            for i in range(1, n_segs):
                pts_idxs.append(len(points_list))
                points_list.append(arc_pts[i])
                
                # Interpolate results for intermediate points
                if results is not None:
                    t = i / n_segs
                    nr1 = results.node_results.get(elem.n1)
                    nr2 = results.node_results.get(elem.n2)
                    d1 = nr1.displacement[:3] if nr1 is not None else np.zeros(3)
                    d2 = nr2.displacement[:3] if nr2 is not None else np.zeros(3)
                    disp_list.append(d1 + t * (d2 - d1))
                    
                    er = results.element_results.get(elem.id)
                    if er is not None:
                        vmis_list.append(er.von_mises_n1 + t * (er.von_mises_n2 - er.von_mises_n1))
                    else:
                        vmis_list.append(0.0)
                        
                    forc_list.append(np.zeros(3))
                    
            pts_idxs.append(node_idx[elem.n2])
            
            for idx in range(n_segs):
                all_edges.append((pts_idxs[idx], pts_idxs[idx+1]))
        else:
            # Straight elements
            i1 = node_idx[elem.n1]
            i2 = node_idx[elem.n2]
            all_edges.append((i1, i2))

    # Group edges into continuous polylines
    n_pts = len(points_list)
    adj = {i: set() for i in range(n_pts)}
    for u, v in all_edges:
        adj[u].add(v)
        adj[v].add(u)

    degrees = {i: len(neighbors) for i, neighbors in adj.items()}
    visited_edges = set()
    polylines = []

    # 1. Start from endpoints or junctions (degree != 2)
    start_nodes = [i for i, deg in degrees.items() if deg != 2 and deg > 0]
    for u in start_nodes:
        for v in list(adj[u]):
            edge = tuple(sorted((u, v)))
            if edge not in visited_edges:
                poly = [u, v]
                visited_edges.add(edge)
                curr = v
                prev = u
                while degrees[curr] == 2:
                    neighbors = list(adj[curr] - {prev})
                    if not neighbors:
                        break
                    next_node = neighbors[0]
                    next_edge = tuple(sorted((curr, next_node)))
                    if next_edge in visited_edges:
                        break
                    poly.append(next_node)
                    visited_edges.add(next_edge)
                    prev = curr
                    curr = next_node
                polylines.append(poly)

    # 2. Start from any remaining unvisited edges (closed loops)
    for u in range(n_pts):
        for v in list(adj[u]):
            edge = tuple(sorted((u, v)))
            if edge not in visited_edges:
                poly = [u, v]
                visited_edges.add(edge)
                curr = v
                prev = u
                while True:
                    neighbors = list(adj[curr] - {prev})
                    if not neighbors:
                        break
                    next_node = neighbors[0]
                    next_edge = tuple(sorted((curr, next_node)))
                    if next_edge in visited_edges:
                        break
                    poly.append(next_node)
                    visited_edges.add(next_edge)
                    prev = curr
                    curr = next_node
                polylines.append(poly)

    # Build the PyVista lines cell array
    lines = []
    for poly in polylines:
        lines.append(len(poly))
        lines.extend(poly)

    points_arr = np.array(points_list)
    mesh = pv.PolyData(points_arr, lines=np.array(lines))

    if results is not None:
        mesh.point_data["DEPL"] = np.array(disp_list)
        mesh.point_data["DEPL_magnitude"] = np.linalg.norm(mesh.point_data["DEPL"], axis=1)
        mesh.point_data["VMIS"] = np.array(vmis_list)
        mesh.point_data["FORC_NODA"] = np.array(forc_list)
        mesh.point_data["FORC_magnitude"] = np.linalg.norm(mesh.point_data["FORC_NODA"], axis=1)

    return mesh


# ---------------------------------------------------------------------------
# True 3D Cross-Sectional Geometry Extrusion
# ---------------------------------------------------------------------------


def _get_profile_2d_loops(sec, n_sides: int = 16) -> list[np.ndarray]:
    """Return section profile loops; inner loops are holes."""
    return [np.asarray(loop, dtype=float) for loop in section_loops(sec, n_sides=n_sides)]


def _signed_polygon_area(poly: np.ndarray) -> float:
    return float(0.5 * np.sum(poly[:, 0] * np.roll(poly[:, 1], -1) - np.roll(poly[:, 0], -1) * poly[:, 1]))


def _is_convex_polygon(poly: np.ndarray) -> bool:
    signs = []
    for i in range(len(poly)):
        a = poly[i] - poly[i - 1]
        b = poly[(i + 1) % len(poly)] - poly[i]
        cross = float(a[0] * b[1] - a[1] * b[0])
        if abs(cross) > 1e-12:
            signs.append(cross > 0.0)
    return not signs or all(sign == signs[0] for sign in signs)


def _point_in_triangle(p: np.ndarray, a: np.ndarray, b: np.ndarray, c: np.ndarray) -> bool:
    v0 = c - a
    v1 = b - a
    v2 = p - a
    dot00 = float(np.dot(v0, v0))
    dot01 = float(np.dot(v0, v1))
    dot02 = float(np.dot(v0, v2))
    dot11 = float(np.dot(v1, v1))
    dot12 = float(np.dot(v1, v2))
    denom = dot00 * dot11 - dot01 * dot01
    if abs(denom) <= 1e-18:
        return False
    inv = 1.0 / denom
    u = (dot11 * dot02 - dot01 * dot12) * inv
    v = (dot00 * dot12 - dot01 * dot02) * inv
    return u >= -1e-12 and v >= -1e-12 and (u + v) <= 1.0 + 1e-12


def _triangulate_profile_polygon(poly: np.ndarray) -> list[tuple[int, int, int]]:
    """Ear-clip a simple 2-D profile polygon for robust vtk.js end caps."""
    clockwise = _signed_polygon_area(poly) < 0.0
    vertices = list(range(len(poly)))
    triangles: list[tuple[int, int, int]] = []

    while len(vertices) > 3:
        for pos, curr in enumerate(vertices):
            prev = vertices[pos - 1]
            nxt = vertices[(pos + 1) % len(vertices)]
            a = poly[prev]
            b = poly[curr]
            c = poly[nxt]
            cross = float((b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0]))
            if (cross < -1e-12) != clockwise:
                continue
            if any(
                _point_in_triangle(poly[idx], a, b, c)
                for idx in vertices
                if idx not in {prev, curr, nxt}
            ):
                continue
            triangles.append((prev, curr, nxt))
            del vertices[pos]
            break
        else:
            return [(vertices[0], vertices[i], vertices[i + 1]) for i in range(1, len(vertices) - 1)]

    triangles.append(tuple(vertices))
    return triangles


def _map_element_surface_data(mesh, model, elem, results, station_fractions):
    """Attach endpoint-interpolated solver data to an already-built surface."""
    if results is not None:
        displacement = [np.zeros(3), np.zeros(3)]
        reaction = [np.zeros(3), np.zeros(3)]
        von_mises = [0.0, 0.0]
        for index, node_id in enumerate((elem.n1, elem.n2)):
            node_result = results.node_results.get(node_id)
            if node_result is not None:
                displacement[index] = node_result.displacement[:3]
                if node_result.reaction_force is not None:
                    reaction[index] = node_result.reaction_force[:3]
        element_result = results.element_results.get(elem.id)
        if element_result is not None:
            von_mises = [element_result.von_mises_n1, element_result.von_mises_n2]

        fractions = np.asarray(station_fractions, dtype=float)[:, None]
        mesh.point_data["DEPL"] = displacement[0] + fractions * (displacement[1] - displacement[0])
        mesh.point_data["DEPL_magnitude"] = np.linalg.norm(mesh.point_data["DEPL"], axis=1)
        mesh.point_data["VMIS"] = von_mises[0] + fractions[:, 0] * (von_mises[1] - von_mises[0])
        mesh.point_data["FORC_NODA"] = reaction[0] + fractions * (reaction[1] - reaction[0])
        mesh.point_data["FORC_magnitude"] = np.linalg.norm(mesh.point_data["FORC_NODA"], axis=1)

    if results is not None and results.load_case is not None:
        try:
            _, resolved_case = model.resolve_load_case(results.load_case)
        except ValueError as exc:
            raise ValueError(f"Cannot map temperature for result load case {results.load_case!r}.") from exc
        mesh.point_data["TEMP"] = np.full(mesh.n_points, resolved_case.temperature)
    elif results is None:
        try:
            _, resolved_case = model.resolve_load_case()
        except ValueError:
            resolved_case = None
        if resolved_case is not None:
            mesh.point_data["TEMP"] = np.full(mesh.n_points, resolved_case.temperature)
    return mesh


def _parallel_transport_frames(path: np.ndarray) -> list[tuple[np.ndarray, np.ndarray, np.ndarray]]:
    """Frames along a path, transported rather than recomputed per point.

    The first frame is the shared beam frame for the element's own direction, so
    this path and the review bundle's element meshes start from one construction.
    After that the frame is rotated along the path by the smallest rotation
    carrying the previous tangent onto the next, which is what keeps a section
    from twisting as it turns: a frame rebuilt from the tangent alone would
    pick a fresh reference direction at every point.
    """
    frames = [beam_local_frame(path[0], path[1], twist_angle_deg=0.0)]
    for i in range(1, len(path)):
        if i < len(path) - 1:
            tangent = path[i + 1] - path[i - 1]
        else:
            tangent = path[i] - path[i - 1]
        norm = np.linalg.norm(tangent)
        if norm > 1e-9:
            tangent = tangent / norm
        else:
            tangent = frames[-1][0]

        lx_prev, ly_prev, lz_prev = frames[-1]
        rot_axis = np.cross(lx_prev, tangent)
        rot_norm = np.linalg.norm(rot_axis)
        if rot_norm > 1e-9:
            rot_axis = rot_axis / rot_norm
            theta = np.arccos(np.clip(np.dot(lx_prev, tangent), -1.0, 1.0))
            cos_t = np.cos(theta)
            sin_t = np.sin(theta)
            # Rodrigues' rotation of the previous y about the axis between the
            # two tangents, so the section is carried rather than rebuilt.
            ly = (
                ly_prev * cos_t
                + np.cross(rot_axis, ly_prev) * sin_t
                + rot_axis * np.dot(rot_axis, ly_prev) * (1.0 - cos_t)
            )
            ly = ly / np.linalg.norm(ly)
            lz = np.cross(tangent, ly)
            lz = lz / np.linalg.norm(lz)
        else:
            ly, lz = ly_prev, lz_prev
        frames.append((tangent, ly, lz))
    return frames


def _get_element_3d_mesh(
    model: "TubaModel",
    elem: "Element",
    results: Optional["FEAResults"] = None,
) -> "pv.PolyData":
    """Construct a 3-D extruded solid mesh for a single element with result mapping."""
    _require_pyvista()

    if elem.type != "pipe_bend" or not elem.bend_radius:
        surface = straight_section_surface_mesh(
            model.sections[elem.section],
            model.nodes[elem.n1].coords,
            model.nodes[elem.n2].coords,
            twist_angle_deg=float(getattr(elem, "twist_angle", 0.0)),
        )
        cells = np.asarray([[3, *face] for face in surface.faces], dtype=np.int32).ravel()
        mesh = pv.PolyData(np.asarray(surface.vertices), faces=cells)
        points_per_end = len(surface.vertices) // 2
        return _map_element_surface_data(
            mesh,
            model,
            elem,
            results,
            [0.0] * points_per_end + [1.0] * points_per_end,
        )
    
    # 1. Determine centerline path points
    path = _get_bend_points(model, elem, n_segments=16)
    N = len(path)
        
    # 2. Get 2D profile loops
    sec = model.sections[elem.section]
    profile_loops = _get_profile_2d_loops(sec)
    loop_sizes = [len(loop) for loop in profile_loops]
    loop_offsets = np.cumsum([0] + loop_sizes[:-1]).tolist()
    M = sum(loop_sizes)
    
    # 3. Frames along the path. The starting frame comes from the shared beam
    # frame, so this surface and the review bundle's element meshes agree about
    # which way a section's web or generatrice points instead of each carrying
    # their own copy of the construction.
    frames = _parallel_transport_frames(path)

    # 4. Generate 3D points
    points_3d = []
    for j in range(N):
        pj = path[j]
        _, ly, lz = frames[j]
        for loop in profile_loops:
            for y_i, z_i in loop:
                pt_3d = pj + y_i * ly + z_i * lz
                points_3d.append(pt_3d)
    points_3d = np.array(points_3d)
    
    # 5. Build quad cells and end caps
    cells = []
    # Quads
    for loop_idx, loop_size in enumerate(loop_sizes):
        loop_offset = loop_offsets[loop_idx]
        for j in range(N - 1):
            for i in range(loop_size):
                i_next = (i + 1) % loop_size
                v0 = j * M + loop_offset + i
                v1 = j * M + loop_offset + i_next
                v2 = (j + 1) * M + loop_offset + i_next
                v3 = (j + 1) * M + loop_offset + i
                cells.append([4, v0, v1, v2, v3] if loop_idx == 0 else [4, v0, v3, v2, v1])

    if len(profile_loops) == 1 and _is_convex_polygon(profile_loops[0]):
        start_cap = [M] + [i for i in reversed(range(M))]
        cells.append(start_cap)

        end_cap = [M] + [(N - 1) * M + i for i in range(M)]
        cells.append(end_cap)
    elif len(profile_loops) == 1:
        for a, b, c in _triangulate_profile_polygon(profile_loops[0]):
            cells.append([3, c, b, a])
        offset = (N - 1) * M
        for a, b, c in _triangulate_profile_polygon(profile_loops[0]):
            cells.append([3, offset + a, offset + b, offset + c])
    else:
        outer_size = loop_sizes[0]
        inner_size = loop_sizes[1]
        if outer_size != inner_size:
            raise ValueError(f"Hollow section {elem.section!r} requires matching outer/inner profile point counts.")
        inner_offset = loop_offsets[1]
        end_offset = (N - 1) * M
        for i in range(outer_size):
            i_next = (i + 1) % outer_size
            cells.append([4, i_next, i, inner_offset + i, inner_offset + i_next])
            cells.append([
                4,
                end_offset + i,
                end_offset + i_next,
                end_offset + inner_offset + i_next,
                end_offset + inner_offset + i,
            ])
    
    cells_arr = []
    for c in cells:
        cells_arr.extend(c)
    cells_arr = np.array(cells_arr, dtype=np.int32)
    
    mesh = pv.PolyData(points_3d, faces=cells_arr)
    
    station_fractions = np.repeat(np.linspace(0.0, 1.0, N), M)
    return _map_element_surface_data(mesh, model, elem, results, station_fractions)


def build_3d_mesh_from_model(
    model: "TubaModel",
    results: Optional["FEAResults"] = None,
) -> "pv.PolyData":
    """Construct a full 3-D cross-sectional geometry mesh from a TubaModel."""
    _require_pyvista()
    meshes = []
    for elem in model.elements:
        m = _get_element_3d_mesh(model, elem, results)
        if m.n_points > 0:
            meshes.append(m)
            
    if not meshes:
        return pv.PolyData()
        
    merged = meshes[0]
    if len(meshes) > 1:
        merged = merged.merge(meshes[1:])
        
    return merged
