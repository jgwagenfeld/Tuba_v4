"""
tuba.plotting.pipeline — Core visualization pipeline.

Converts Tuba model data and FEA results into PyVista meshes
for rendering. Handles:
  - Loading .rmed files via meshio
  - Building line meshes directly from TubaModel geometry
  - Inflating 1D lines into 3D tubes
  - Mapping scalar fields to tube surfaces
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from types import SimpleNamespace
from typing import TYPE_CHECKING, Optional

import numpy as np

from tuba.geometry.section_mesh import beam_local_frame, section_loops, straight_section_surface_mesh
from tuba.solver.aster_loads import node_temperature_entries, resolve_operation_field_groups

if TYPE_CHECKING:
    from tuba.model import TubaModel
    from tuba.solver.base import FEAResults

try:
    import pyvista as pv

    _HAS_PYVISTA = True
except ImportError:
    _HAS_PYVISTA = False

try:
    import meshio

    _HAS_MESHIO = True
except ImportError:
    _HAS_MESHIO = False


def _require_pyvista():
    if not _HAS_PYVISTA:
        raise ImportError(
            "PyVista is required for visualization. "
            "Install it with: pip install 'tuba[viz]'"
        )


# ---------------------------------------------------------------------------
# Loading .rmed results
# ---------------------------------------------------------------------------


def load_rmed(path: str) -> "pv.UnstructuredGrid":
    """Read a Code_Aster ``.rmed`` result file and return a PyVista mesh.

    Uses *meshio* to parse the MED format, then converts to a PyVista
    :class:`~pyvista.UnstructuredGrid`.  All point and cell data arrays
    present in the file are preserved.
    """
    _require_pyvista()
    if not _HAS_MESHIO:
        raise ImportError("meshio is required to read .rmed files: pip install meshio")

    try:
        mesh_io = meshio.read(str(path), file_format="med")
    except (KeyError, TypeError):
        # Code_Aster pipe studies can contain section-point ELGA supports such
        # as ``SP_PIPE SE3`` and fields present on only one MED cell block.
        # meshio 5.3 cannot represent either case.  Read the same MED datasets
        # while retaining every supported nodal/ELNO array and deliberately
        # skipping only unsupported integration-point supports.
        mesh_io = _read_code_aster_med_fields(path)

    points = mesh_io.points
    if points.shape[1] == 2:
        points = np.column_stack([points, np.zeros(len(points))])

    cells, cell_types, supported_blocks = [], [], []
    vtk_cell_types = {
        "line": 3,       # VTK_LINE
        "line3": 21,     # VTK_QUADRATIC_EDGE
        "triangle": 5,
        "quad": 9,
    }
    for block_index, cell_block in enumerate(mesh_io.cells):
        ct = cell_block.type
        data = cell_block.data
        vtk_type = vtk_cell_types.get(ct)
        if vtk_type is None:
            continue  # skip unsupported
        supported_blocks.append((block_index, cell_block))
        for conn in data:
            cells.append(np.concatenate([[len(conn)], conn]))
            cell_types.append(vtk_type)

    if not cells:
        raise ValueError(f"RMED mesh {path!r} does not contain supported cells for visualization.")

    cells_arr = np.concatenate(cells)
    grid = pv.UnstructuredGrid(cells_arr, np.array(cell_types), points)

    # Transfer point data
    for name, arr in mesh_io.point_data.items():
        grid.point_data[name] = arr

    # Transfer cell data
    for name, blocks in mesh_io.cell_data.items():
        selected = [
            np.asarray(blocks[index])
            for index, _block in supported_blocks
            if blocks[index] is not None
        ]
        if not selected:
            continue
        if any(array.shape[1:] != selected[0].shape[1:] for array in selected[1:]):
            # Mixed MED element families can expose different ELNO/Gauss
            # cardinalities.  Such arrays cannot be represented as one VTK
            # cell field without discarding their element-local meaning.
            continue
        combined = np.concatenate(selected)
        if len(combined) == grid.n_cells:
            grid.cell_data[name] = combined.reshape(len(combined), -1)

    displacement = _latest_result_array(mesh_io.point_data, "DEPL")
    if displacement is not None and displacement.ndim == 2 and displacement.shape[1] >= 3:
        grid.point_data["DEPL"] = displacement[:, :3]
        grid.point_data["DEPL_magnitude"] = np.linalg.norm(displacement[:, :3], axis=1)

    stress_blocks = _latest_result_array(mesh_io.cell_data, "SIEQ")
    if stress_blocks is not None:
        point_stress = np.full(len(points), np.nan)
        for (block_index, cell_block) in supported_blocks:
            if stress_blocks[block_index] is None:
                continue
            block = np.asarray(stress_blocks[block_index])
            if block.ndim < 3:
                continue
            for connection, values in zip(cell_block.data, block[:, :, 0]):
                for point_index, value in zip(connection, values):
                    current = point_stress[point_index]
                    point_stress[point_index] = value if np.isnan(current) else max(current, value)
        if np.isfinite(point_stress).any():
            grid.point_data["VMIS"] = point_stress

    return grid


def _read_code_aster_med_fields(path: str):
    """Read supported MED geometry/results when meshio rejects Aster supports.

    This compatibility reader intentionally uses meshio's MED value decoders,
    so profiles and Fortran-order result arrays retain their established
    semantics.  Unsupported Code_Aster integration-point supports are omitted;
    no substitute or zero-valued solver data is created.
    """
    import h5py
    from meshio.med import _med

    with h5py.File(path, "r") as med_file:
        meshes = med_file["ENS_MAA"]
        if len(meshes) != 1:
            raise ValueError(f"RMED must contain exactly one mesh, found {len(meshes)}.")
        mesh = meshes[next(iter(meshes))]
        dimension = mesh.attrs["ESP"]
        if "NOE" not in mesh:
            if len(mesh) != 1:
                raise ValueError(f"RMED mesh must contain exactly one time step, found {len(mesh)}.")
            mesh = mesh[next(iter(mesh))]

        coordinates = mesh["NOE"]["COO"]
        point_count = coordinates.attrs["NBR"]
        points = coordinates[()].reshape((point_count, dimension), order="F")

        cells = []
        cell_types = []
        cell_data = {}
        for med_type, cell_group in mesh["MAI"].items():
            cell_type = _med.med_to_meshio_type[med_type]
            connectivity = cell_group["NOD"]
            cell_count = connectivity.attrs["NBR"]
            cells.append(
                meshio.CellBlock(
                    cell_type,
                    connectivity[()].reshape(cell_count, -1, order="F") - 1,
                )
            )
            cell_types.append(cell_type)
            if "FAM" in cell_group:
                cell_data.setdefault("cell_tags", []).append(cell_group["FAM"][()])

        point_data = {}
        if "FAM" in mesh["NOE"]:
            point_data["point_tags"] = mesh["NOE"]["FAM"][()]

        profiles = med_file["PROFILS"] if "PROFILS" in med_file else None
        for field_name, field in med_file.get("CHA", {}).items():
            steps = sorted(field.keys())
            names = [field_name]
            if len(steps) > 1:
                names = [
                    f"{field_name}[{index}] - {field[step].attrs['PDT']:g}"
                    for index, step in enumerate(steps)
                ]
            for name, step in zip(names, steps):
                med_data = field[step]
                for support in med_data:
                    if support == "NOE":
                        point_data[name] = _med._read_nodal_data(med_data, profiles)
                        continue
                    med_cell_type = support.partition(".")[2]
                    cell_type = _med.med_to_meshio_type.get(med_cell_type)
                    if cell_type not in cell_types:
                        continue
                    values = cell_data.setdefault(name, [None] * len(cell_types))
                    values[cell_types.index(cell_type)] = _med._read_cell_data(
                        med_data[support], profiles
                    )

    return SimpleNamespace(
        points=points,
        cells=cells,
        point_data=point_data,
        cell_data=cell_data,
    )


def _latest_result_array(data: dict, field: str):
    matches = [(name, value) for name, value in data.items() if field in name.upper()]
    if not matches:
        return None

    def step(item):
        name = item[0]
        try:
            return int(name.rsplit("[", 1)[1].split("]", 1)[0])
        except (IndexError, ValueError):
            return -1

    return max(matches, key=step)[1]


# ---------------------------------------------------------------------------
# Build mesh from TubaModel + FEAResults
# ---------------------------------------------------------------------------


def _get_bend_points(model: "TubaModel", elem: "Element", n_segments: int = 16) -> np.ndarray:
    """Calculate intermediate coordinates along the 3D circular bend arc."""
    p1 = model.nodes[elem.n1].coords
    if elem.bend_geometry is None:
        raise ValueError(f"Cannot visualize pipe bend {elem.id!r} without explicit bend_geometry.")
    from tuba.model import sample_bend_geometry

    return sample_bend_geometry(p1, elem.bend_geometry, n_segments=n_segments)


def _node_result_vector(results, node_id, quantity):
    record = results.node_results.get(node_id)
    try:
        vector = np.asarray(getattr(record, quantity, None), dtype=float)
    except (TypeError, ValueError):
        return np.full(3, np.nan)
    if vector.ndim != 1 or len(vector) < 3 or not np.isfinite(vector[:3]).all():
        return np.full(3, np.nan)
    return vector[:3]


def _element_von_mises(results, element):
    record = results.element_results.get(element.id)
    try:
        values = np.asarray([
            getattr(record, "von_mises_n1", np.nan),
            getattr(record, "von_mises_n2", np.nan),
        ], dtype=float)
    except (TypeError, ValueError):
        return np.full(2, np.nan)
    return np.where(np.isfinite(values), values, np.nan)


def _nodal_von_mises(model, results):
    """Average incident endpoint stresses only when every value is available."""
    values = {node_id: [] for node_id in model.nodes}
    for element in model.elements:
        stresses = _element_von_mises(results, element)
        values[element.n1].append(stresses[0])
        values[element.n2].append(stresses[1])
    return {
        node_id: float(np.mean(stresses)) if stresses and np.isfinite(stresses).all() else np.nan
        for node_id, stresses in values.items()
    }


def _interpolate_endpoints(values, fractions, *, interpolate=True):
    """Keep known endpoints; an unavailable endpoint leaves the span unavailable."""
    values = np.asarray(values, dtype=float)
    fractions = np.asarray(fractions, dtype=float)
    mapped = np.full((len(fractions), *values.shape[1:]), np.nan)
    if interpolate:
        weights = fractions.reshape((-1,) + (1,) * (values.ndim - 1))
        mapped = (1 - weights) * values[0] + weights * values[1]
    mapped[fractions == 0] = values[0]
    mapped[fractions == 1] = values[1]
    return mapped


def _require_result_field(mesh, field, *, complete=False):
    if field not in mesh.point_data:
        raise ValueError(f"Solver result field {field} is unavailable.")
    values = np.asarray(mesh.point_data[field], dtype=float)
    if field in {"DEPL", "FORC_NODA"}:
        if values.ndim != 2 or values.shape[1] < 3:
            raise ValueError(f"Solver result field {field} requires XYZ vectors.")
        values = values[:, :3]
        finite = np.isfinite(values).all(axis=1)
    else:
        finite = np.isfinite(values)
    if not finite.any() or (complete and not finite.all()):
        raise ValueError(f"Solver result field {field} has missing or non-finite values.")
    values = values.copy()
    values[~finite] = np.nan
    mesh.point_data[field] = values
    if field in {"DEPL", "FORC_NODA"}:
        magnitude_field = "DEPL_magnitude" if field == "DEPL" else "FORC_magnitude"
        mesh.point_data[magnitude_field] = np.linalg.norm(values, axis=1)
    return values


def build_mesh_from_model(
    model: "TubaModel",
    results: Optional["FEAResults"] = None,
) -> "pv.PolyData":
    """Construct a PyVista **line** mesh (centreline) from a :class:`TubaModel`.

    This is the "mesh mode" view: the raw centreline with curved bends and no
    section thickness. Its counterpart is :func:`build_3d_mesh_from_model`,
    which extrudes each element's true section profile ("geometry mode"). Both
    are public entry points — pick mesh mode for a fast schematic, geometry
    mode to see real pipe/beam shapes.
    """
    _require_pyvista()

    # Pre-populate points list with basic nodes
    node_ids = list(model.nodes.keys())
    points_list = [model.nodes[nid].coords for nid in node_ids]
    
    # Store indices for basic nodes
    node_idx = {nid: i for i, nid in enumerate(node_ids)}
    
    # Results data lists
    disp_list = []
    vmis_list = []
    forc_list = []
    
    if results is not None:
        stress_by_node = _nodal_von_mises(model, results)
        for nid in node_ids:
            disp_list.append(_node_result_vector(results, nid, "displacement"))
            vmis_list.append(stress_by_node[nid])
            forc_list.append(_node_result_vector(results, nid, "reaction_force"))

    all_edges = []
    
    for elem in model.elements:
        if elem.type == "pipe_bend" and elem.bend_radius:
            # Generate curved points
            n_segs = 16
            arc_pts = _get_bend_points(model, elem, n_segments=n_segs)
            
            pts_idxs = [node_idx[elem.n1]]
            for i in range(1, n_segs):
                pts_idxs.append(len(points_list))
                points_list.append(arc_pts[i])
                
                # Interpolate results for intermediate points
                if results is not None:
                    t = i / n_segs
                    displacement = [
                        _node_result_vector(results, node_id, "displacement")
                        for node_id in (elem.n1, elem.n2)
                    ]
                    disp_list.append(_interpolate_endpoints(displacement, [t])[0])
                    vmis_list.append(_interpolate_endpoints(_element_von_mises(results, elem), [t])[0])
                    # Reactions exist at solver nodes, not invented bend stations.
                    forc_list.append(np.full(3, np.nan))
                    
            pts_idxs.append(node_idx[elem.n2])
            
            for idx in range(n_segs):
                all_edges.append((pts_idxs[idx], pts_idxs[idx+1]))
        else:
            # Straight elements
            i1 = node_idx[elem.n1]
            i2 = node_idx[elem.n2]
            all_edges.append((i1, i2))

    # Group edges into continuous polylines
    n_pts = len(points_list)
    adj = {i: set() for i in range(n_pts)}
    for u, v in all_edges:
        adj[u].add(v)
        adj[v].add(u)

    degrees = {i: len(neighbors) for i, neighbors in adj.items()}
    visited_edges = set()
    polylines = []

    # 1. Start from endpoints or junctions (degree != 2)
    start_nodes = [i for i, deg in degrees.items() if deg != 2 and deg > 0]
    for u in start_nodes:
        for v in list(adj[u]):
            edge = tuple(sorted((u, v)))
            if edge not in visited_edges:
                poly = [u, v]
                visited_edges.add(edge)
                curr = v
                prev = u
                while degrees[curr] == 2:
                    neighbors = list(adj[curr] - {prev})
                    if not neighbors:
                        break
                    next_node = neighbors[0]
                    next_edge = tuple(sorted((curr, next_node)))
                    if next_edge in visited_edges:
                        break
                    poly.append(next_node)
                    visited_edges.add(next_edge)
                    prev = curr
                    curr = next_node
                polylines.append(poly)

    # 2. Start from any remaining unvisited edges (closed loops)
    for u in range(n_pts):
        for v in list(adj[u]):
            edge = tuple(sorted((u, v)))
            if edge not in visited_edges:
                poly = [u, v]
                visited_edges.add(edge)
                curr = v
                prev = u
                while True:
                    neighbors = list(adj[curr] - {prev})
                    if not neighbors:
                        break
                    next_node = neighbors[0]
                    next_edge = tuple(sorted((curr, next_node)))
                    if next_edge in visited_edges:
                        break
                    poly.append(next_node)
                    visited_edges.add(next_edge)
                    prev = curr
                    curr = next_node
                polylines.append(poly)

    # Build the PyVista lines cell array
    lines = []
    for poly in polylines:
        lines.append(len(poly))
        lines.extend(poly)

    points_arr = np.array(points_list)
    mesh = pv.PolyData(points_arr, lines=np.array(lines))

    if results is not None:
        mesh.point_data["DEPL"] = np.array(disp_list)
        mesh.point_data["DEPL_magnitude"] = np.linalg.norm(mesh.point_data["DEPL"], axis=1)
        mesh.point_data["VMIS"] = np.array(vmis_list)
        mesh.point_data["FORC_NODA"] = np.array(forc_list)
        mesh.point_data["FORC_magnitude"] = np.linalg.norm(mesh.point_data["FORC_NODA"], axis=1)

    return mesh


# ---------------------------------------------------------------------------
# True 3D Cross-Sectional Geometry Extrusion
# ---------------------------------------------------------------------------


def _get_profile_2d_loops(sec, n_sides: int = 16) -> list[np.ndarray]:
    """Return section profile loops; inner loops are holes."""
    return [np.asarray(loop, dtype=float) for loop in section_loops(sec, n_sides=n_sides)]


def _signed_polygon_area(poly: np.ndarray) -> float:
    return float(0.5 * np.sum(poly[:, 0] * np.roll(poly[:, 1], -1) - np.roll(poly[:, 0], -1) * poly[:, 1]))


def _is_convex_polygon(poly: np.ndarray) -> bool:
    signs = []
    for i in range(len(poly)):
        a = poly[i] - poly[i - 1]
        b = poly[(i + 1) % len(poly)] - poly[i]
        cross = float(a[0] * b[1] - a[1] * b[0])
        if abs(cross) > 1e-12:
            signs.append(cross > 0.0)
    return not signs or all(sign == signs[0] for sign in signs)


def _point_in_triangle(p: np.ndarray, a: np.ndarray, b: np.ndarray, c: np.ndarray) -> bool:
    v0 = c - a
    v1 = b - a
    v2 = p - a
    dot00 = float(np.dot(v0, v0))
    dot01 = float(np.dot(v0, v1))
    dot02 = float(np.dot(v0, v2))
    dot11 = float(np.dot(v1, v1))
    dot12 = float(np.dot(v1, v2))
    denom = dot00 * dot11 - dot01 * dot01
    if abs(denom) <= 1e-18:
        return False
    inv = 1.0 / denom
    u = (dot11 * dot02 - dot01 * dot12) * inv
    v = (dot00 * dot12 - dot01 * dot02) * inv
    return u >= -1e-12 and v >= -1e-12 and (u + v) <= 1.0 + 1e-12


def _triangulate_profile_polygon(poly: np.ndarray) -> list[tuple[int, int, int]]:
    """Ear-clip a simple 2-D profile polygon for robust vtk.js end caps."""
    clockwise = _signed_polygon_area(poly) < 0.0
    vertices = list(range(len(poly)))
    triangles: list[tuple[int, int, int]] = []

    while len(vertices) > 3:
        for pos, curr in enumerate(vertices):
            prev = vertices[pos - 1]
            nxt = vertices[(pos + 1) % len(vertices)]
            a = poly[prev]
            b = poly[curr]
            c = poly[nxt]
            cross = float((b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0]))
            if (cross < -1e-12) != clockwise:
                continue
            if any(
                _point_in_triangle(poly[idx], a, b, c)
                for idx in vertices
                if idx not in {prev, curr, nxt}
            ):
                continue
            triangles.append((prev, curr, nxt))
            del vertices[pos]
            break
        else:
            return [(vertices[0], vertices[i], vertices[i + 1]) for i in range(1, len(vertices) - 1)]

    triangles.append(tuple(vertices))
    return triangles


@dataclass(frozen=True)
class _AppliedTemperature:
    operation: str
    default: float
    element_values: dict[str, float]
    element_end_values: dict[str, tuple[float, float]]

    def at_stations(self, elem, station_fractions):
        if elem.id in self.element_end_values:
            return _interpolate_endpoints(self.element_end_values[elem.id], station_fractions)
        return np.full(len(station_fractions), self.element_values.get(elem.id, self.default))


def _resolve_applied_temperature(model, results):
    """Resolve one selected operation through the Code_Aster input helpers.

    Element assignments retain their constant input values. Node assignments
    use the compiler's interpolation and fallback to the last element field
    covering an otherwise uncovered endpoint, or the case default.
    """
    if results is not None:
        if results.load_case is None:
            return None
        try:
            operation, case = model.resolve_load_case(results.load_case)
        except ValueError as exc:
            raise ValueError(f"Cannot map temperature for result load case {results.load_case!r}.") from exc
    else:
        try:
            operation, case = model.resolve_load_case()
        except ValueError:
            return None

    fields = resolve_operation_field_groups(model, case, "temperature")
    element_values = {
        element_id: value
        for element_ids, value in fields
        for element_id in element_ids
    }
    # These identifiers belong to display endpoints, not to a solver mesh.
    # The helper resolves both ends of each element touched by a node field;
    # surface stations then interpolate the same engineering input fractions.
    endpoints = dict(node_temperature_entries(
        model, case, fields,
        lambda elem: [(f"{elem.id}:start", 0.0), (f"{elem.id}:end", 1.0)],
    ))
    element_end_values = {
        elem.id: (endpoints[f"{elem.id}:start"], endpoints[f"{elem.id}:end"])
        for elem in model.elements
        if f"{elem.id}:start" in endpoints
    }
    return _AppliedTemperature(operation, float(case.temperature), element_values, element_end_values)


def _map_element_surface_data(mesh, elem, results, station_fractions, temperature):
    """Attach solver fields and the separately resolved applied input."""
    if results is not None:
        displacement = [_node_result_vector(results, node_id, "displacement") for node_id in (elem.n1, elem.n2)]
        reaction = [_node_result_vector(results, node_id, "reaction_force") for node_id in (elem.n1, elem.n2)]
        mesh.point_data["DEPL"] = _interpolate_endpoints(displacement, station_fractions)
        mesh.point_data["DEPL_magnitude"] = np.linalg.norm(mesh.point_data["DEPL"], axis=1)
        mesh.point_data["VMIS"] = _interpolate_endpoints(_element_von_mises(results, elem), station_fractions)
        mesh.point_data["FORC_NODA"] = _interpolate_endpoints(reaction, station_fractions, interpolate=False)
        mesh.point_data["FORC_magnitude"] = np.linalg.norm(mesh.point_data["FORC_NODA"], axis=1)

    if temperature is not None:
        mesh.point_data["TEMP"] = temperature.at_stations(elem, station_fractions)
    return mesh


def _parallel_transport_frames(path: np.ndarray) -> list[tuple[np.ndarray, np.ndarray, np.ndarray]]:
    """Frames along a path, transported rather than recomputed per point.

    The first frame is the shared beam frame for the element's own direction, so
    this path and the review bundle's element meshes start from one construction.
    After that the frame is rotated along the path by the smallest rotation
    carrying the previous tangent onto the next, which is what keeps a section
    from twisting as it turns: a frame rebuilt from the tangent alone would
    pick a fresh reference direction at every point.
    """
    frames = [beam_local_frame(path[0], path[1], twist_angle_deg=0.0)]
    for i in range(1, len(path)):
        if i < len(path) - 1:
            tangent = path[i + 1] - path[i - 1]
        else:
            tangent = path[i] - path[i - 1]
        norm = np.linalg.norm(tangent)
        if norm > 1e-9:
            tangent = tangent / norm
        else:
            tangent = frames[-1][0]

        lx_prev, ly_prev, lz_prev = frames[-1]
        rot_axis = np.cross(lx_prev, tangent)
        rot_norm = np.linalg.norm(rot_axis)
        if rot_norm > 1e-9:
            rot_axis = rot_axis / rot_norm
            theta = np.arccos(np.clip(np.dot(lx_prev, tangent), -1.0, 1.0))
            cos_t = np.cos(theta)
            sin_t = np.sin(theta)
            # Rodrigues' rotation of the previous y about the axis between the
            # two tangents, so the section is carried rather than rebuilt.
            ly = (
                ly_prev * cos_t
                + np.cross(rot_axis, ly_prev) * sin_t
                + rot_axis * np.dot(rot_axis, ly_prev) * (1.0 - cos_t)
            )
            ly = ly / np.linalg.norm(ly)
            lz = np.cross(tangent, ly)
            lz = lz / np.linalg.norm(lz)
        else:
            ly, lz = ly_prev, lz_prev
        frames.append((tangent, ly, lz))
    return frames


def _get_element_3d_mesh(
    model: "TubaModel",
    elem: "Element",
    results: Optional["FEAResults"] = None,
    *,
    temperature: Optional[_AppliedTemperature] = None,
) -> "pv.PolyData":
    """Construct a 3-D extruded solid mesh for a single element with result mapping."""
    _require_pyvista()

    if elem.type != "pipe_bend" or not elem.bend_radius:
        surface = straight_section_surface_mesh(
            model.sections[elem.section],
            model.nodes[elem.n1].coords,
            model.nodes[elem.n2].coords,
            twist_angle_deg=float(getattr(elem, "twist_angle", 0.0)),
        )
        cells = np.asarray([[3, *face] for face in surface.faces], dtype=np.int32).ravel()
        mesh = pv.PolyData(np.asarray(surface.vertices), faces=cells)
        points_per_end = len(surface.vertices) // 2
        return _map_element_surface_data(
            mesh,
            elem,
            results,
            [0.0] * points_per_end + [1.0] * points_per_end,
            temperature,
        )
    
    # 1. Determine centerline path points
    path = _get_bend_points(model, elem, n_segments=16)
    N = len(path)
        
    # 2. Get 2D profile loops
    sec = model.sections[elem.section]
    profile_loops = _get_profile_2d_loops(sec)
    loop_sizes = [len(loop) for loop in profile_loops]
    loop_offsets = np.cumsum([0] + loop_sizes[:-1]).tolist()
    M = sum(loop_sizes)
    
    # 3. Frames along the path. The starting frame comes from the shared beam
    # frame, so this surface and the review bundle's element meshes agree about
    # which way a section's web or generatrice points instead of each carrying
    # their own copy of the construction.
    frames = _parallel_transport_frames(path)

    # 4. Generate 3D points
    points_3d = []
    for j in range(N):
        pj = path[j]
        _, ly, lz = frames[j]
        for loop in profile_loops:
            for y_i, z_i in loop:
                pt_3d = pj + y_i * ly + z_i * lz
                points_3d.append(pt_3d)
    points_3d = np.array(points_3d)
    
    # 5. Build quad cells and end caps
    cells = []
    # Quads
    for loop_idx, loop_size in enumerate(loop_sizes):
        loop_offset = loop_offsets[loop_idx]
        for j in range(N - 1):
            for i in range(loop_size):
                i_next = (i + 1) % loop_size
                v0 = j * M + loop_offset + i
                v1 = j * M + loop_offset + i_next
                v2 = (j + 1) * M + loop_offset + i_next
                v3 = (j + 1) * M + loop_offset + i
                cells.append([4, v0, v1, v2, v3] if loop_idx == 0 else [4, v0, v3, v2, v1])

    if len(profile_loops) == 1 and _is_convex_polygon(profile_loops[0]):
        start_cap = [M] + [i for i in reversed(range(M))]
        cells.append(start_cap)

        end_cap = [M] + [(N - 1) * M + i for i in range(M)]
        cells.append(end_cap)
    elif len(profile_loops) == 1:
        for a, b, c in _triangulate_profile_polygon(profile_loops[0]):
            cells.append([3, c, b, a])
        offset = (N - 1) * M
        for a, b, c in _triangulate_profile_polygon(profile_loops[0]):
            cells.append([3, offset + a, offset + b, offset + c])
    else:
        outer_size = loop_sizes[0]
        inner_size = loop_sizes[1]
        if outer_size != inner_size:
            raise ValueError(f"Hollow section {elem.section!r} requires matching outer/inner profile point counts.")
        inner_offset = loop_offsets[1]
        end_offset = (N - 1) * M
        for i in range(outer_size):
            i_next = (i + 1) % outer_size
            cells.append([4, i_next, i, inner_offset + i, inner_offset + i_next])
            cells.append([
                4,
                end_offset + i,
                end_offset + i_next,
                end_offset + inner_offset + i_next,
                end_offset + inner_offset + i,
            ])
    
    cells_arr = []
    for c in cells:
        cells_arr.extend(c)
    cells_arr = np.array(cells_arr, dtype=np.int32)
    
    mesh = pv.PolyData(points_3d, faces=cells_arr)
    
    station_fractions = np.repeat(np.linspace(0.0, 1.0, N), M)
    return _map_element_surface_data(mesh, elem, results, station_fractions, temperature)


def build_3d_mesh_from_model(
    model: "TubaModel",
    results: Optional["FEAResults"] = None,
) -> "pv.PolyData":
    """Construct a full 3-D cross-sectional geometry mesh from a TubaModel.

    ``TEMP`` is the selected operation's resolved applied input, not a nodal
    temperature read from an RMED result. Uniform element/route assignments,
    including the compiler's midpoint values for linear route fields, remain
    constant per element and can be discontinuous across a shared interface.
    Node-scoped inputs interpolate along each touched element's display
    stations, using the compiler's endpoint fallback and field write order.
    ``TEMP_source`` and ``TEMP_operation`` field data preserve that provenance.
    """
    _require_pyvista()
    temperature = _resolve_applied_temperature(model, results)
    meshes = []
    for elem in model.elements:
        m = _get_element_3d_mesh(model, elem, results, temperature=temperature)
        if m.n_points > 0:
            meshes.append(m)
            
    if not meshes:
        return pv.PolyData()
        
    merged = meshes[0]
    if len(meshes) > 1:
        # Preserve both element-local solver fields and discontinuous applied
        # inputs; merging shared vertices would silently choose one value.
        local_temperature = temperature is not None and bool(temperature.element_values)
        merged = merged.merge(meshes[1:], merge_points=results is None and not local_temperature)

    if temperature is not None:
        merged.field_data["TEMP_source"] = ["applied_input"]
        merged.field_data["TEMP_operation"] = [temperature.operation]
        
    return merged
