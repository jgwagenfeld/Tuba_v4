"""Validation helpers for Tuba models."""

from __future__ import annotations

from collections import Counter
from collections.abc import Sequence
import math
from numbers import Real
from typing import Any

import numpy as np

from tuba.attributes import coerce_entity_ref
from tuba.model import BarSection, CableSection, IBeamSection, PipeSection, RectangularSection, TubaModel
from tuba.placements import placement_frame_id, resolve_placement_frame
from tuba.refs import resolve_entity_ref


_PIPE_TO_PORT_OPTIONS = {"3D_TUYAU", "3D_POU", "COQ_TUYAU", "COQ_POU"}


class ModelValidationError(ValueError):
    """Raised when a model violates structural invariants."""


def validate_model(model: TubaModel) -> None:
    errors: list[str] = []

    for name, material in model.materials.items():
        label = f"Material {name!r}"
        _number(material.E, f"{label} E", errors, lower=0, open_lower=True)
        _number(material.nu, f"{label} nu", errors, lower=-1, upper=0.5,
                open_lower=True, open_upper=True)
        _number(material.rho, f"{label} rho", errors, lower=0)
        _number(material.alpha, f"{label} alpha", errors)

    for kind, cases in (("Load case", model.load_cases), ("Operation", model.operations)):
        for name, case in cases.items():
            label = f"{kind} {name!r}"
            _number(case.temperature, f"{label} temperature", errors)
            _number(case.ref_temperature, f"{label} ref_temperature", errors)
            _number(case.internal_pressure, f"{label} internal_pressure", errors, lower=0)

    for node_id, node in model.nodes.items():
        coords = np.asarray(node.coords, dtype=float)
        if coords.shape != (3,) or not np.all(np.isfinite(coords)):
            errors.append(f"Node {node_id!r} has invalid coordinates.")

    element_ids = [elem.id for elem in model.elements]
    for elem_id, count in Counter(element_ids).items():
        if count > 1:
            errors.append(f"Duplicate element id {elem_id!r}.")

    for elem in model.elements:
        if elem.n1 not in model.nodes:
            errors.append(f"Element {elem.id!r} references missing node {elem.n1!r}.")
        if elem.n2 not in model.nodes:
            errors.append(f"Element {elem.id!r} references missing node {elem.n2!r}.")
        if elem.section not in model.sections:
            errors.append(f"Element {elem.id!r} references missing section {elem.section!r}.")
        if elem.material not in model.materials:
            errors.append(f"Element {elem.id!r} references missing material {elem.material!r}.")
        if elem.n1 == elem.n2:
            errors.append(f"Element {elem.id!r} has identical start and end nodes.")
        _validate_element_station(elem, errors)
        _validate_bend_geometry_record(elem, errors)

    for support in model.supports:
        if support.node not in model.nodes:
            errors.append(f"Support references missing node {support.node!r}.")
        if support.attached_to is not None:
            if support.attached_to not in model.nodes:
                errors.append(f"Support {support.id!r} is attached to missing node {support.attached_to!r}.")
            elif support.attached_to == support.node:
                errors.append(
                    f"Support {support.id!r} is attached to its own node {support.node!r}; give the pipe its own node."
                )
            if support.imposed_displacement is not None:
                errors.append(f"Support {support.id!r} is attached to a node, so it cannot impose a displacement.")
            if support.type == "spring" and support.blocked_dof is not None:
                errors.append(f"Support {support.id!r} is an attached spring, so it cannot also block DOFs.")

    for name, section in model.sections.items():
        _validate_section(name, section, errors)

    for group_name, group in getattr(model, "groups", {}).items():
        for node_id in group.get("nodes", []):
            if node_id not in model.nodes:
                errors.append(f"Group {group_name!r} references missing node {node_id!r}.")
        for element_id in group.get("elements", []):
            if element_id not in element_ids:
                errors.append(f"Group {group_name!r} references missing element {element_id!r}.")

    _validate_placement_frames(model, errors)
    _validate_placement_assignments(model, errors)

    for assignment in getattr(model, "attributes", []):
        try:
            resolve_entity_ref(model, assignment.target)
        except KeyError:
            errors.append(
                f"Attribute {assignment.key!r} references missing "
                f"{assignment.target.kind} {assignment.target.id!r}."
            )
        if assignment.key == "insulation" and assignment.value not in model.specs.get("insulation", {}):
            errors.append(f"Attribute 'insulation' references missing spec {assignment.value!r}.")

    _validate_mixed_records(model, errors)
    _validate_operation_fields(model, errors)
    _validate_nodal_forces(model, errors)

    if errors:
        raise ModelValidationError("\n".join(errors))


def _validate_element_station(elem, errors: list[str]) -> None:
    start = getattr(elem, "station_start", None)
    end = getattr(elem, "station_end", None)
    if start is None and end is None:
        return
    if start is None or end is None:
        errors.append(f"Element {elem.id!r} must define both station_start and station_end.")
        return
    if not np.isfinite(float(start)) or not np.isfinite(float(end)):
        errors.append(f"Element {elem.id!r} has non-finite station metadata.")
        return
    if float(end) < float(start):
        errors.append(f"Element {elem.id!r} station_end must be greater than or equal to station_start.")


def _validate_bend_geometry_record(elem, errors: list[str]) -> None:
    geometry = getattr(elem, "bend_geometry", None)
    if geometry is None:
        return
    if elem.type != "pipe_bend":
        errors.append(f"Element {elem.id!r} has bend_geometry but is not a pipe_bend.")
        return
    for attr in ("center", "normal", "start_tangent", "end_tangent"):
        values = np.asarray(getattr(geometry, attr), dtype=float)
        if values.shape != (3,) or not np.all(np.isfinite(values)):
            errors.append(f"Element {elem.id!r} bend_geometry.{attr} must be a finite 3-vector.")
        elif attr != "center" and np.linalg.norm(values) <= 1e-12:
            errors.append(f"Element {elem.id!r} bend_geometry.{attr} must be non-zero.")
    if not np.isfinite(float(geometry.radius)) or float(geometry.radius) <= 0.0:
        errors.append(f"Element {elem.id!r} bend_geometry.radius must be positive.")
    if not np.isfinite(float(geometry.angle)) or abs(float(geometry.angle)) <= 1e-12:
        errors.append(f"Element {elem.id!r} bend_geometry.angle must be non-zero.")
    if not geometry.generation_mode:
        errors.append(f"Element {elem.id!r} bend_geometry.generation_mode must not be empty.")


def _pipe_node_ids(model: TubaModel) -> set[str]:
    """Nodes that lie on a pipe element, the only nodes a node temperature may name."""
    return {
        node_id
        for elem in model.elements
        if elem.type in {"pipe_straight", "pipe_bend"}
        for node_id in (elem.n1, elem.n2)
    }


def fluid_field_problem(field_record, *, infer_scope: bool = False, selectors: list[str] | None = None) -> str | None:
    """Strict contents admission, also used before authoring can coerce a value."""
    errors: list[str] = []
    _number(field_record.value, "fluid_density", errors, lower=0)
    if errors:
        return errors[0]
    selectors = selectors if selectors is not None else [name for name, value in (
        ("group", field_record.group is not None),
        ("route", field_record.route_id is not None),
        ("elements", bool(field_record.element_ids)),
        ("nodes", bool(field_record.node_ids)),
    ) if value]
    scope = field_record.scope
    if len(selectors) > 1 or (selectors and scope != selectors[0] and not (infer_scope and scope == "all")):
        return "fluid_density has competing selectors or a conflicting scope."
    if infer_scope and selectors:
        scope = selectors[0]
    if scope not in {"all", "group", "route", "elements"} or field_record.node_ids:
        return "fluid_density requires all, group, route or elements scope."
    if field_record.profile != "uniform" or field_record.direction is not None:
        return "fluid_density requires a uniform profile without direction."
    for name in ("station_start", "station_end"):
        value = getattr(field_record, name)
        if value is not None:
            if scope != "route":
                return "fluid_density station selectors require route scope."
            _number(value, f"fluid_density {name}", errors)
    return errors[0] if errors else None


def operation_field_problem(
    field_record,
    model: TubaModel,
    pipe_nodes: set[str] | None = None,
) -> str | None:
    """The first reason one operation field cannot compile, or None.

    This is the only place a single field's rules live: admission (``validate_model``) and the
    Code_Aster exporters both cross it. Messages read as the tail of
    ``Operation 'Name' field 2 <message>``.
    """
    if field_record.quantity == "fluid_density":
        problem = fluid_field_problem(field_record)
        if problem:
            return problem
    if field_record.quantity not in {"pressure", "temperature", "wind", "line_load", "fluid_density"}:
        return (
            f"has unsupported quantity {field_record.quantity!r}; "
            "supported quantities are pressure, temperature, wind, line_load, and fluid_density."
        )
    if field_record.scope not in {"all", "group", "route", "elements", "nodes"}:
        return f"has unsupported scope {field_record.scope!r}."
    if field_record.profile not in {"uniform", "linear", "piecewise"}:
        return f"has unsupported profile {field_record.profile!r}."
    if not np.isfinite(float(field_record.value)):
        return "has a non-finite value."
    if field_record.scope == "nodes" or field_record.node_ids:
        if pipe_nodes is None:
            pipe_nodes = _pipe_node_ids(model)
        return _node_field_problem(field_record, model, pipe_nodes)
    if field_record.profile != "uniform":
        if not (field_record.quantity in {"temperature", "pressure"} and field_record.profile == "linear"):
            return (
                f"uses profile {field_record.profile!r}; "
                "the Code_Aster writer currently supports only uniform operation fields, "
                "plus linear pressure and temperature fields by route/station."
            )
        if field_record.scope != "route" or not field_record.route_id:
            return f"linear {field_record.quantity} field requires route scope."
        if field_record.station_start is None or field_record.station_end is None:
            return f"linear {field_record.quantity} field requires station_start and station_end."
    if field_record.direction is not None and field_record.quantity not in {"wind", "line_load"}:
        return "uses direction but only wind and line_load fields accept direction."
    if field_record.quantity in {"wind", "line_load"}:
        if field_record.direction is None:
            return f"{field_record.quantity} field requires a finite non-zero direction vector."
        direction = np.asarray(field_record.direction, dtype=float)
        if direction.shape != (3,) or not np.all(np.isfinite(direction)) or np.linalg.norm(direction) <= 1e-12:
            return f"{field_record.quantity} field requires a finite non-zero direction vector."
    start = field_record.station_start
    end = field_record.station_end
    if start is not None and not np.isfinite(float(start)):
        return "has non-finite station_start."
    if end is not None and not np.isfinite(float(end)):
        return "has non-finite station_end."
    if start is not None and end is not None and float(end) <= float(start):
        return "station_end must be greater than station_start."
    try:
        selected = model.resolve_operation_field_elements(field_record)
    except ValueError as exc:
        return f"is invalid: {exc}"
    if not selected:
        if field_record.quantity in {"wind", "line_load"}:
            return "selects no pipe or beam elements."
        return "selects no pipe elements."
    if field_record.quantity == "fluid_density":
        refused = [e.id for e in selected if not isinstance(model.sections.get(e.section), PipeSection)]
        if refused:
            return f"fluid_density requires PipeSection on elements {refused!r}."
    return None


def operation_fields_problem(fields: Sequence[Any], model: TubaModel) -> list[str]:
    """Every reason these fields cannot compile together, as messages that follow ``Operation 'Name' ``.

    Cross-field rules (overlaps, node versus element temperatures) live here beside the per-field
    rules, so admission and export see the same set.
    """
    problems: list[str] = []
    pipe_nodes = _pipe_node_ids(model)
    seen: dict[str, dict[str, tuple[Any, ...]]] = {}
    node_temperatures: dict[str, float] = {}
    element_temperature_nodes: dict[str, set[int]] = {}
    for index, field_record in enumerate(fields):
        problem = operation_field_problem(field_record, model, pipe_nodes)
        if problem is not None:
            problems.append(f"field {index} {problem}")
            continue
        if field_record.scope == "nodes" or field_record.node_ids:
            value = float(field_record.value)
            for node_id in field_record.node_ids:
                previous = node_temperatures.get(node_id)
                if previous is not None and previous != value:
                    problems.append(
                        f"has overlapping incompatible temperature fields "
                        f"on node {node_id!r}: {previous!r} vs {value!r}."
                    )
                node_temperatures[node_id] = value
            continue
        selected = model.resolve_operation_field_elements(field_record)
        if field_record.quantity == "temperature":
            for elem in selected:
                for node_id in (elem.n1, elem.n2):
                    element_temperature_nodes.setdefault(node_id, set()).add(index)
        quantity_values = seen.setdefault(field_record.quantity, {})
        value_key = _operation_field_value_key(field_record)
        for elem in selected:
            previous = quantity_values.get(elem.id)
            if previous is not None and field_record.quantity == "line_load":
                # Pressure, temperature and wind are states, so equal values agree; line loads add.
                problems.append(
                    f"has overlapping line_load fields on element {elem.id!r}; "
                    "line loads add, so author one combined line_load field."
                )
            elif previous is not None and previous != value_key:
                problems.append(
                    f"has overlapping incompatible {field_record.quantity} fields on element {elem.id!r}: "
                    f"{previous!r} vs {value_key!r}."
                )
            quantity_values[elem.id] = value_key
    shared = sorted(set(node_temperatures) & set(element_temperature_nodes))
    if shared:
        indices = sorted({index for node_id in shared for index in element_temperature_nodes[node_id]})
        problems.append(
            f"gives nodes {shared!r} a node temperature, but they belong to elements that "
            f"element temperature fields {indices!r} cover; a node takes one or the other."
        )
    return problems


def _validate_operation_fields(model: TubaModel, errors: list[str]) -> None:
    for operation_name, operation in {**model.load_cases, **model.operations}.items():
        errors.extend(
            f"Operation {operation_name!r} {problem}"
            for problem in operation_fields_problem(getattr(operation, "fields", []), model)
        )


def _node_field_problem(field_record, model: TubaModel, pipe_nodes: set[str]) -> str | None:
    """The first reason a node-scoped operation field is invalid, or None."""
    if field_record.scope != "nodes":
        return f"lists node_ids but has scope {field_record.scope!r}; node_ids need scope 'nodes'."
    if field_record.quantity != "temperature" or field_record.profile != "uniform":
        return f"scopes {field_record.quantity!r} to nodes; only uniform temperature fields take node_ids."
    if not field_record.node_ids:
        return "has scope 'nodes' but no node_ids."
    if (
        field_record.group is not None
        or field_record.route_id is not None
        or field_record.station_start is not None
        or field_record.station_end is not None
        or field_record.element_ids
        or field_record.direction is not None
    ):
        return "scopes to nodes, so it takes no group, route_id, station range, element_ids or direction."
    missing = [node_id for node_id in field_record.node_ids if node_id not in model.nodes]
    if missing:
        return f"references missing nodes {missing!r}."
    off_pipe = [node_id for node_id in field_record.node_ids if node_id not in pipe_nodes]
    if off_pipe:
        return f"gives a temperature to nodes on no pipe element: {off_pipe!r}."
    return None


def _operation_field_value_key(field_record) -> tuple[Any, ...]:
    if field_record.quantity == "fluid_density":
        return (float(field_record.value),)
    direction = None
    if field_record.direction is not None:
        vector = np.asarray(field_record.direction, dtype=float)
        norm = float(np.linalg.norm(vector))
        if norm > 1e-12:
            direction = tuple(float(value / norm) for value in vector)
    return (
        field_record.profile,
        float(field_record.value),
        field_record.station_start,
        field_record.station_end,
        direction,
    )


def _validate_nodal_forces(model: TubaModel, errors: list[str]) -> None:
    cases = [(f"Load case {name!r}", load_case) for name, load_case in getattr(model, "load_cases", {}).items()]
    cases.extend((f"Operation {name!r}", operation) for name, operation in getattr(model, "operations", {}).items())
    for label, case in cases:
        for index, force in enumerate(getattr(case, "nodal_forces", [])):
            force_label = f"{label} nodal force {index}"
            if force.node not in model.nodes:
                errors.append(f"{force_label} references missing node {force.node!r}.")
                continue
            components = np.asarray(force.components, dtype=float)
            if components.shape != (6,) or not np.all(np.isfinite(components)):
                errors.append(f"{force_label} must define finite [FX, FY, FZ, MX, MY, MZ] components.")
            elif np.linalg.norm(components) <= 1e-12:
                errors.append(f"{force_label} must not be all zero.")


def _validate_placement_frames(model: TubaModel, errors: list[str]) -> None:
    frames = getattr(model, "placement_frames", {})
    for frame_id, frame in frames.items():
        if frame_id != frame.id:
            errors.append(f"Placement frame key {frame_id!r} does not match id {frame.id!r}.")
        try:
            frame.to_coordinate_system()
        except Exception as exc:  # noqa: BLE001 - collect all validation errors
            errors.append(f"Placement frame {frame_id!r} is invalid: {exc}")
        parent_id = placement_frame_id(frame.parent)
        if parent_id is not None and parent_id not in frames:
            errors.append(f"Placement frame {frame_id!r} references missing parent {parent_id!r}.")

    for frame_id in frames:
        try:
            resolve_placement_frame(frame_id, frames)
        except Exception as exc:  # noqa: BLE001 - collect all validation errors
            errors.append(f"Placement frame cycle or resolution error at {frame_id!r}: {exc}")


def _validate_placement_assignments(model: TubaModel, errors: list[str]) -> None:
    frames = getattr(model, "placement_frames", {})
    seen: set[tuple[str, str | None]] = set()
    for assignment in getattr(model, "placement_assignments", []):
        frame_id = placement_frame_id(assignment.frame)
        if frame_id not in frames:
            errors.append(f"Placement assignment references missing frame {assignment.frame!r}.")
        try:
            resolve_entity_ref(model, coerce_entity_ref(assignment.target))
        except Exception:  # noqa: BLE001 - collect all validation errors
            errors.append(f"Placement assignment references missing target {assignment.target!r}.")
        if assignment.role == "object_placement":
            key = (assignment.target, assignment.source)
            if key in seen:
                errors.append(f"Duplicate object placement assignment for {assignment.target!r}.")
            seen.add(key)


def _number(value, label: str, errors: list[str], *, lower=None, upper=None,
            open_lower: bool = False, open_upper: bool = False) -> bool:
    """Check a real finite engineering scalar without coercing or replacing it."""
    expected = "a finite real number"
    if lower is not None:
        expected += f" {'>' if open_lower else '>='} {lower}"
    if upper is not None:
        expected += f" {'<' if open_upper else '<='} {upper}"
    valid = isinstance(value, Real) and not isinstance(value, (bool, np.bool_))
    if valid:
        try:
            valid = math.isfinite(value)
        except OverflowError:
            valid = False
    if valid and lower is not None:
        valid = value > lower if open_lower else value >= lower
    if valid and upper is not None:
        valid = value < upper if open_upper else value <= upper
    if not valid:
        errors.append(f"{label} must be {expected}; got {value!r}.")
    return bool(valid)


def _validate_section(name: str, section, errors: list[str]) -> None:
    if isinstance(section, PipeSection):
        label = f"Pipe section {name!r}"
        od_ok = _number(section.OD, f"{label} OD", errors, lower=0, open_lower=True)
        wt_ok = _number(section.WT, f"{label} WT", errors, lower=0, open_lower=True,
                        upper=section.OD / 2 if od_ok else None, open_upper=True)
        _number(section.corrosion_allowance, f"{label} corrosion_allowance", errors,
                lower=0, upper=section.WT if wt_ok else None, open_upper=True)
    elif isinstance(section, BarSection):
        _number(section.OD, f"Bar section {name!r} OD", errors, lower=0, open_lower=True)
        # WT == 0 and WT >= OD/2 both represent solid bars in the existing model.
        _number(section.WT, f"Bar section {name!r} WT", errors, lower=0)
    elif isinstance(section, CableSection):
        label = f"Cable section {name!r}"
        _number(section.radius, f"{label} radius", errors, lower=0, open_lower=True)
        _number(section.pretension, f"{label} pretension", errors, lower=0)
        _number(section.compression_modulus_ratio, f"{label} compression_modulus_ratio",
                errors, lower=0, upper=1)
    elif isinstance(section, RectangularSection):
        label = f"Rectangular section {name!r}"
        thickness_ok = []
        for axis in ("y", "z"):
            height = getattr(section, f"height_{axis}")
            valid = _number(height, f"{label} height_{axis}", errors, lower=0, open_lower=True)
            thickness_ok.append(_number(
                getattr(section, f"thickness_{axis}"), f"{label} thickness_{axis}", errors,
                lower=0, upper=height / 2 if valid else None, open_upper=True,
            ))
        if all(thickness_ok) and ((section.thickness_y == 0) != (section.thickness_z == 0)):
            errors.append(
                f"{label} thickness_y and thickness_z must both be zero for a solid section "
                f"or both positive for a hollow section; got {section.thickness_y!r}, {section.thickness_z!r}."
            )
    elif isinstance(section, IBeamSection):
        if not section.profile_name:
            errors.append(f"I-beam section {name!r} profile_name must not be empty.")
        required = {'A', 'IY', 'IZ', 'JX'}
        for key in sorted(required | section.properties.keys()):
            positive = key in required | {'H', 'B', 'Tw', 'Tf'}
            _number(section.properties.get(key), f"I-beam section {name!r} {key}", errors,
                    lower=0 if positive else None, open_lower=positive)
    else:
        errors.append(f"Section {name!r} has unsupported type {type(section).__name__}.")


def _validate_mixed_records(model: TubaModel, errors: list[str]) -> None:
    _validate_record_keys_and_ids("cad_assets", model.cad_assets, errors)
    _validate_record_keys_and_ids("imported_components", model.imported_components, errors)
    _validate_record_keys_and_ids("analysis_regions", model.analysis_regions, errors)
    _validate_record_keys_and_ids("ports", model.ports, errors)
    _validate_record_keys_and_ids("mesh_groups", model.mesh_groups, errors)
    _validate_record_keys_and_ids("couplings", model.couplings, errors)

    _validate_imported_components(model, errors)
    _validate_analysis_regions(model, errors)
    _validate_ports(model, errors)
    _validate_mesh_groups(model, errors)
    _validate_couplings(model, errors)


def _validate_record_keys_and_ids(record_name: str, records: dict[str, Any], errors: list[str]) -> None:
    for key, record in records.items():
        if key != getattr(record, "id", None):
            errors.append(
                f"{record_name} key {key!r} does not match record id {getattr(record, 'id', None)!r}."
            )


def _validate_imported_components(model: TubaModel, errors: list[str]) -> None:
    for component_id, component in model.imported_components.items():
        if component.asset.kind != "cad_asset":
            errors.append(
                f"Imported component {component_id!r} references non-cad asset {component.asset!r}."
            )
        try:
            resolve_entity_ref(model, component.asset)
        except KeyError:
            errors.append(
                f"Imported component {component_id!r} references missing cad asset {component.asset!r}."
            )


def _validate_analysis_regions(model: TubaModel, errors: list[str]) -> None:
    for region_id, region in model.analysis_regions.items():
        if region.owner.kind != "component":
            errors.append(
                f"Analysis region {region_id!r} owner must be a component, got {region.owner.kind!r}."
            )
        elif region.owner.id not in model.imported_components:
            errors.append(
                f"Analysis region {region_id!r} references missing owner {region.owner!r}."
            )

        if region.material not in model.materials:
            errors.append(
                f"Analysis region {region_id!r} references missing material {region.material!r}."
            )

        if region.role == "solid_3d" and region.code_aster_modelisation != "3D":
            errors.append(
                f"Analysis region {region_id!r} is solid_3d but has modelisation "
                f"{region.code_aster_modelisation!r}."
            )


def _validate_ports(model: TubaModel, errors: list[str]) -> None:
    for port_id, port in model.ports.items():
        if port.owner.kind != "component":
            errors.append(f"Port {port_id!r} owner must be a component, got {port.owner.kind!r}.")
        elif port.owner.id not in model.imported_components:
            errors.append(f"Port {port_id!r} references missing owner {port.owner!r}.")

        if port.status == "confirmed" and not port.face_group:
            errors.append(f"Port {port_id!r} is confirmed but missing face_group.")


def _validate_mesh_groups(model: TubaModel, errors: list[str]) -> None:
    for group_id, mesh_group in model.mesh_groups.items():
        try:
            resolve_entity_ref(model, mesh_group.owner)
        except KeyError:
            errors.append(
                f"Mesh group {group_id!r} references missing owner {mesh_group.owner!r}."
            )


def _validate_couplings(model: TubaModel, errors: list[str]) -> None:
    element_ids = {element.id for element in model.elements}
    for coupling_id, coupling in model.couplings.items():
        if coupling.kind == "pipe_to_solid_port":
            if coupling.code_aster_keyword != "LIAISON_ELEM":
                errors.append(
                    f"Coupling {coupling_id!r} pipe_to_solid_port must use Code_Aster keyword "
                    "'LIAISON_ELEM'."
                )
            if coupling.code_aster_option not in _PIPE_TO_PORT_OPTIONS:
                errors.append(
                    f"Coupling {coupling_id!r} has unsupported pipe-to-port option "
                    f"{coupling.code_aster_option!r}."
                )

        if coupling.source.kind != "element":
            errors.append(
                f"Coupling {coupling_id!r} source must be an element, got {coupling.source.kind!r}."
            )
        elif coupling.source.id not in element_ids:
            errors.append(
                f"Coupling {coupling_id!r} references missing source element {coupling.source.id!r}."
            )

        if coupling.source_node.kind != "node":
            errors.append(
                f"Coupling {coupling_id!r} source node must be a node, got {coupling.source_node.kind!r}."
            )
        elif coupling.source_node.id not in model.nodes:
            errors.append(
                f"Coupling {coupling_id!r} references missing source node {coupling.source_node.id!r}."
            )

        if coupling.target.kind != "port":
            errors.append(f"Coupling {coupling_id!r} target must be a port, got {coupling.target.kind!r}.")
        else:
            try:
                port = resolve_entity_ref(model, coupling.target)
            except KeyError:
                errors.append(
                    f"Coupling {coupling_id!r} references missing target port {coupling.target.id!r}."
                )
            else:
                if port.status != "confirmed":
                    errors.append(
                        f"Coupling {coupling_id!r} target port {coupling.target.id!r} is not confirmed."
                    )

        if (
            coupling.kind == "pipe_to_solid_port"
            and coupling.code_aster_keyword == "LIAISON_ELEM"
            and coupling.code_aster_option == "3D_TUYAU"
        ):
            _validate_pipe_to_solid_port(model, coupling_id, coupling, errors)


def _validate_pipe_to_solid_port(
    model: TubaModel,
    coupling_id: str,
    coupling: Any,
    errors: list[str],
) -> None:
    if (
        coupling.source.kind != "element"
        or coupling.source_node.kind != "node"
        or coupling.target.kind != "port"
    ):
        return

    try:
        source = resolve_entity_ref(model, coupling.source)
    except KeyError:
        return
    source_node_id = coupling.source_node.id
    if source.type not in {"pipe_straight", "pipe_bend"}:
        errors.append(
            f"Coupling {coupling_id!r} source element {source.id!r} must be pipe_straight or pipe_bend "
            f"for 3D_TUYAU."
        )

    if source_node_id not in {source.n1, source.n2}:
        errors.append(
            f"Coupling {coupling_id!r} source node {source_node_id!r} must be endpoint of element {source.id!r}."
        )

    try:
        port = resolve_entity_ref(model, coupling.target)
    except KeyError:
        return

    has_solid_region = any(
        region.owner == port.owner and region.role == "solid_3d"
        for region in model.analysis_regions.values()
    )
    if not has_solid_region:
        errors.append(
            f"Coupling {coupling_id!r} target port {coupling.target.id!r} has no solid_3d analysis region owner."
        )

    section = model.sections.get(source.section)
    if section is None:
        return
    if not hasattr(section, "OD"):
        errors.append(
            f"Coupling {coupling_id!r} source section {source.section!r} has no OD for diameter comparison."
        )
        return

    if not _number(section.OD, f"Coupling {coupling_id!r} section {source.section!r} OD",
                   errors, lower=0, open_lower=True):
        return
    pipe_radius = float(section.OD) / 2.0
    tolerance = max(0.001, pipe_radius * 0.02)
    if abs(pipe_radius - port.radius) > tolerance:
        errors.append(
            f"Coupling {coupling_id!r} pipe/port diameter mismatch for "
            f"{source.id!r} and {port.id!r}."
        )
