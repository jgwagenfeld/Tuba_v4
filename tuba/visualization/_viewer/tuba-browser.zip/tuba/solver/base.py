"""
tuba.solver.base — Abstract solver interface and result containers.

These types carry parsed Code_Aster results into compliance and display paths.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

import numpy as np

from tuba.analysis.buckling import BucklingResult


# ---------------------------------------------------------------------------
# Result containers
# ---------------------------------------------------------------------------

@dataclass
class NodeResult:
    """Per-node result quantities."""

    node_id: str
    displacement: np.ndarray  # shape (6,) — ux, uy, uz, rx, ry, rz
    reaction_force: Optional[np.ndarray] = None  # shape (6,) — Fx, Fy, Fz, Mx, My, Mz


@dataclass
class ElementResult:
    """Per-element result quantities (at each end-node)."""

    element_id: str
    # Internal forces at node 1 (start)
    forces_n1: np.ndarray  # shape (6,) — N, Vy, Vz, Mx, My, Mz
    # Internal forces at node 2 (end)
    forces_n2: np.ndarray  # shape (6,)
    # Stress scalars
    von_mises_n1: float = float("nan")
    von_mises_n2: float = float("nan")
    max_von_mises: float = float("nan")
    # A beam's extreme fibre normal stress, |axial| + bending, over every solver
    # node of the member (Code_Aster SIPO_ELNO; see parse_sipo_table).
    max_normal_stress: float = float("nan")


@dataclass(frozen=True)
class ContactResult:
    """One solved support state, SI units (N, m); global forces act on the pipe.

    ``normal`` is the outward unit normal; ``slip`` is accumulated native
    tangential slip, distinct from total relative displacement.
    """

    support_id: str
    node_id: str
    status: str
    normal: tuple[float, float, float]
    normal_force: float
    tangential_force: tuple[float, float, float]
    gap: float
    relative_displacement: tuple[float, float, float]
    slip: tuple[float, float, float]
    friction_limit: float
    utilization: float | None
    status_source: str

    def __post_init__(self) -> None:
        for name in ("support_id", "node_id"):
            if not isinstance(getattr(self, name), str) or not getattr(self, name).strip():
                raise ValueError(f"ContactResult {name} must be a nonempty string.")
        if self.status not in {"open", "sticking", "sliding", "indeterminate"}:
            raise ValueError("ContactResult status is invalid.")
        if self.status_source not in {"solver", "derived"}:
            raise ValueError("ContactResult status_source must be solver or derived.")
        for name in ("normal", "tangential_force", "relative_displacement", "slip"):
            values = tuple(float(value) for value in getattr(self, name))
            if len(values) != 3 or not np.isfinite(values).all():
                raise ValueError(f"ContactResult {name} must contain three finite values.")
            object.__setattr__(self, name, values)
        if not np.isclose(np.linalg.norm(self.normal), 1.0, rtol=0.0, atol=1e-8):
            raise ValueError("ContactResult normal must be a unit vector.")
        for name in ("normal_force", "gap", "friction_limit", "utilization"):
            value = getattr(self, name)
            if name == "utilization" and value is None:
                continue
            value = float(value)
            if not np.isfinite(value):
                raise ValueError(f"ContactResult {name} must be finite.")
            object.__setattr__(self, name, value)
        if self.friction_limit < 0 or (self.utilization is not None and self.utilization < 0):
            raise ValueError("ContactResult friction_limit and utilization must be non-negative.")

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "ContactResult":
        return cls(**data)


@dataclass
class FEAResults:
    """Container holding the full set of results from a solver run.

    Provides convenience accessors used by the compliance evaluator and
    the visualiser.
    """

    solver_name: str
    load_case: Optional[str] = None

    node_results: Dict[str, NodeResult] = field(default_factory=dict)
    element_results: Dict[str, ElementResult] = field(default_factory=dict)
    analysis_node_results: Dict[str, NodeResult] = field(default_factory=dict)
    # Detailed per-cross-section FE fibre stress (von Mises) at TUYAU sub-points,
    # for visualization only; it is not a piping-code compliance result.
    tuyau_subpoints: List[Dict[str, Any]] = field(default_factory=list)
    volume_von_mises: Dict[str, float] = field(default_factory=dict)
    parser_diagnostics: List[str] = field(default_factory=list)

    # Path to the raw result file (e.g. .rmed)
    result_file: Optional[Path] = None

    # Reference to original model for visualization, SIFs, etc.
    _model: Optional[Any] = None

    contact_results: dict[str, ContactResult] = field(default_factory=dict)
    metadata: dict[str, Any] = field(default_factory=dict)
    #: Linear buckling eigenproblem solved on this load case's own prestress, when
    #: the case was declared with ``buckling=``. Absent otherwise; never a stand-in.
    buckling: BucklingResult | None = None
    #: Files the buckling results were read from, so a persistent record can name
    #: the artifacts a reviewer must be able to reopen.
    buckling_artifacts: Dict[str, Path] = field(default_factory=dict)

    # ------------------------------------------------------------------
    # Accessors
    # ------------------------------------------------------------------

    def get_displacement(self, node_id: str) -> np.ndarray:
        return self.node_results[node_id].displacement

    def get_analysis_displacement(self, node_id: str) -> np.ndarray:
        return self.analysis_node_results[node_id].displacement

    def get_reaction(self, node_id: str) -> Optional[np.ndarray]:
        nr = self.node_results.get(node_id)
        return nr.reaction_force if nr else None

    def get_forces(self, element_id: str) -> Dict[str, np.ndarray]:
        er = self.element_results[element_id]
        return {"n1": er.forces_n1, "n2": er.forces_n2}

    def get_max_von_mises(self, element_id: str) -> float:
        return self.element_results[element_id].max_von_mises

    # ------------------------------------------------------------------
    # Visualisation shortcuts (delegate to tuba.plotting)
    # ------------------------------------------------------------------

    def plot_deformed(self, scale: float = 50.0, show_undeformed: bool = True, **kwargs):
        """Show the deformed pipe shape."""
        from tuba.plotting.plots import plot_deformed
        return plot_deformed(self, scale=scale, show_undeformed=show_undeformed, **kwargs)

    def plot_stress(self, cmap: str = "jet", **kwargs):
        """Color-map Von Mises stress on the pipe surface."""
        from tuba.plotting.plots import plot_stress
        return plot_stress(self, cmap=cmap, **kwargs)

    def plot_displacement_vectors(self, scale: float = 50.0, **kwargs):
        """Show displacement arrow glyphs."""
        from tuba.plotting.plots import plot_displacement_vectors
        return plot_displacement_vectors(self, scale=scale, **kwargs)

    def plot_reactions(self, scale: float | str = "auto", **kwargs):
        """Show reaction force arrow glyphs at supports."""
        from tuba.plotting.plots import plot_reactions
        return plot_reactions(self, scale=scale, **kwargs)

    def plot_temperature(self, cmap: str = "coolwarm", **kwargs):
        """Color-map temperature distribution."""
        from tuba.plotting.plots import plot_temperature
        return plot_temperature(self, cmap=cmap, **kwargs)

    def plot_deformed_stress(
        self,
        deform_scale: float = 50.0,
        cmap: str = "turbo",
        export_html: Optional[str] = None,
        **kwargs,
    ):
        """Combined deformed shape colored by Von Mises stress — the primary view."""
        from tuba.plotting.plots import plot_deformed_stress
        return plot_deformed_stress(
            self,
            deform_scale=deform_scale,
            cmap=cmap,
            export_html=export_html,
            **kwargs,
        )

    def export_ply(self, path: str):
        """Export tubes with vertex-color stress to PLY for Blender."""
        from tuba.plotting.export import export_ply
        export_ply(self, path)

    def export_gltf(self, path: str):
        """Export to glTF for universal 3-D viewing."""
        from tuba.plotting.export import export_gltf
        export_gltf(self, path)
