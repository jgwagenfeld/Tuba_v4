"""tuba.solver.aster_comm — Code_Aster command file (.comm) generation.

Split out of tuba.solver.aster (behaviour-preserving). ``_CommWriterMixin`` is
mixed into ``CodeAsterSolver`` and keeps ``self`` access to mesh helpers.
"""
from __future__ import annotations

import logging
import math
from pathlib import Path
from typing import Callable, Dict, List

import numpy as np
from tuba.physical import _fluid_density_by_element, _physical_properties_for_element
from tuba.solver.aster_buckling import write_buckling_analysis
from tuba.solver.aster_contact import shoes, write_contact_solve, write_contact_tables, write_shoe_anchor, write_tie
from tuba.solver.code_aster_runtime import write_artifact_text

from tuba.model import (
    BarSection,
    CableSection,
    IBeamSection,
    LoadCase,
    PipeSection,
    RectangularSection,
    TubaModel,
    resolve_buckling_options,
)
from tuba.solver.modelisation import (
    discrete_support_group,
    modelisation_assignments,
    PipeModelization,
    needs_discrete_element,
    spring_links,
)
from tuba.solver.aster_loads import (
    group_ma_value,
    has_pressure_load,
    has_temperature_load as has_thermal_load,
    has_wind_load,
    node_temperature_entries,
    resolve_line_load_groups,
    resolve_operation_field_groups,
    resolve_wind_field_groups,
    tuyau_wind_rows,
    write_line_load,
    write_pressure_load,
    write_thermal_load,
    write_tuyau_wind_load,
    write_wind_load,
)

logger = logging.getLogger(__name__)


def _held_dofs(support) -> list[str]:
    """The DOFs a two-way support holds: every axis its restraint fixes (one projection of it)."""
    names = ["DX", "DY", "DZ", "DRX", "DRY", "DRZ"]
    return [name for name, state in zip(names, support.restraint().states) if state == "fixed"]


def _spring_stiffness(support) -> list[float]:
    """The six global stiffnesses [Kx, Ky, Kz, Krx, Kry, Krz] of a spring support."""
    return list(support.restraint().spring_stiffness)


def _pipe_orientation_vector(model: TubaModel, pipe_straights: list, pipe_bends: list) -> tuple[float, float, float]:
    directions = []
    for elem in pipe_straights:
        directions.append(np.asarray(model.nodes[elem.n2].coords, dtype=float) - np.asarray(model.nodes[elem.n1].coords, dtype=float))
    for elem in pipe_bends:
        if elem.bend_geometry is not None:
            directions.append(np.asarray(elem.bend_geometry.start_tangent, dtype=float))
            directions.append(np.asarray(elem.bend_geometry.end_tangent, dtype=float))
        else:
            directions.append(np.asarray(model.nodes[elem.n2].coords, dtype=float) - np.asarray(model.nodes[elem.n1].coords, dtype=float))

    unit_directions = []
    for direction in directions:
        norm = float(np.linalg.norm(direction))
        if norm > 1e-12:
            unit_directions.append(direction / norm)

    if not unit_directions:
        return (0.0, 0.0, 1.0)

    candidates = [
        (0.0, 0.0, 1.0),
        (0.0, 1.0, 0.0),
        (1.0, 0.0, 0.0),
        (1.0, 1.0, 1.0),
        (1.0, -1.0, 1.0),
        (1.0, 2.0, 3.0),
    ]
    for candidate in candidates:
        vector = np.asarray(candidate, dtype=float)
        vector_norm = float(np.linalg.norm(vector))
        if vector_norm <= 1e-12:
            continue
        unit_vector = vector / vector_norm
        if all(float(np.linalg.norm(np.cross(unit_vector, direction))) > 1e-8 for direction in unit_directions):
            return candidate

    for x in range(-3, 4):
        for y in range(-3, 4):
            for z in range(-3, 4):
                vector = np.asarray((float(x), float(y), float(z)), dtype=float)
                vector_norm = float(np.linalg.norm(vector))
                if vector_norm <= 1e-12:
                    continue
                unit_vector = vector / vector_norm
                if all(float(np.linalg.norm(np.cross(unit_vector, direction))) > 1e-8 for direction in unit_directions):
                    return (float(x), float(y), float(z))

    return (1.0, 2.0, 3.0)


class _CommWriterMixin:
    def _write_comm(
        self,
        model: TubaModel,
        load_case: LoadCase,
        path: Path,
        *,
        name_map: Callable[[str], str] | None = None,
    ) -> None:
        """Generate the Code_Aster command file for static piping analysis.

        Uses ``MODELISATION='TUYAU_3M'`` for pipe elements, ``'POU_D_T'`` for beams,
        ``'BARRE'`` for bars, and ``'CABLE'`` for cables.
        """
        pipe_straights = [e for e in model.elements if e.type == "pipe_straight"]
        pipe_bends = [e for e in model.elements if e.type == "pipe_bend"]
        beam_elems = [e for e in model.elements if e.type == "beam"]
        bar_elems = [e for e in model.elements if e.type == "bar"]
        cable_elems = [e for e in model.elements if e.type == "cable"]
        beam_pipes = self.pipe_modelization is PipeModelization.POU_D_T
        has_pipe_stress = bool(pipe_straights or pipe_bends) and not beam_pipes

        straight_elems = pipe_straights + beam_elems + bar_elems + cable_elems
        bend_elems = pipe_bends
        map_name = name_map or (lambda value: value)
        contacts = shoes(model, self.pipe_modelization)
        links = spring_links(model)
        native_path = self.load_path is not None
        if native_path and (not beam_pipes or cable_elems):
            raise ValueError('Native contact load paths require beam piping without cables.')

        # Collect unique materials referenced by elements
        used_mat_names = sorted({e.material for e in model.elements})
        cable_mats = {e.material for e in model.elements if e.type == "cable"}

        # Collect unique sections
        used_sec_names = sorted({e.section for e in model.elements})

        # Check for POI1 requirements (discrete springs or masses)
        has_poi1 = any(needs_discrete_element(s) for s in model.supports)

        # Shoes and cables are nonlinear by construction. A shoe opens and
        # closes (every rest is one, and friction exists only on rests). A cable
        # carries no compression and starts from N_INIT, so MECA_STATIQUE would
        # solve it as a bar that pushes back and drops the pretension entirely.
        is_nonlinear = bool(contacts) or bool(cable_elems)

        comm: List[str] = []

        def w(text: str = "") -> None:
            """Append a line."""
            comm.append(text)

        # ==============================================================
        # DEBUT
        # ==============================================================
        w("DEBUT(PAR_LOT='NON');")
        w()

        # ==============================================================
        # LIRE_MAILLAGE / CREA_MAILLAGE
        # ==============================================================
        w("# ----- Read mesh -----")
        w("MAIL0 = LIRE_MAILLAGE(FORMAT='ASTER',")
        w("                      UNITE=20);")
        w()

        if has_poi1:
            w("# ----- Create POI1 elements for discrete springs/masses -----")
            w("MAIL = CREA_MAILLAGE(")
            w("    MAILLAGE=MAIL0,")
            w("    CREA_POI1=(")
            for s in model.supports:
                if needs_discrete_element(s):
                    w(f"        _F(NOM_GROUP_MA='{map_name(discrete_support_group(s.node))}', GROUP_NO='{map_name(f'GN_{s.node}')}'),")
            w("    ),")
            w(");")
        else:
            w("MAIL = MAIL0;")
        w()

        # ==============================================================
        # AFFE_MODELE
        # ==============================================================
        w("# ----- Model definition -----")
        w("MODELE = AFFE_MODELE(")
        w("    MAILLAGE=MAIL,")
        w("    AFFE=(")
        for group_name, modelisation in modelisation_assignments(model, self.pipe_modelization).items():
            w("        _F(")
            w(f"            GROUP_MA='{map_name(group_name)}',")
            w("            PHENOMENE='MECANIQUE',")
            w(f"            MODELISATION='{modelisation}',")
            w("        ),")
        w("    ),")
        w(");")
        w()

        # ==============================================================
        # DEFI_MATERIAU
        # ==============================================================
        w("# ----- Material definitions -----")
        for mat_name in used_mat_names:
            mat = model.materials[mat_name]
            var = f"MAT_{mat_name.upper().replace(' ', '_').replace('-', '_')}"
            w(f"{var} = DEFI_MATERIAU(")
            w(f"    ELAS=_F(")
            w(f"        E={mat.E:.6E},")
            w(f"        NU={mat.nu:.6E},")
            w(f"        RHO={mat.rho:.6E},")
            w(f"        ALPHA={mat.alpha:.6E},")
            w(f"    ),")
            if mat_name in cable_mats:
                # EC_SUR_E is a material property in Code_Aster but a
                # per-cable modelling choice here, so a material shared by two
                # idealisations has no single answer and must say so.
                ratios = {
                    section.compression_modulus_ratio
                    for section in model.sections.values()
                    if isinstance(section, CableSection)
                    and any(
                        e.section == section.name and e.material == mat_name
                        for e in model.elements
                        if e.type == "cable"
                    )
                }
                if len(ratios) > 1:
                    raise ValueError(
                        f"Material {mat_name!r} carries cable sections with different "
                        f"compression modulus ratios {sorted(ratios)}; EC_SUR_E is a "
                        "material property, so give each idealisation its own material."
                    )
                w(f"    CABLE=_F(EC_SUR_E={ratios.pop() if ratios else 1.0}),")
            w(f");")
            w()

        for index, contact in enumerate(contacts):
            w(f"CM{index} = DEFI_MATERIAU(DIS_CONTACT=_F(RIGI_NOR={contact.kn!r},RIGI_TAN={contact.kt!r},COULOMB={contact.support.friction_coefficient!r},DIST_1=1.0))")

        # ==============================================================
        # AFFE_MATERIAU
        # ==============================================================
        w("# ----- Material assignment -----")

        material_element_groups: Dict[str, List[str]] = {}
        for elem in model.elements:
            if elem.type == "pipe_bend":
                material_element_groups.setdefault(elem.material, []).extend(
                    f"{elem.id}_s{i}" for i in range(self._BEND_SEGMENTS)
                )
            else:
                material_element_groups.setdefault(elem.material, []).append(elem.id)

        delta_t = load_case.temperature - load_case.ref_temperature
        pressure_fields = resolve_operation_field_groups(model, load_case, "pressure")
        temperature_fields = resolve_operation_field_groups(model, load_case, "temperature")
        node_temperatures = node_temperature_entries(model, load_case, temperature_fields, self._element_solver_nodes)
        wind_fields = resolve_wind_field_groups(model, load_case)
        # Wind reaches Code_Aster through the command its element's modelization
        # accepts: VENT on beam-modelled elements, Tuba's cross-flow rule on
        # TUYAU_3M pipes, which refuse VENT.
        element_types = {element.id: element.type for element in model.elements}
        beam_winds = [row for row in wind_fields if beam_pipes or element_types[row[0][0]] == "beam"]
        tuyau_winds = tuyau_wind_rows(
            model,
            [row for row in wind_fields if not (beam_pipes or element_types[row[0][0]] == "beam")],
            lambda element: self._get_bend_geometry(model, element)[:2],
        )
        line_loads = resolve_line_load_groups(model, load_case)
        nodal_forces = list(getattr(load_case, "nodal_forces", []))
        has_pressure = has_pressure_load(load_case, pressure_fields)
        has_temperature = has_thermal_load(load_case, temperature_fields, node_temperatures)
        has_wind = has_wind_load(beam_winds)
        has_tuyau_wind = bool(tuyau_winds)
        has_line_load = bool(line_loads)
        has_nodal_forces = bool(nodal_forces)

        affe_entries: List[str] = []
        all_material_element_ids = {
            element_id
            for element_ids in material_element_groups.values()
            for element_id in element_ids
        }
        for mat_name, element_ids in material_element_groups.items():
            var = f"MAT_{mat_name.upper().replace(' ', '_').replace('-', '_')}"
            if set(element_ids) == all_material_element_ids and not contacts:
                group_spec = "TOUT='OUI',"
            else:
                group_spec = f"GROUP_MA='{map_name(self._material_group_name(mat_name))}',"
            affe_entries.append(
                f"        _F(\n"
                f"            {group_spec}\n"
                f"            MATER={var},\n"
                f"        ),"
            )

        # Carry non-structural insulation mass on the steel section. E, NU,
        # ALPHA and wall geometry stay unchanged; RHO supplies static gravity.
        fluid_densities = _fluid_density_by_element(model, load_case)
        for index, elem in enumerate(model.elements):
            if model.get_insulation(f"element:{elem.id}") is None and not fluid_densities.get(elem.id):
                continue
            props = _physical_properties_for_element(model, elem, fluid_densities.get(elem.id, 0.0))
            if load_case.gravity and props.insulation_thickness_m > 0 and props.insulation_mass_kg_per_m <= 0:
                raise ValueError(f"Insulation on {elem.id!r} requires a positive density for gravity loading.")
            if props.insulation_mass_kg_per_m + props.fluid_mass_kg_per_m <= 0:
                continue
            mat = model.materials[elem.material]
            density = props.mass_kg_per_m / props.metal_area_m2
            var = f"IM{index}"
            w(f"# Insulation mass for {elem.id}: {props.insulation_mass_kg_per_m:.12E} kg/m")
            if props.fluid_mass_kg_per_m:
                w(f"# Fluid contents mass for {elem.id}: {props.fluid_mass_kg_per_m:.12E} kg/m")
            w(f"{var} = DEFI_MATERIAU(ELAS=_F(E={mat.E:.12E}, NU={mat.nu:.12E}, "
              f"RHO={density:.12E}, ALPHA={mat.alpha:.12E}));")
            affe_entries.append(f"        _F(GROUP_MA='{map_name(elem.id)}', MATER={var}),")

        for index, contact in enumerate(contacts):
            affe_entries.append(f"_F(GROUP_MA='{map_name(contact.group)}',MATER=CM{index}),")
        w("CHMAT = AFFE_MATERIAU(")
        w("    MAILLAGE=MAIL,")
        w("    AFFE=(")
        for entry in affe_entries:
            w(entry)
        w("    ),")
        w(");")
        w()

        # ==============================================================
        # AFFE_CARA_ELEM
        # ==============================================================
        w("# ----- Cross-section properties -----")
        w("CARA = AFFE_CARA_ELEM(")
        w("    MODELE=MODELE,")

        # POUTRE entries for pipes and beams
        poutre_entries: List[str] = []
        for sec_name in used_sec_names:
            sec = model.sections[sec_name]
            sec_straights = [e.id for e in straight_elems if e.section == sec_name and e.type in ("pipe_straight", "beam")]
            
            if sec_straights:
                section_group = f"'{map_name(self._section_group_name(sec_name))}'"
                
                if isinstance(sec, PipeSection) or isinstance(sec, BarSection):
                    r_ext = sec.OD / 2.0
                    ep = sec.WT
                    poutre_entries.append(
                        f"        _F(\n"
                        f"            GROUP_MA={section_group},\n"
                        f"            SECTION='CERCLE',\n"
                        f"            CARA=('R', 'EP'),\n"
                        f"            VALE=({r_ext:.8E}, {ep:.8E}),\n"
                        f"        ),"
                    )
                elif isinstance(sec, RectangularSection):
                    h_y = sec.height_y
                    h_z = sec.height_z
                    t_y = sec.thickness_y
                    t_z = sec.thickness_z
                    if t_y == 0.0 and t_z == 0.0:
                        poutre_entries.append(
                            f"        _F(\n"
                            f"            GROUP_MA={section_group},\n"
                            f"            SECTION='RECTANGLE',\n"
                            f"            CARA=('HY', 'HZ'),\n"
                            f"            VALE=({h_y:.8E}, {h_z:.8E}),\n"
                            f"        ),"
                        )
                    else:
                        poutre_entries.append(
                            f"        _F(\n"
                            f"            GROUP_MA={section_group},\n"
                            f"            SECTION='RECTANGLE',\n"
                            f"            CARA=('HY', 'HZ', 'EPY', 'EPZ'),\n"
                            f"            VALE=({h_y:.8E}, {h_z:.8E}, {t_y:.8E}, {t_z:.8E}),\n"
                            f"        ),"
                        )
                elif isinstance(sec, IBeamSection):
                    p = sec.properties
                    beamCaraStr = ['A','IY','IZ','AY','AZ','EY','EZ','JX','JG','IYR2','IZR2','RY','RZ','RT']
                    vals = [p.get(k, 0.0) for k in beamCaraStr]
                    poutre_entries.append(
                        f"        _F(\n"
                        f"            GROUP_MA={section_group},\n"
                        f"            SECTION='GENERALE',\n"
                        f"            CARA=({', '.join(repr(k) for k in beamCaraStr)}),\n"
                        f"            VALE=({', '.join(f'{v:.8E}' for v in vals)}),\n"
                        f"        ),"
                    )

        for elem in bend_elems:
            sec = model.sections[elem.section]
            r_ext = sec.OD / 2.0
            ep = sec.WT
            bend_group = f"'{map_name(elem.id)}'"
            poutre_entries.append(
                f"        _F(\n"
                f"            GROUP_MA={bend_group},\n"
                f"            SECTION='CERCLE',\n"
                f"            CARA=('R', 'EP'),\n"
                f"            VALE=({r_ext:.8E}, {ep:.8E}),\n"
                f"        ),"
            )
            if beam_pipes:
                from tuba.solver.flexibility import elbow_flexibility

                flexibility = elbow_flexibility(elem, model)
                if flexibility is None:
                    raise ValueError("POU_D_T requires a qualified isotropic elbow flexibility factor.")
                # U4.42.01: COEF_FLEX divides I by k. A flexibility factor is
                # not a stress intensification factor and is never used as one.
                poutre_entries.append(
                    f"        _F(GROUP_MA={bend_group}, SECTION='COUDE', "
                    f"COEF_FLEX={flexibility.k:.10E}),"
                )
            else:
                poutre_entries.append(f"        _F(GROUP_MA={bend_group}, SECTION='COUDE'),")

        if poutre_entries:
            w("    POUTRE=(")
            for entry in poutre_entries:
                w(entry)
            w("    ),")

        # BARRE entries
        barre_entries: List[str] = []
        for sec_name in used_sec_names:
            sec = model.sections[sec_name]
            sec_bars = [e.id for e in straight_elems if e.section == sec_name and e.type == "bar"]
            if sec_bars:
                group_list = ", ".join(f"'{map_name(eid)}'" for eid in sec_bars)
                grp = f"({group_list})" if len(sec_bars) > 1 else f"'{map_name(sec_bars[0])}'"
                r_ext = sec.OD / 2.0
                ep = sec.WT if hasattr(sec, "WT") else 0.0
                if ep == 0.0:
                    ep = r_ext  # Solid bar
                barre_entries.append(
                    f"        _F(\n"
                    f"            GROUP_MA={grp},\n"
                    f"            SECTION='CERCLE',\n"
                    f"            CARA=('R', 'EP'),\n"
                    f"            VALE=({r_ext:.8E}, {ep:.8E}),\n"
                    f"        ),"
                )
        if barre_entries:
            w("    BARRE=(")
            for entry in barre_entries:
                w(entry)
            w("    ),")

        # CABLE entries
        cable_entries: List[str] = []
        for sec_name in used_sec_names:
            sec = model.sections[sec_name]
            sec_cables = [e.id for e in straight_elems if e.section == sec_name and e.type == "cable"]
            if sec_cables:
                group_list = ", ".join(f"'{map_name(eid)}'" for eid in sec_cables)
                grp = f"({group_list})" if len(sec_cables) > 1 else f"'{map_name(sec_cables[0])}'"
                area = sec.area
                pret = sec.pretension
                cable_entries.append(
                    f"        _F(\n"
                    f"            GROUP_MA={grp},\n"
                    f"            SECTION={area:.8E},\n"
                    f"            N_INIT={pret:.8E},\n"
                    f"        ),"
                )
        if cable_entries:
            w("    CABLE=(")
            for entry in cable_entries:
                w(entry)
            w("    ),")

        # DISCRET entries for springs/masses
        discret_entries: List[str] = []
        for contact in contacts:
            discret_entries.append(f"_F(GROUP_MA='{map_name(contact.group)}',REPERE='LOCAL',CARA='K_T_D_L',VALE=(0.,0.,0.)),")
        for s in model.supports:
            if s.type == "spring" and s.attached_to is None and (s.stiffness_matrix is not None or s.stiffness is not None):
                k = _spring_stiffness(s)
                discret_entries.append(
                    f"        _F(\n"
                    f"            GROUP_MA='{map_name(f'DIS_{s.node}')}',\n"
                    f"            REPERE='GLOBAL',\n"
                    f"            CARA='K_TR_D_N',\n"
                    f"            VALE=({k[0]:.8E}, {k[1]:.8E}, {k[2]:.8E}, {k[3]:.8E}, {k[4]:.8E}, {k[5]:.8E}),\n"
                    f"        ),"
                )
                if s.mass <= 0.0:
                    discret_entries.append(
                        f"        _F(\n"
                        f"            GROUP_MA='{map_name(f'DIS_{s.node}')}',\n"
                        f"            CARA='M_TR_D_N',\n"
                        f"            VALE=(0.00000000E+00, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),\n"
                        f"        ),"
                    )
            if s.mass > 0.0:
                discret_entries.append(
                    f"        _F(\n"
                    f"            GROUP_MA='{map_name(f'DIS_{s.node}')}',\n"
                    f"            CARA='M_TR_D_N',\n"
                    f"            VALE=({s.mass:.8E}, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0),\n"
                    f"        ),"
                )
        for link in links:
            k = _spring_stiffness(link.support)
            discret_entries.append(
                f"        _F(\n"
                f"            GROUP_MA='{map_name(link.group)}',\n"
                f"            REPERE='GLOBAL',\n"
                f"            CARA='K_TR_D_L',\n"
                f"            VALE=({k[0]:.8E}, {k[1]:.8E}, {k[2]:.8E}, {k[3]:.8E}, {k[4]:.8E}, {k[5]:.8E}),\n"
                f"        ),"
            )
        if discret_entries:
            w("    DISCRET=(")
            for entry in discret_entries:
                w(entry)
            w("    ),")

        # Orientation
        orientation_entries: List[str] = []
        for contact in contacts:
            orientation_entries.append(f"_F(GROUP_MA='{map_name(contact.group)}',CARA='VECT_Y',VALE={contact.tangent!r}),")
        if (pipe_straights or pipe_bends) and not beam_pipes:
            orientation = _pipe_orientation_vector(model, pipe_straights, pipe_bends)
            orientation_entries.append(
                "        _F(\n"
                f"            GROUP_NO='{map_name('PipeOrientationNodes')}',\n"
                "            CARA='GENE_TUYAU',\n"
                f"            VALE=({orientation[0]:.8E}, {orientation[1]:.8E}, {orientation[2]:.8E}),\n"
                "        ),"
            )
        if beam_pipes:
            for elem in pipe_straights + pipe_bends:
                orientation_entries.append(
                    f"        _F(GROUP_MA='{map_name(elem.id)}', CARA='ANGL_VRIL', VALE=0.0),"
                )
        if beam_elems:
            for elem in beam_elems:
                angle = getattr(elem, "twist_angle", 0.0)
                orientation_entries.append(
                    f"        _F(\n"
                    f"            GROUP_MA='{map_name(elem.id)}',\n"
                    f"            CARA='ANGL_VRIL',\n"
                    f"            VALE={angle:.4f},\n"
                    f"        ),"
                )
        if orientation_entries:
            w("    ORIENTATION=(")
            for entry in orientation_entries:
                w(entry)
            w("    ),")

        w(");")
        w()


        # ==============================================================
        # AFFE_CHAR_MECA — supports
        # ==============================================================
        w("# ----- Boundary conditions -----")
        active_bcs = []
        pipe_nodes_with_warping = {
            node_id
            for elem in ([] if beam_pipes else pipe_straights + pipe_bends)
            for node_id in (elem.n1, elem.n2)
        }

        def append_pipe_warping_bc(lines: list[str], node_id: str) -> None:
            if node_id in pipe_nodes_with_warping:
                lines.append("        WO=0.0,")

        for i, sup in enumerate(model.supports):
            grp_name = map_name(f"GN_{sup.node}")
            char_name = f"BC_{i}"

            if sup.attached_to is not None and sup.type not in ("rest", "spring"):
                dofs = _held_dofs(sup)
                if not dofs:
                    continue
                other = map_name(f"GN_{sup.attached_to}")
                w(f"{char_name} = AFFE_CHAR_MECA(")
                w("    MODELE=MODELE,")
                w("    LIAISON_DDL=(")
                for dof in dofs:
                    w(f"        _F(GROUP_NO=('{grp_name}', '{other}'), DDL=('{dof}', '{dof}'), COEF_MULT=(1.0, -1.0), COEF_IMPO=0.0),")
                w("    ),")
                if sup.node in pipe_nodes_with_warping:
                    w("    DDL_IMPO=_F(")
                    w(f"        GROUP_NO='{grp_name}',")
                    w("        WO=0.0,")
                    w("    ),")
                w(");")
                w()
                active_bcs.append(char_name)
                continue

            write_bc = False
            lines_bc = []

            if sup.blocked_dof is not None:
                blocked = _held_dofs(sup)
                if blocked:
                    write_bc = True
                    lines_bc.append(f"{char_name} = AFFE_CHAR_MECA(")
                    lines_bc.append(f"    MODELE=MODELE,")
                    lines_bc.append(f"    DDL_IMPO=_F(")
                    lines_bc.append(f"        GROUP_NO='{grp_name}',")
                    for dof in blocked:
                        lines_bc.append(f"        {dof}=0.0,")
                    append_pipe_warping_bc(lines_bc, sup.node)
                    lines_bc.append(f"    ),")
                    lines_bc.append(f");")
            else:
                if sup.type == "anchor":
                    write_bc = True
                    lines_bc.append(f"{char_name} = AFFE_CHAR_MECA(")
                    lines_bc.append(f"    MODELE=MODELE,")
                    lines_bc.append(f"    DDL_IMPO=_F(")
                    lines_bc.append(f"        GROUP_NO='{grp_name}',")
                    lines_bc.append(f"        BLOCAGE=('DEPLACEMENT', 'ROTATION'),")
                    append_pipe_warping_bc(lines_bc, sup.node)
                    lines_bc.append(f"    ),")
                    lines_bc.append(f");")
                elif sup.type == "guide":
                    write_bc = True
                    lines_bc.append(f"{char_name} = AFFE_CHAR_MECA(")
                    lines_bc.append(f"    MODELE=MODELE,")
                    lines_bc.append(f"    DDL_IMPO=_F(")
                    lines_bc.append(f"        GROUP_NO='{grp_name}',")
                    for dof in _held_dofs(sup):
                        lines_bc.append(f"        {dof}=0.0,")
                    append_pipe_warping_bc(lines_bc, sup.node)
                    lines_bc.append(f"    ),")
                    lines_bc.append(f");")
                elif sup.type == "rest":
                    # A rest is a contact shoe (aster_contact.shoes), never a
                    # bilateral DDL_IMPO. It still owes the warping restraint every
                    # support gets: a TUYAU node needs WO fixed; a beam node has none.
                    if sup.node not in pipe_nodes_with_warping:
                        continue
                    write_bc = True
                    lines_bc.append(f"{char_name} = AFFE_CHAR_MECA(")
                    lines_bc.append(f"    MODELE=MODELE,")
                    lines_bc.append(f"    DDL_IMPO=_F(")
                    lines_bc.append(f"        GROUP_NO='{grp_name}',")
                    append_pipe_warping_bc(lines_bc, sup.node)
                    lines_bc.append(f"    ),")
                    lines_bc.append(f");")
                elif sup.type == "spring":
                    pass
                else:
                    write_bc = True
                    lines_bc.append(f"{char_name} = AFFE_CHAR_MECA(")
                    lines_bc.append(f"    MODELE=MODELE,")
                    lines_bc.append(f"    DDL_IMPO=_F(")
                    lines_bc.append(f"        GROUP_NO='{grp_name}',")
                    for dof in _held_dofs(sup):
                        lines_bc.append(f"        {dof}=0.0,")
                    append_pipe_warping_bc(lines_bc, sup.node)
                    lines_bc.append(f"    ),")
                    lines_bc.append(f");")

            if write_bc:
                for line in lines_bc:
                    w(line)
                w()
                active_bcs.append(char_name)

        if not native_path:
            for index, contact in enumerate(contacts):
                active_bcs.append(write_shoe_anchor(w, index, contact, map_name))
        for index, link in enumerate(links):
            write_tie(w, f"SPRING{index}", link.helper, link.support.attached_to,
                      ("DX", "DY", "DZ", "DRX", "DRY", "DRZ"), map_name)
            active_bcs.append(f"SPRING{index}")

        if native_path:
            write_contact_solve(w, model, load_case, self.load_path, contacts, map_name, affe_entries, active_bcs, self.load_step)
        else:
            # ==============================================================
            # AFFE_CHAR_MECA — gravity
            # ==============================================================
            if load_case.gravity:
                w("# ----- Gravity -----")
                w("GRAVITY = AFFE_CHAR_MECA(")
                w("    MODELE=MODELE,")
                w("    PESANTEUR=_F(")
                w("        GRAVITE=9.81,")
                w("        DIRECTION=(0.0, 0.0, -1.0),")
                w("    ),")
                w(");")
                w()

            # ==============================================================
            # AFFE_CHAR_MECA — pressure
            # ==============================================================
            if has_pressure:
                write_pressure_load(
                    w,
                    map_name=map_name,
                    load_case=load_case,
                    pressure_fields=pressure_fields,
                )

            # ==============================================================
            # AFFE_CHAR_MECA_F — wind: VENT on beam-modelled elements,
            # Tuba's cross-flow rule on TUYAU_3M pipes
            # ==============================================================
            if has_wind:
                write_wind_load(
                    w,
                    map_name=map_name,
                    wind_fields=beam_winds,
                )
            if has_tuyau_wind:
                write_tuyau_wind_load(
                    w,
                    map_name=map_name,
                    rows=tuyau_winds,
                )

            # ==============================================================
            # AFFE_CHAR_MECA — line loads on pipes and beams
            # ==============================================================
            if has_line_load:
                write_line_load(
                    w,
                    map_name=map_name,
                    line_loads=line_loads,
                )

            # ==============================================================
            # AFFE_CHAR_MECA - concentrated nodal forces
            # ==============================================================
            if has_nodal_forces:
                component_names = ("FX", "FY", "FZ", "MX", "MY", "MZ")
                w("# ----- Concentrated nodal forces -----")
                w("POINT_FORCE = AFFE_CHAR_MECA(")
                w("    MODELE=MODELE,")
                w("    FORCE_NODALE=(")
                for force in nodal_forces:
                    w("        _F(")
                    w(f"            GROUP_NO='{map_name(f'GN_{force.node}')}',")
                    for name, value in zip(component_names, force.components):
                        w(f"            {name}={float(value):.8E},")
                    w("        ),")
                w("    ),")
                w(");")
                w()

            # ==============================================================
            # Thermal load (uniform temperature field for expansion)
            # ==============================================================
            has_discrete_supports = bool(contacts) or bool(links) or any(needs_discrete_element(s) for s in model.supports)
            structural_groups = [
                group
                for group, present in (
                    ("AllPipes", bool(pipe_straights or pipe_bends)),
                    ("G_TUBE", bool(beam_elems)),
                    ("G_BAR", bool(bar_elems)),
                    ("G_CABLE", bool(cable_elems)),
                )
                if present
            ]
            if has_temperature:
                write_thermal_load(
                    w,
                    map_name=map_name,
                    load_case=load_case,
                    temperature_fields=temperature_fields,
                    node_temperatures=node_temperatures,
                    affe_entries=affe_entries,
                    is_nonlinear=is_nonlinear,
                    varc_groups=structural_groups if has_discrete_supports else None,
                )

            # ==============================================================
            # Solve
            # ==============================================================
            w("# ----- Solve -----")

            # Build EXCIT list
            excit_entries: List[str] = []
            for char_name in active_bcs:
                excit_entries.append(f"        _F(CHARGE={char_name}),")
            if load_case.gravity:
                excit_entries.append("        _F(CHARGE=GRAVITY),")
            if has_pressure:
                excit_entries.append("        _F(CHARGE=PRESSURE),")
            if has_wind:
                excit_entries.append("        _F(CHARGE=WIND),")
            if has_tuyau_wind:
                excit_entries.append("        _F(CHARGE=WIND_TUY),")
            if has_line_load:
                excit_entries.append("        _F(CHARGE=LINELOAD),")
            if has_nodal_forces:
                excit_entries.append("        _F(CHARGE=POINT_FORCE),")

            if is_nonlinear:
                if contacts:
                    # Mechanical loads act in full from the first increment; only the
                    # temperature ramps over the load_step increments.
                    w(f"lst_inst = DEFI_LIST_REEL(DEBUT=0.0, INTERVALLE=_F(JUSQU_A=1.0, NOMBRE={math.ceil(1 / self.load_step)}));")
                else:
                    w("lst_inst = DEFI_LIST_REEL(VALE=(0.0, 1.0));")
                w("times = DEFI_LIST_INST(DEFI_LIST=_F(LIST_INST=lst_inst));")
                w()
                w("RESU = STAT_NON_LINE(")
                w("    MODELE=MODELE,")
                w("    CHAM_MATER=CHMAT,")
                w("    CARA_ELEM=CARA,")
                w("    EXCIT=(")
                for entry in excit_entries:
                    w(entry)
                w("    ),")
                if cable_elems or contacts:
                    elastic_groups: List[str] = []
                    if pipe_straights or pipe_bends:
                        elastic_groups.append("AllPipes")
                    if beam_elems:
                        elastic_groups.append("G_TUBE")
                    if bar_elems:
                        elastic_groups.append("G_BAR")
                    for support in model.supports:
                        if needs_discrete_element(support):
                            elastic_groups.append(discrete_support_group(support.node))
                    elastic_groups.extend(link.group for link in links)
                    w("    COMPORTEMENT=(")
                    if elastic_groups:
                        w("        _F(")
                        w(f"            GROUP_MA={group_ma_value(elastic_groups, map_name)},")
                        w("            RELATION='ELAS',")
                        w("        ),")
                    if cable_elems:
                        w("        _F(")
                        w(f"            GROUP_MA='{map_name('G_CABLE')}',")
                        w("            RELATION='CABLE',")
                        w("            DEFORMATION='GROT_GDEP',")
                        w("        ),")
                    for contact in contacts:
                        w(f"        _F(GROUP_MA='{map_name(contact.group)}', RELATION='DIS_CHOC', RESI_INTE=1e-9),")
                    w("    ),")
                else:
                    w("    COMPORTEMENT=_F(")
                    w("        TOUT='OUI',")
                    w("        RELATION='ELAS',")
                    w("    ),")
                w("    INCREMENT=_F(")
                w("        LIST_INST=times,")
                w("    ),")
                if contacts:
                    # As tight as a load path (aster_contact.py): the default RESI_GLOB_RELA=1e-6 is
                    # relative to the anchors' thermal reactions and left shoe forces ~30 N out of balance.
                    w(f"    CONVERGENCE=_F(RESI_GLOB_RELA=1e-8, ITER_GLOB_MAXI={100 if cable_elems else 50}),")
                elif cable_elems:
                    w("    CONVERGENCE=_F(ITER_GLOB_MAXI=100),")
                if cable_elems:
                    w("    RECH_LINEAIRE=_F(METHODE='CORDE'),")
                w("    METHODE='NEWTON',")
                w(");")
            else:
                w("RESU = MECA_STATIQUE(")
                w("    MODELE=MODELE,")
                w("    CHAM_MATER=CHMAT,")
                w("    CARA_ELEM=CARA,")
                w("    EXCIT=(")
                for entry in excit_entries:
                    w(entry)
                w("    ),")
                w(");")
            w()

        # ==============================================================
        # CALC_CHAMP — derived fields
        # ==============================================================
        w("# ----- Derived fields -----")
        w("RESU = CALC_CHAMP(")
        w("    reuse=RESU,")
        w("    RESULTAT=RESU,")
        w("    CONTRAINTE=('EFGE_ELNO', 'SIEF_ELNO'),")
        if has_pipe_stress:
            w("    CRITERES=('SIEQ_ELGA', 'SIEQ_ELNO'),")
        w("    FORCE='REAC_NODA',")
        w(");")
        w()

        # ==============================================================
        # IMPR_RESU — MED output
        # ==============================================================
        w("# ----- Write MED results file -----")
        w("IMPR_RESU(")
        w("    FORMAT='MED',")
        w("    UNITE=80,")
        w("    RESU=_F(")
        w("        RESULTAT=RESU,")
        # A load-path history keeps every increment; a single-operation shoe
        # study keeps only its final state, in the MED file and in every table.
        if contacts and not native_path:
            w("        INST=1.0,")
        if has_pipe_stress:
            w("        CARA_ELEM=CARA,")
            w("        NOM_CHAM=('DEPL', 'SIEQ_ELGA', 'SIEQ_ELNO', 'EFGE_ELNO', 'REAC_NODA'),")
        else:
            w("        NOM_CHAM=('DEPL', 'EFGE_ELNO', 'REAC_NODA'),")
        w("    ),")
        w(");")
        w()

        # ==============================================================
        # CREA_TABLE + IMPR_TABLE — parseable text output
        # ==============================================================
        w("# ----- Text table for EFGE_ELNO -----")
        w("TAB_EFFO = CREA_TABLE(")
        w("    RESU=_F(")
        w("        RESULTAT=RESU,")
        w("        NOM_CHAM='EFGE_ELNO',")
        w("        TOUT='OUI',")
        w("        NOM_CMP=('N', 'VY', 'VZ', 'MT', 'MFY', 'MFZ'),")
        if is_nonlinear and not native_path:
            w("        INST=1.0,")
        w("    ),")
        w(");")
        w()
        w("IMPR_TABLE(")
        w("    TABLE=TAB_EFFO,")
        w("    UNITE=38,")
        w("    FORMAT='TABLEAU',")
        w("    FORMAT_R='1PE24.16',")
        w("    SEPARATEUR=',',")
        w(");")
        w()
        w("# ----- Text table for DEPL -----")
        w("TAB_DEPL = CREA_TABLE(")
        w("    RESU=_F(")
        w("        RESULTAT=RESU,")
        w("        NOM_CHAM='DEPL',")
        w("        TOUT='OUI',")
        w("        NOM_CMP=('DX', 'DY', 'DZ', 'DRX', 'DRY', 'DRZ'),")
        if is_nonlinear and not native_path:
            w("        INST=1.0,")
        w("    ),")
        w(");")
        w()
        w("IMPR_TABLE(")
        w("    TABLE=TAB_DEPL,")
        w("    UNITE=39,")
        w("    FORMAT='TABLEAU',")
        w("    FORMAT_R='1PE24.16',")
        w("    SEPARATEUR=',',")
        w(");")
        w()
        w("# ----- Text table for REAC_NODA -----")
        w("TAB_REAC = CREA_TABLE(")
        w("    RESU=_F(")
        w("        RESULTAT=RESU,")
        w("        NOM_CHAM='REAC_NODA',")
        w("        TOUT='OUI',")
        w("        NOM_CMP=('DX', 'DY', 'DZ', 'DRX', 'DRY', 'DRZ'),")
        if is_nonlinear and not native_path:
            w("        INST=1.0,")
        w("    ),")
        w(");")
        w()
        w("IMPR_TABLE(")
        w("    TABLE=TAB_REAC,")
        w("    UNITE=40,")
        w("    FORMAT='TABLEAU',")
        w("    FORMAT_R='1PE24.16',")
        w("    SEPARATEUR=',',")
        w(");")
        w()
        if has_pipe_stress:
            w("# ----- Text table for SIEQ_ELNO -----")
            w("TAB_SIEQ = CREA_TABLE(")
            w("    RESU=_F(")
            w("        RESULTAT=RESU,")
            w("        NOM_CHAM='SIEQ_ELNO',")
            w("        TOUT='OUI',")
            w("        NOM_CMP=('VMIS',),")
            if is_nonlinear and not native_path:
                w("        INST=1.0,")
            w("    ),")
            w(");")
            w()
            w("IMPR_TABLE(")
            w("    TABLE=TAB_SIEQ,")
            w("    UNITE=41,")
            w("    FORMAT='TABLEAU',")
            w("    FORMAT_R='1PE24.16',")
            w("    SEPARATEUR=',',")
            w(");")
            w()

        # ==============================================================
        # FIN
        # ==============================================================
        if load_case.buckling is not None:
            # Must precede FIN(): FIN closes the jeveux memory manager and any
            # command after it fails with "memory manager is not started".
            if is_nonlinear:
                raise ValueError(
                    f"Operation {load_case.name!r}: buckling analysis is unsupported on a "
                    "nonlinear solve (contact or cable). The geometric stiffness is built from "
                    "a single SIEF_ELGA of a linear run, so on a nonlinear history it would "
                    "read one increment as if it were the whole prestress."
                )
            write_buckling_analysis(
                w,
                resolve_buckling_options(load_case.buckling),
                boundary_conditions=list(active_bcs),
            )
        if contacts:
            write_contact_tables(w, contacts, map_name, instant=None if native_path else 1.0)
        w("FIN();")

        write_artifact_text(path, "\n".join(comm))
        logger.info("Wrote command file: %s", path)
