"""
tuba.model — Core data model for Tuba v4.

Defines the canonical, serializable representation of a piping system:
materials, cross-sections, nodes, elements, supports, and load cases.
All data is stored in plain Python dataclasses and can be round-tripped
to/from the Tuba JSON schema.
"""

from __future__ import annotations

import copy
import json
import math
import uuid
from contextlib import contextmanager
from dataclasses import dataclass, field
from numbers import Real
from pathlib import Path
from typing import TYPE_CHECKING, Any, Dict, List, Optional, Sequence, Tuple

import numpy as np

from tuba.attributes import AttributeAssignment, InsulationSpec, coerce_entity_ref
from tuba.codelink import script_line_field, script_lines
from tuba.coordinates import CoordinateSystem
from tuba.placements import PlacementAssignment, PlacementFrame, resolve_placement_frame
from tuba.mixed import (
    AnalysisRegion,
    CadAsset,
    CouplingSpec,
    ImportedComponent,
    MeshGroup,
    Port,
)
from tuba.refs import EntityRef

if TYPE_CHECKING:
    from tuba.analysis.run import AnalysisRun
    from tuba.builder import BuiltRun
    from tuba.solver.modelisation import PipeModelization


# Stable model-schema identity. This intentionally does not track the package
# release version; readers continue to accept legacy records through from_dict.
MODEL_SERIALIZATION_VERSION = "tuba.model.v4"
DEFAULT_SNAPPING_TOLERANCE: float = 1e-6


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class Material:
    """Engineering material with temperature-dependent allowable stress."""

    name: str
    E: float  # Young's modulus [Pa]
    nu: float  # Poisson's ratio [-]
    rho: float = 7850.0  # Density [kg/m³]
    alpha: float = 0.0  # Mean thermal expansion coeff [1/K]
    allowable_stress: Dict[float, float] = field(default_factory=dict)
    """Mapping of temperature [°C] → allowable stress [Pa]."""
    source_line: Optional[int] = script_line_field()
    source_call_line: Optional[int] = script_line_field()

    @property
    def G(self) -> float:
        """Shear modulus derived from E and nu."""
        return self.E / (2.0 * (1.0 + self.nu))


@dataclass
class PipeSection:
    """Circular pipe cross-section."""

    name: str
    OD: float  # Outer diameter [m]
    WT: float  # Wall thickness [m]
    corrosion_allowance: float = 0.0  # [m]
    source_line: Optional[int] = script_line_field()
    source_call_line: Optional[int] = script_line_field()

    @property
    def ID(self) -> float:  # noqa: N802 – intentional capital
        """Inner diameter [m]."""
        return self.OD - 2.0 * self.WT

    @property
    def corroded_WT(self) -> float:
        """Wall thickness after corrosion allowance [m]."""
        return self.WT - self.corrosion_allowance

    @property
    def mean_radius(self) -> float:
        """Mean radius [m]."""
        return (self.OD - self.WT) / 2.0

    @property
    def area(self) -> float:
        """Cross-sectional area [m²]."""
        r_o = self.OD / 2.0
        r_i = self.ID / 2.0
        return math.pi * (r_o**2 - r_i**2)

    @property
    def I(self) -> float:  # noqa: E741, N802
        """Second moment of area [m⁴]."""
        r_o = self.OD / 2.0
        r_i = self.ID / 2.0
        return math.pi / 4.0 * (r_o**4 - r_i**4)

    @property
    def J(self) -> float:
        """Polar moment of area [m⁴]."""
        return 2.0 * self.I

    @property
    def Z(self) -> float:
        """Elastic section modulus [m³]."""
        return self.I / (self.OD / 2.0)


@dataclass
class BarSection:
    """Solid circular bar or pipe-like bar section."""

    name: str
    OD: float  # Outer diameter [m]
    WT: float  # Wall thickness [m] (0.0 if solid)
    source_line: Optional[int] = script_line_field()
    source_call_line: Optional[int] = script_line_field()

    @property
    def area(self) -> float:
        if self.WT == 0.0 or self.WT >= self.OD / 2.0:
            return math.pi * (self.OD / 2.0)**2
        r_o = self.OD / 2.0
        r_i = r_o - self.WT
        return math.pi * (r_o**2 - r_i**2)


@dataclass
class CableSection:
    """Tension-only cable section."""

    name: str
    radius: float  # [m]
    pretension: float = 0.0  # [N]
    #: Compression modulus as a fraction of the tension modulus - Code_Aster's
    #: ``EC_SUR_E``. At the default 1.0 the cable resists compression exactly
    #: like a bar and never goes slack, which is what a permanently taut stay
    #: does and what converges for a cable nothing holds taut. Drop it (1e-4 is
    #: the usual value) when slackening is the point, as it is for a guy that
    #: sheds its load to the windward side.
    compression_modulus_ratio: float = 1.0
    source_line: Optional[int] = script_line_field()
    source_call_line: Optional[int] = script_line_field()

    @property
    def area(self) -> float:
        return math.pi * self.radius**2


@dataclass
class RectangularSection:
    """Rectangular or hollow box section."""

    name: str
    height_y: float  # [m]
    height_z: float  # [m]
    thickness_y: float = 0.0  # [m], 0.0 if solid
    thickness_z: float = 0.0  # [m], 0.0 if solid
    source_line: Optional[int] = script_line_field()
    source_call_line: Optional[int] = script_line_field()

    @property
    def area(self) -> float:
        h_y = self.height_y
        h_z = self.height_z
        if self.thickness_y == 0.0 and self.thickness_z == 0.0:
            return h_y * h_z
        t_y = self.thickness_y
        t_z = self.thickness_z
        i_y = h_y - 2.0 * t_y
        i_z = h_z - 2.0 * t_z
        return (h_y * h_z) - max(0.0, i_y * i_z)


@dataclass
class IBeamSection:
    """Standard or general I-beam profile."""

    name: str
    profile_name: str
    properties: Dict[str, float] = field(default_factory=dict)
    source_line: Optional[int] = script_line_field()
    source_call_line: Optional[int] = script_line_field()

    @classmethod
    def load_from_db(cls, name: str, profile_name: str) -> IBeamSection:
        from tuba.sections import SectionCatalog

        profile = SectionCatalog.default().get_ibeam_profile(profile_name)
        return cls(name=name, profile_name=profile_name, properties=dict(profile.properties))



@dataclass
class Node:
    """A point in 3-D space."""

    id: str
    coords: np.ndarray  # shape (3,)
    source_line: Optional[int] = script_line_field()
    source_call_line: Optional[int] = script_line_field()

    def __post_init__(self):
        self.coords = np.asarray(self.coords, dtype=float)


@dataclass
class Element:
    """A 1-D structural element connecting two nodes."""

    id: str
    type: str  # "pipe_straight" | "pipe_bend" | "beam" | "bar" | "cable"
    n1: str  # start node id
    n2: str  # end node id
    section: str  # PipeSection name
    material: str  # Material name
    bend_radius: Optional[float] = None  # [m], only for bends
    bend_angle: Optional[float] = None  # [deg], only for bends
    bend_geometry: Optional["BendGeometry"] = None
    twist_angle: float = 0.0  # [deg], local cross-section twist angle
    route_id: Optional[str] = None
    station_start: Optional[float] = None
    station_end: Optional[float] = None
    # Where the user script built it (code <-> 3D link; see tuba.codelink). Deliberately
    # not serialized: it must never change model.json or the solver-input fingerprint.
    source_line: Optional[int] = None
    source_call_line: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        """The canonical payload: optional fields stay absent, declared floats are float.

        The fingerprint hashes it, model.json writes it, and generated scripts project
        it; nothing may read the dataclass attributes into a second shape.
        """
        data: Dict[str, Any] = {
            "id": self.id,
            "type": self.type,
            "n1": self.n1,
            "n2": self.n2,
            "section": self.section,
            "material": self.material,
        }
        # These are declared float, so serialize them as float even when the caller
        # passed an int literal: JSON renders 90 and 90.0 differently, which would
        # change the solver-input fingerprint of an otherwise identical model.
        if self.bend_radius is not None:
            data["bend_radius"] = float(self.bend_radius)
        if self.bend_angle is not None:
            data["bend_angle"] = float(self.bend_angle)
        if self.bend_geometry is not None:
            data["bend_geometry"] = self.bend_geometry.to_dict()
        twist_angle = float(getattr(self, "twist_angle", 0.0))
        if twist_angle != 0.0:
            data["twist_angle"] = twist_angle
        if self.route_id is not None:
            data["route_id"] = self.route_id
        if self.station_start is not None:
            data["station_start"] = float(self.station_start)
        if self.station_end is not None:
            data["station_end"] = float(self.station_end)
        return data


@dataclass
class BendGeometry:
    """Explicit 3-D bend geometry for solver, visualization, and compliance."""

    center: List[float]
    normal: List[float]
    radius: float
    angle: float
    start_tangent: List[float]
    end_tangent: List[float]
    generation_mode: str = "bend"

    def to_dict(self) -> Dict[str, Any]:
        return {
            "center": [float(value) for value in self.center],
            "normal": [float(value) for value in self.normal],
            "radius": float(self.radius),
            "angle": float(self.angle),
            "start_tangent": [float(value) for value in self.start_tangent],
            "end_tangent": [float(value) for value in self.end_tangent],
            "generation_mode": self.generation_mode,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "BendGeometry":
        return cls(
            center=[float(value) for value in data["center"]],
            normal=[float(value) for value in data["normal"]],
            radius=float(data["radius"]),
            angle=float(data["angle"]),
            start_tangent=[float(value) for value in data["start_tangent"]],
            end_tangent=[float(value) for value in data["end_tangent"]],
            generation_mode=data.get("generation_mode", "bend"),
        )


SUPPORT_TYPES = ("anchor", "guide", "rest", "spring", "hanger", "custom")


@dataclass
class Support:
    """A boundary condition applied at a node."""

    node: str
    type: str  # one of SUPPORT_TYPES
    direction: Optional[List[float]] = None  # constrained direction [x, y, z]
    stiffness: Optional[float] = None  # spring stiffness [N/m]
    imposed_displacement: Optional[List[float]] = None  # [m]
    stiffness_matrix: Optional[List[float]] = None  # discrete spring stiffnesses [K_x, K_y, K_z, K_rx, K_ry, K_rz]
    blocked_dof: Optional[List[Any]] = None  # discrete blockings [x, y, z, rx, ry, rz]
    mass: float = 0.0  # discrete mass [kg]
    friction_coefficient: float = 0.0
    id: Optional[str] = None
    gap: float = 0.0
    normal_stiffness: Optional[float] = None
    tangential_stiffness: Optional[float] = None
    attached_to: Optional[str] = None  # the node the restraint acts against; None means ground
    source_line: Optional[int] = None  # user script lines, not serialized (see Element)
    source_call_line: Optional[int] = None

    def to_dict(self) -> Dict[str, Any]:
        """The canonical payload: optional fields stay absent.

        Pinned: ``imposed_displacement`` is carried by the record and consumed by
        reporting and contact code but is not encoded; making this encoding
        canonical must not silently change that.
        """
        data: Dict[str, Any] = {"node": self.node, "type": self.type}
        if self.id is not None:
            data["id"] = self.id
        if self.direction:
            data["direction"] = self.direction
        if self.stiffness is not None:
            data["stiffness"] = self.stiffness
        if self.stiffness_matrix is not None:
            data["stiffness_matrix"] = self.stiffness_matrix
        if self.blocked_dof is not None:
            data["blocked_dof"] = self.blocked_dof
        if self.mass != 0.0:
            data["mass"] = self.mass
        if self.friction_coefficient != 0.0:
            data["friction_coefficient"] = self.friction_coefficient
        if self.gap != 0.0:
            data["gap"] = self.gap
        if self.normal_stiffness is not None:
            data["normal_stiffness"] = self.normal_stiffness
        if self.tangential_stiffness is not None:
            data["tangential_stiffness"] = self.tangential_stiffness
        if self.attached_to is not None:
            data["attached_to"] = self.attached_to
        return data

    def __post_init__(self):
        if self.type not in SUPPORT_TYPES:
            raise ValueError(f"Unknown support type {self.type!r}; use one of {', '.join(SUPPORT_TYPES)}.")
        for name in ('friction_coefficient', 'gap'):
            value = getattr(self, name)
            if not np.isfinite(value) or value < 0:
                raise ValueError(f'Support {name} must be finite and non-negative.')
        for name in ('normal_stiffness', 'tangential_stiffness'):
            value = getattr(self, name)
            if value is not None and (not np.isfinite(value) or value <= 0):
                raise ValueError(f'Support {name} must be finite and positive.')
        if self.direction is not None:
            direction = np.asarray(self.direction, dtype=float)
            if direction.shape != (3,) or not np.all(np.isfinite(direction)) or np.linalg.norm(direction) == 0:
                raise ValueError('Support direction must be a finite nonzero three-vector.')

    def restraint(self) -> "SupportRestraint":
        """The six restraint states this support compiles to, and its resolved spring stiffness.

        The solver's DDL emission, the contact shoe's one-way axis and the review glyph all read
        this one record, so they cannot disagree about what a support does.
        """
        states = ["free"] * 6
        stiffness = [0.0] * 6
        direction = [float(value) for value in self.direction] if self.direction is not None else None
        if self.stiffness_matrix is not None:
            matrix = list(self.stiffness_matrix)
            stiffness = [
                float(matrix[index])
                if index < len(matrix) and np.isfinite(float(matrix[index]))
                else 0.0
                for index in range(6)
            ]
        elif direction is not None:
            value = self.stiffness if self.stiffness is not None else 1.0e6
            for index in range(3):
                if abs(direction[index]) > 1e-12:
                    stiffness[index] = float(value)
        elif self.type == "spring":
            raise ValueError(
                f"Spring support at node {self.node} uses scalar stiffness without direction. "
                "Use stiffness_matrix=[Kx, Ky, Kz, Krx, Kry, Krz] or provide direction."
            )
        if self.blocked_dof is not None:
            for index, value in enumerate(self.blocked_dof[:6]):
                states[index] = "fixed" if value not in (False, 0, "0", "x", "X", None) else "free"
        elif self.type in ("anchor", "fixed"):
            states = ["fixed"] * 6
        elif self.type == "rest":
            axis = 2
            if direction is not None:
                axis = next((index for index in range(3) if abs(direction[index]) > 1e-12), 2)
            states[axis] = "one-way"
        elif self.type == "guide" and direction is not None:
            for index in range(3):
                if abs(direction[index]) > 1e-12:
                    states[index] = "fixed"
        elif self.type != "spring":
            # A guide with no direction, and the fallback for an unrecognised type: all translations.
            states[0] = states[1] = states[2] = "fixed"
        for index, value in enumerate(stiffness):
            if states[index] == "free" and value != 0.0:
                states[index] = "spring"
        return SupportRestraint(tuple(states), tuple(stiffness))


@dataclass(frozen=True)
class SupportRestraint:
    """One support's six restraint states (X, Y, Z, RX, RY, RZ) and its spring stiffnesses.

    A state is ``fixed`` (a bilateral restraint), ``one-way`` (a shoe that lifts off),
    ``spring`` (a discrete stiffness), or ``free``.
    """

    states: tuple[str, ...]
    spring_stiffness: tuple[float, ...]


TEE_TYPES = ("welding_tee", "reinforced_tee", "unreinforced_tee")


@dataclass
class Tee:
    """A branch/tee junction definition at a node."""

    node: str
    type: str = "unreinforced_tee"  # welding_tee | reinforced_tee | unreinforced_tee
    pad_thickness: float = 0.0  # reinforcing pad thickness [m]

    def __post_init__(self) -> None:
        if self.type not in TEE_TYPES:
            raise ValueError(f"Unknown Tee type: {self.type}")
        self.pad_thickness = float(self.pad_thickness)

    def to_dict(self) -> Dict[str, Any]:
        # node is the map key in TubaModel.tees, so it stays out of the value.
        return {"type": self.type, "pad_thickness": self.pad_thickness}

    @classmethod
    def from_dict(cls, node: str, data: Dict[str, Any]) -> "Tee":
        return cls(
            node=node,
            type=data.get("type", "unreinforced_tee"),
            pad_thickness=float(data.get("pad_thickness", 0.0)),
        )


@dataclass
class OperationField:
    """Local operating value over a selectable part of the pipe model."""

    quantity: str
    value: float
    direction: Optional[List[float]] = None
    scope: str = "all"
    profile: str = "uniform"
    group: Optional[str] = None
    route_id: Optional[str] = None
    station_start: Optional[float] = None
    station_end: Optional[float] = None
    element_ids: List[str] = field(default_factory=list)
    node_ids: List[str] = field(default_factory=list)
    source_line: Optional[int] = script_line_field()
    source_call_line: Optional[int] = script_line_field()

    def to_dict(self) -> Dict[str, Any]:
        """The canonical payload: absent selectors stay absent, direction is float-cast.

        This is the one encoding of a field. The fingerprint hashes it, generated scripts
        write it, and reports project it; nothing may read the dataclass attributes into a
        second shape.
        """
        data: Dict[str, Any] = {
            "quantity": self.quantity,
            "value": self.value,
            "scope": self.scope,
            "profile": self.profile,
        }
        if self.group is not None:
            data["group"] = self.group
        if self.route_id is not None:
            data["route_id"] = self.route_id
        if self.station_start is not None:
            data["station_start"] = self.station_start
        if self.station_end is not None:
            data["station_end"] = self.station_end
        if self.element_ids:
            data["element_ids"] = list(self.element_ids)
        if self.node_ids:
            data["node_ids"] = list(self.node_ids)
        if self.direction is not None:
            data["direction"] = [float(value) for value in self.direction]
        return data


@dataclass
class NodalForce:
    """Concentrated nodal force/moment in global coordinates."""

    node: str
    components: List[float]
    source_line: Optional[int] = script_line_field()
    source_call_line: Optional[int] = script_line_field()

    def __post_init__(self) -> None:
        if len(self.components) != 6:
            raise ValueError("NodalForce components must be [FX, FY, FZ, MX, MY, MZ].")
        self.components = [float(value) for value in self.components]

    @classmethod
    def from_force(
        cls,
        node: str,
        force: List[float],
        moment: Optional[List[float]] = None,
    ) -> "NodalForce":
        if len(force) == 6 and moment is None:
            return cls(node=node, components=list(force))
        if len(force) != 3:
            raise ValueError("force must contain either 3 force values or all 6 force/moment values.")
        return cls(node=node, components=list(force) + list(moment or [0.0, 0.0, 0.0]))

    def to_dict(self) -> Dict[str, Any]:
        return {"node": self.node, "components": [float(value) for value in self.components]}

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "NodalForce":
        if "components" in data:
            return cls(node=data["node"], components=list(data["components"]))
        return cls.from_force(node=data["node"], force=list(data["force"]), moment=data.get("moment"))


@dataclass(frozen=True)
class BucklingOptions:
    """Request a linear buckling eigenvalue analysis on a load case's own prestress.

    The load case still solves as an ordinary static study; this adds a
    linearised buckling eigenproblem on the geometric stiffness built from that
    solution, so one solve answers both "how does it deflect" and "how close is it
    to buckling". Code_Aster reaches this through
    ``CALC_MODES(TYPE_RESU='MODE_FLAMB')``.

    A critical factor is a *reference load*, not a design verdict: it is a
    linearised perfect-frame figure with no initial imperfection, and a real column
    buckles at a fraction of it. Read it as the first step of a buckling check, not
    the last.

    ``stop_on_error`` is False by default on purpose. Code_Aster's default
    a-posteriori modal tolerance is 1e-6, which a real frame frequently cannot
    meet even though the factors are accurate to 1e-12; leaving the check on makes
    the run raise ``ALGELINE5_15`` *after* computing usable factors.
    """

    n_modes: int = 6
    modal_subspace: int = 12
    method: str = "TRI_DIAG"
    rigid_modes: str = "NON"
    stop_on_error: bool = False
    mode_shapes: bool = True

    def __post_init__(self) -> None:
        if not isinstance(self.n_modes, int) or isinstance(self.n_modes, bool) or self.n_modes < 1:
            raise ValueError(
                f"buckling n_modes must be a positive integer, got {self.n_modes!r}."
            )
        if not isinstance(self.modal_subspace, int) or isinstance(self.modal_subspace, bool) or self.modal_subspace < 1:
            raise ValueError(
                f"buckling modal_subspace must be a positive integer, got {self.modal_subspace!r}."
            )
        if self.method not in {"TRI_DIAG", "SORENSEN", "JACOBI"}:
            raise ValueError(
                f"buckling method must be TRI_DIAG, SORENSEN or JACOBI, got {self.method!r}."
            )
        if self.rigid_modes not in {"OUI", "NON"}:
            raise ValueError(
                f"buckling rigid_modes must be OUI or NON, got {self.rigid_modes!r}."
            )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "n_modes": int(self.n_modes),
            "modal_subspace": int(self.modal_subspace),
            "method": str(self.method),
            "rigid_modes": str(self.rigid_modes),
            "stop_on_error": bool(self.stop_on_error),
            "mode_shapes": bool(self.mode_shapes),
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "BucklingOptions":
        return cls(
            n_modes=int(data["n_modes"]),
            modal_subspace=int(data.get("modal_subspace", 12)),
            method=str(data.get("method", "TRI_DIAG")),
            rigid_modes=str(data.get("rigid_modes", "NON")),
            stop_on_error=bool(data.get("stop_on_error", False)),
            mode_shapes=bool(data.get("mode_shapes", True)),
        )


def resolve_buckling_options(
    buckling: Optional[BucklingOptions | Dict[str, Any]],
) -> Optional[BucklingOptions]:
    """Accept a BucklingOptions, a plain dict, or nothing; refuse a non-mapping otherwise."""
    if buckling is None:
        return None
    if isinstance(buckling, BucklingOptions):
        return buckling
    if isinstance(buckling, dict):
        return BucklingOptions.from_dict(buckling)
    raise ValueError(
        f"buckling must be a BucklingOptions, a dict, or None, got {type(buckling).__name__}."
    )


@dataclass
class LoadCase:
    """Operating load case definition."""

    name: str
    gravity: bool = True
    internal_pressure: float = 0.0  # [Pa]
    temperature: float = 20.0  # [°C]
    ref_temperature: float = 20.0  # [°C]
    fields: List[OperationField] = field(default_factory=list)
    nodal_forces: List[NodalForce] = field(default_factory=list)
    buckling: Optional[BucklingOptions] = None
    source_line: Optional[int] = script_line_field()
    source_call_line: Optional[int] = script_line_field()

    def add_nodal_force(
        self,
        node: str,
        force: List[float],
        moment: Optional[List[float]] = None,
    ) -> NodalForce:
        load = NodalForce.from_force(node=node, force=force, moment=moment)
        load.source_line, load.source_call_line = script_lines()
        self.nodal_forces.append(load)
        return load


@dataclass
class Operation:
    """Uniform operating scenario that can be compiled to a load case."""

    name: str
    gravity: bool = True
    internal_pressure: float = 0.0  # [Pa]
    temperature: float = 20.0  # [C]
    ref_temperature: float = 20.0  # [C]
    metadata: Dict[str, Any] = field(default_factory=dict)
    fields: List[OperationField] = field(default_factory=list)
    nodal_forces: List[NodalForce] = field(default_factory=list)
    buckling: Optional[BucklingOptions] = None
    source_line: Optional[int] = script_line_field()
    source_call_line: Optional[int] = script_line_field()

    def to_load_case(self) -> LoadCase:
        return LoadCase(
            name=self.name,
            gravity=self.gravity,
            internal_pressure=self.internal_pressure,
            temperature=self.temperature,
            ref_temperature=self.ref_temperature,
            fields=list(self.fields),
            nodal_forces=list(self.nodal_forces),
            buckling=self.buckling,
        )

    def add_nodal_force(
        self,
        node: str,
        force: List[float],
        moment: Optional[List[float]] = None,
    ) -> NodalForce:
        load = NodalForce.from_force(node=node, force=force, moment=moment)
        load.source_line, load.source_call_line = script_lines()
        self.nodal_forces.append(load)
        return load

    def add_field(
        self,
        quantity: str,
        value: float,
        *,
        scope: str = "all",
        profile: str = "uniform",
        group: Optional[str] = None,
        route_id: Optional[str] = None,
        station_start: Optional[float] = None,
        station_end: Optional[float] = None,
        element_ids: Optional[List[str]] = None,
        node_ids: Optional[List[str]] = None,
        direction: Optional[List[float]] = None,
    ) -> OperationField:
        field_record = _make_operation_field(
            quantity, value, scope=scope, profile=profile, group=group, route_id=route_id,
            station_start=station_start, station_end=station_end, element_ids=element_ids,
            node_ids=node_ids, direction=direction,
        )
        field_record.source_line, field_record.source_call_line = script_lines()
        self.fields.append(field_record)
        return field_record


def _make_operation_field(
    quantity, value, *, scope="all", profile="uniform", group=None, route_id=None,
    station_start=None, station_end=None, element_ids=None, node_ids=None, direction=None,
) -> OperationField:
    if quantity == "fluid_density":
        from tuba.validation import fluid_field_problem
        raw = OperationField(quantity=quantity, value=value, scope=scope, profile=profile,
                             group=group, route_id=route_id, station_start=station_start,
                             station_end=station_end, element_ids=element_ids or [],
                             node_ids=node_ids or [], direction=direction)
        selectors = [name for name, value in (("group", group), ("route", route_id),
                                             ("elements", element_ids), ("nodes", node_ids))
                     if value is not None]
        problem = fluid_field_problem(raw, infer_scope=True, selectors=selectors)
        if problem:
            raise ValueError(problem)
    if group is not None:
        scope = "group"
    elif route_id is not None:
        scope = "route"
    elif element_ids is not None:
        scope = "elements"
    elif node_ids is not None:
        scope = "nodes"
    field_record = OperationField(
        quantity=quantity,
        value=float(value),
        direction=(None if direction is None else [float(value) for value in direction]),
        scope=scope,
        profile=profile,
        group=group,
        route_id=route_id,
        station_start=station_start,
        station_end=station_end,
        element_ids=list(element_ids or []),
        node_ids=list(node_ids or []),
    )
    return field_record


# ---------------------------------------------------------------------------
# Central model
# ---------------------------------------------------------------------------

class TubaModel:
    """Root container for a complete piping analysis model.

    This is the single source of truth: geometry, materials, sections,
    supports, and load cases.  It serialises to the canonical Tuba JSON
    schema and drives every downstream operation (solver, compliance,
    visualisation).
    """

    def __init__(self, project_name: str = "Untitled", standard: str = ""):
        self.project_name = project_name
        self.standard = standard

        self.materials: Dict[str, Material] = {}
        self.sections: Dict[str, PipeSection] = {}
        self.nodes: Dict[str, Node] = {}
        self.elements: List[Element] = []
        self.supports: List[Support] = []
        self.load_cases: Dict[str, LoadCase] = {}
        self.operations: Dict[str, Operation] = {}
        self.tees: Dict[str, Tee] = {}
        self.obstacles: List[Dict[str, Any]] = []
        self.groups: Dict[str, Dict[str, Any]] = {}
        self.placement_frames: Dict[str, PlacementFrame] = {}
        self.placement_assignments: List[PlacementAssignment] = []
        self.specs: Dict[str, Dict[str, Any]] = {}
        self.attributes: List[AttributeAssignment] = []
        self.cad_assets: Dict[str, CadAsset] = {}
        self.imported_components: Dict[str, ImportedComponent] = {}
        self.analysis_regions: Dict[str, AnalysisRegion] = {}
        self.ports: Dict[str, Port] = {}
        self.mesh_groups: Dict[str, MeshGroup] = {}
        self.couplings: Dict[str, CouplingSpec] = {}

        # Pipe runs built through pipe() or PipeRunRecipe.build, in the order they finished.
        # Runtime only, like source lines: never serialized, so a generated model script can
        # write each run back as its steps without changing model.json or the fingerprint.
        self.pipe_runs: List["BuiltRun"] = []

        # Assembly invocations applied through tuba.assemblies.assemble, in creation order.
        # Runtime only, like pipe_runs: each entry records the unit ref, its replayable
        # params and the record offsets it spans, so a generated model script can write it
        # back as one assemble() call without changing model.json or the fingerprint.
        # Entry shape: {"ref": str, "params": dict, "node0": int, "element0": int,
        # "support0": int, "node1": int, "element1": int, "support1": int}.
        self.assembly_calls: List[Dict[str, Any]] = []

        self._node_counter: int = 0
        self._element_counters: Dict[str, int] = {}
        self._support_counter: int = 0
        self._node_point_index: Dict[Tuple[int, int, int], str] = {}
        self._element_ids: set[str] = set()
        self._element_by_id: Dict[str, Element] = {}

    # -- Materials -----------------------------------------------------------

    def add_material(
        self,
        name: str,
        E: float,
        nu: float,
        rho: float = 7850.0,
        alpha: float = 0.0,
        allowable_stress: Optional[Dict[float, float]] = None,
    ) -> Material:
        mat = Material(
            name=name,
            E=E,
            nu=nu,
            rho=rho,
            alpha=alpha,
            allowable_stress=allowable_stress or {},
        )
        mat.source_line, mat.source_call_line = script_lines()
        self.materials[name] = mat
        return mat

    # -- Sections ------------------------------------------------------------

    def add_pipe_section(
        self,
        name: str,
        OD: float,
        WT: float,
        corrosion_allowance: float = 0.0,
    ) -> PipeSection:
        sec = PipeSection(name=name, OD=OD, WT=WT, corrosion_allowance=corrosion_allowance)
        sec.source_line, sec.source_call_line = script_lines()
        self.sections[name] = sec
        return sec

    def add_bar_section(self, name: str, OD: float, WT: float) -> BarSection:
        sec = BarSection(name=name, OD=OD, WT=WT)
        sec.source_line, sec.source_call_line = script_lines()
        self.sections[name] = sec
        return sec

    def add_cable_section(
        self,
        name: str,
        radius: float,
        pretension: float = 0.0,
        compression_modulus_ratio: float = 1.0,
    ) -> CableSection:
        sec = CableSection(
            name=name,
            radius=radius,
            pretension=pretension,
            compression_modulus_ratio=compression_modulus_ratio,
        )
        sec.source_line, sec.source_call_line = script_lines()
        self.sections[name] = sec
        return sec

    def add_rectangular_section(
        self,
        name: str,
        height_y: float,
        height_z: float,
        thickness_y: float = 0.0,
        thickness_z: float = 0.0,
    ) -> RectangularSection:
        sec = RectangularSection(
            name=name,
            height_y=height_y,
            height_z=height_z,
            thickness_y=thickness_y,
            thickness_z=thickness_z,
        )
        sec.source_line, sec.source_call_line = script_lines()
        self.sections[name] = sec
        return sec

    def add_ibeam_section(self, name: str, profile_name: str) -> IBeamSection:
        sec = IBeamSection.load_from_db(name=name, profile_name=profile_name)
        sec.source_line, sec.source_call_line = script_lines()
        self.sections[name] = sec
        return sec

    # -- Mixed-analysis records ----------------------------------------------

    def add_cad_asset(self, **kwargs) -> CadAsset:
        asset = CadAsset(**kwargs)
        self.cad_assets[asset.id] = asset
        return asset

    def add_imported_component(self, **kwargs) -> ImportedComponent:
        component = ImportedComponent(**kwargs)
        self.imported_components[component.id] = component
        return component

    def add_analysis_region(self, **kwargs) -> AnalysisRegion:
        region = AnalysisRegion(**kwargs)
        self.analysis_regions[region.id] = region
        return region

    def add_port(self, **kwargs) -> Port:
        port = Port(**kwargs)
        self.ports[port.id] = port
        return port

    def add_mesh_group(self, **kwargs) -> MeshGroup:
        mesh_group = MeshGroup(**kwargs)
        self.mesh_groups[mesh_group.id] = mesh_group
        return mesh_group

    def add_coupling(self, **kwargs) -> CouplingSpec:
        coupling = CouplingSpec(**kwargs)
        self.couplings[coupling.id] = coupling
        return coupling

    def connect_pipe_to_port(
        self,
        *,
        pipe: str | EntityRef,
        node: str | EntityRef,
        port: str | EntityRef,
        method: str = "3D_TUYAU",
        id: str | None = None,
    ) -> CouplingSpec:
        """Create a pipe-to-port coupling with basic structural checks."""
        from tuba.mixed import connect_pipe_to_port as _connect

        return _connect(self, pipe=pipe, node=node, port=port, method=method, id=id)

    # -- Nodes ---------------------------------------------------------------

    def add_node(self, coords: Sequence[float] | np.ndarray) -> str:
        """Create a node from [x, y, z] coordinates and return its id."""
        node_id = f"N{self._node_counter}"
        self._node_counter += 1
        node = Node(id=node_id, coords=np.asarray(coords, dtype=float))
        node.source_line, node.source_call_line = script_lines()
        self.nodes[node_id] = node
        self._index_node(node_id)
        return node_id

    def find_node_by_point(
        self, coords, *, tol: float = DEFAULT_SNAPPING_TOLERANCE
    ) -> Optional[str]:
        """Return an existing node id at coords, if one exists within tolerance."""
        target = np.asarray(coords, dtype=float)
        tol_val = float(tol)
        indexed = self._node_point_index.get(_point_index_key(target, tol_val))
        if indexed is not None:
            node = self.nodes.get(indexed)
            if node is not None and float(np.linalg.norm(node.coords - target)) <= tol_val:
                return indexed
        for nid, node in self.nodes.items():
            if float(np.linalg.norm(node.coords - target)) <= tol_val:
                return nid
        return None

    def get_or_create_node(
        self,
        coords: Sequence[float] | np.ndarray,
        *,
        tolerance: float = DEFAULT_SNAPPING_TOLERANCE,
    ) -> str:
        """Reuse a node within *tolerance* [m], or create one at finite [x, y, z]."""
        point = np.asarray(coords, dtype=object)
        if point.shape != (3,) or any(
            not isinstance(value, Real) or isinstance(value, (bool, np.bool_)) for value in point
        ):
            raise ValueError("Node coordinates must be a finite numeric 3-vector.")
        if not isinstance(tolerance, Real) or isinstance(tolerance, (bool, np.bool_)):
            raise ValueError("Node tolerance must be a positive finite number.")
        try:
            point = point.astype(float)
            tolerance = float(tolerance)
        except (ValueError, OverflowError) as exc:
            raise ValueError("Node coordinates and tolerance must be finite numbers.") from exc
        if not np.all(np.isfinite(point)):
            raise ValueError("Node coordinates must be a finite numeric 3-vector.")
        if not math.isfinite(tolerance) or tolerance <= 0.0:
            raise ValueError("Node tolerance must be a positive finite number.")
        try:
            _point_index_key(point, tolerance)
            _point_index_key(point)
        except (OverflowError, ValueError) as exc:
            raise ValueError("Node coordinates cannot be indexed at the requested or default tolerance.") from exc
        existing = self.find_node_by_point(point, tol=tolerance)
        return existing if existing is not None else self.add_node(point)

    # -- Elements ------------------------------------------------------------

    def add_element(self, **kwargs) -> Element:
        elem = Element(**kwargs)
        elem.source_line, elem.source_call_line = script_lines()
        self.elements.append(elem)
        self._element_ids.add(elem.id)
        self._element_by_id[elem.id] = elem
        self._sync_element_counter(elem.id)
        return elem

    def get_element(self, element_id: str) -> Optional[Element]:
        """Return an element by id using the maintained model index."""

        return self._element_by_id.get(element_id)

    def next_element_id(self, prefix: str) -> str:
        """Return the next globally unique element id for *prefix*.

        Element IDs are consumed by solver result mapping, so they must be
        unique across independent builder contexts and autorouted pipe runs.
        """
        idx = self._element_counters.get(prefix, 0)
        while f"{prefix}_{idx}" in self._element_ids:
            idx += 1
        self._element_counters[prefix] = idx + 1
        return f"{prefix}_{idx}"

    def _sync_element_counter(self, elem_id: str) -> None:
        """Advance the matching prefix counter beyond an existing element id."""
        if "_" not in elem_id:
            return
        prefix, suffix = elem_id.rsplit("_", 1)
        if not suffix.isdigit():
            return
        self._element_counters[prefix] = max(
            self._element_counters.get(prefix, 0),
            int(suffix) + 1,
        )

    def _index_node(self, node_id: str) -> None:
        node = self.nodes[node_id]
        self._node_point_index[_point_index_key(node.coords)] = node_id

    # -- Supports ------------------------------------------------------------

    def add_support(
        self,
        node: str,
        type: str,
        direction: Optional[List[float]] = None,
        stiffness: Optional[float] = None,
        imposed_displacement: Optional[List[float]] = None,
        stiffness_matrix: Optional[List[float]] = None,
        blocked_dof: Optional[List[Any]] = None,
        mass: float = 0.0,
        friction_coefficient: float = 0.0,
        id: Optional[str] = None,
        gap: float = 0.0,
        normal_stiffness: Optional[float] = None,
        tangential_stiffness: Optional[float] = None,
        attached_to: Optional[str] = None,
    ) -> Support:
        support_id = id or self.next_support_id()
        sup = Support(
            node=node,
            type=type,
            direction=direction,
            stiffness=stiffness,
            imposed_displacement=imposed_displacement,
            stiffness_matrix=stiffness_matrix,
            blocked_dof=blocked_dof,
            mass=mass,
            friction_coefficient=friction_coefficient,
            id=support_id,
            gap=gap,
            normal_stiffness=normal_stiffness,
            tangential_stiffness=tangential_stiffness,
            attached_to=attached_to,
        )
        sup.source_line, sup.source_call_line = script_lines()
        self.supports.append(sup)
        self._sync_support_counter(support_id)
        return sup

    def next_support_id(self) -> str:
        """Return the next globally unique support id."""
        existing = {support.id for support in self.supports}
        idx = self._support_counter
        while f"support_{idx}" in existing:
            idx += 1
        self._support_counter = idx + 1
        return f"support_{idx}"

    def _sync_support_counter(self, support_id: Optional[str]) -> None:
        if not support_id or "_" not in support_id:
            return
        prefix, suffix = support_id.rsplit("_", 1)
        if prefix != "support" or not suffix.isdigit():
            return
        self._support_counter = max(self._support_counter, int(suffix) + 1)

    # -- Semantic attributes -------------------------------------------------

    def add_insulation_spec(
        self,
        id: str,
        material: str,
        thickness_m: float,
        density_kg_m3: float = 0.0,
        cost_per_m: float = 0.0,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> InsulationSpec:
        spec = InsulationSpec(
            id=id,
            material=material,
            thickness_m=thickness_m,
            density_kg_m3=density_kg_m3,
            cost_per_m=cost_per_m,
            metadata=dict(metadata or {}),
        )
        self.specs.setdefault("insulation", {})[spec.id] = spec
        return spec

    def assign_attribute(
        self,
        target,
        key: str,
        value: Any,
        *,
        source: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> AttributeAssignment:
        line, call_line = script_lines()
        assignment = AttributeAssignment(
            target=coerce_entity_ref(target),
            key=key,
            value=value,
            source=source,
            metadata=dict(metadata or {}),
            source_line=line,
            source_call_line=call_line,
        )
        self.attributes.append(assignment)
        return assignment

    def assign_insulation(
        self,
        target,
        insulation_spec_id: str,
        *,
        source: Optional[str] = None,
        metadata: Optional[Dict[str, Any]] = None,
    ) -> AttributeAssignment:
        if insulation_spec_id not in self.specs.get("insulation", {}):
            raise ValueError(f"Unknown insulation spec {insulation_spec_id!r}.")
        return self.assign_attribute(
            target,
            "insulation",
            insulation_spec_id,
            source=source,
            metadata=metadata,
        )

    def get_attribute_assignments(self, target) -> Dict[str, AttributeAssignment]:
        """The assignment that supplies each attribute of *target*.

        Assignments to groups containing it come first and direct ones after; the last
        assignment of a key wins. :meth:`get_attributes` reads its values from here.
        """
        ref = coerce_entity_ref(target)
        assignments: Dict[str, AttributeAssignment] = {}

        if ref.kind in _GROUP_MEMBER_KEYS:
            containing_groups = self._groups_containing_ref(ref)
            for assignment in self.attributes:
                if assignment.target.kind == "group" and assignment.target.id in containing_groups:
                    assignments[assignment.key] = assignment

        for assignment in self.attributes:
            if assignment.target == ref:
                assignments[assignment.key] = assignment

        return assignments

    def get_attributes(self, target) -> Dict[str, Any]:
        return {key: assignment.value for key, assignment in self.get_attribute_assignments(target).items()}

    def get_insulation(self, target) -> Optional[InsulationSpec]:
        spec_id = self.get_attributes(target).get("insulation")
        if spec_id is None:
            return None
        spec = self.specs.get("insulation", {}).get(spec_id)
        if spec is None:
            raise ValueError(f"Unknown insulation spec {spec_id!r}.")
        if isinstance(spec, InsulationSpec):
            return spec
        return InsulationSpec.from_dict(spec_id, spec)

    def _groups_containing_ref(self, ref) -> set[str]:
        member_key = _GROUP_MEMBER_KEYS.get(ref.kind)
        if member_key is None:
            return set()
        return {
            group_name
            for group_name, group in self.groups.items()
            if ref.id in group.get(member_key, [])
        }

    # -- Load cases ----------------------------------------------------------

    def define_load_case(
        self,
        name: str,
        gravity: bool = True,
        pressure: float = 0.0,
        temperature: float = 20.0,
        ref_temperature: float = 20.0,
        fields: Optional[List[Dict[str, Any] | OperationField]] = None,
        buckling: Optional[BucklingOptions | Dict[str, Any]] = None,
    ) -> LoadCase:
        if name in self.operations:
            raise ValueError(
                f"Cannot define load case {name!r}: an operation already uses that name; "
                "load cases and operations share one namespace."
            )
        lc = LoadCase(
            name=name,
            gravity=gravity,
            internal_pressure=pressure,
            temperature=temperature,
            ref_temperature=ref_temperature,
            buckling=resolve_buckling_options(buckling),
        )
        lc.fields = [record if isinstance(record, OperationField) else _make_operation_field(**record)
                     for record in fields or []]
        lc.source_line, lc.source_call_line = script_lines()
        self.load_cases[name] = lc
        return lc

    def define_operation(
        self,
        name: str,
        gravity: bool = True,
        pressure: float = 0.0,
        temperature: float = 20.0,
        ref_temperature: float = 20.0,
        metadata: Optional[Dict[str, Any]] = None,
        fields: Optional[List[Dict[str, Any] | OperationField]] = None,
        buckling: Optional[BucklingOptions | Dict[str, Any]] = None,
    ) -> Operation:
        if name in self.load_cases:
            raise ValueError(
                f"Cannot define operation {name!r}: a load case already uses that name; "
                "load cases and operations share one namespace."
            )
        op = Operation(
            name=name,
            gravity=gravity,
            internal_pressure=pressure,
            temperature=temperature,
            ref_temperature=ref_temperature,
            metadata=dict(metadata or {}),
            buckling=resolve_buckling_options(buckling),
        )
        op.source_line, op.source_call_line = script_lines()
        op.fields = [record if isinstance(record, OperationField) else _make_operation_field(**record)
                     for record in fields or []]
        self.operations[name] = op
        return op

    def resolve_load_case(self, name: Optional[str] = None) -> Tuple[str, LoadCase]:
        """Return a named load case or uniform operation as a load case."""
        if name is None:
            if self.load_cases:
                name = next(iter(self.load_cases))
            elif self.operations:
                name = next(iter(self.operations))
            else:
                raise ValueError("Model has no load cases or operations defined.")

        if name in self.load_cases:
            return name, self.load_cases[name]
        if name in self.operations:
            return name, self.operations[name].to_load_case()

        available = list(self.load_cases.keys()) + list(self.operations.keys())
        raise ValueError(
            f"Load case or operation '{name}' not found. "
            f"Available: {available}"
        )

    def resolve_operation_field_elements(self, field_record: OperationField) -> List[Element]:
        load_quantities = {"wind", "line_load"}
        whole_elements = load_quantities | {"fluid_density"}
        allowed_types = (
            {"beam", "pipe_straight", "pipe_bend"}
            if field_record.quantity in load_quantities
            else {"pipe_straight", "pipe_bend"}
        )
        if field_record.scope == "all":
            covered = self.elements
        elif field_record.scope == "group":
            if not field_record.group or field_record.group not in self.groups:
                raise ValueError(f"Operation field references missing group {field_record.group!r}.")
            ids = set(self.groups[field_record.group].get("elements", []))
            covered = [e for e in self.elements if e.id in ids]
        elif field_record.scope == "route":
            if not field_record.route_id:
                raise ValueError("Operation field route scope requires route_id.")
            covered = [e for e in self.elements if e.route_id == field_record.route_id]
            if field_record.station_start is not None or field_record.station_end is not None:
                start = field_record.station_start if field_record.station_start is not None else float("-inf")
                end = field_record.station_end if field_record.station_end is not None else float("inf")
                # Wind and line loads ignore float noise at the range ends; other quantities keep the strict overlap.
                noise = 1e-9 if field_record.quantity in whole_elements else 0.0
                covered = [
                    e for e in covered
                    if e.station_start is not None
                    and e.station_end is not None
                    and e.station_start < end - noise
                    and e.station_end > start + noise
                ]
                if field_record.quantity in whole_elements:
                    # FORCE_POUTRE loads whole elements, so wind and line loads must not cover part of one.
                    partial = [e for e in covered if e.station_start < start - noise or e.station_end > end + noise]
                    if partial:
                        spans = ", ".join(
                            f"{e.id!r} (stations {e.station_start:g} to {e.station_end:g})" for e in partial
                        )
                        raise ValueError(
                            f"{field_record.quantity} station range {start:g} to {end:g} only partly covers {spans}; "
                            "align the range with element ends or use element_ids."
                        )
        elif field_record.scope == "elements":
            ids = set(field_record.element_ids)
            covered = [e for e in self.elements if e.id in ids]
        else:
            raise ValueError(f"Unsupported operation field scope {field_record.scope!r}.")

        selected = [e for e in covered if e.type in allowed_types]
        if (field_record.scope == "elements" or field_record.quantity in load_quantities
                or (field_record.quantity == "fluid_density" and field_record.scope != "all")):
            # Named elements must exist, and wind and line loads may not cover elements that cannot carry them.
            named = set(field_record.element_ids) if field_record.scope == "elements" else {e.id for e in covered}
            if field_record.scope == "group" and field_record.quantity == "fluid_density":
                named = set(self.groups[field_record.group].get("elements", []))
            refused = sorted(named - {e.id for e in selected})
            if refused:
                remedy = (
                    " Target pipe and beam elements with a group, route or element_ids."
                    if field_record.quantity in load_quantities
                    else ""
                )
                raise ValueError(
                    "Operation field references elements that do not exist or cannot carry "
                    f"{field_record.quantity!r}: {refused!r}.{remedy}"
                )
        return selected

    # -- Tees and Obstacles --------------------------------------------------

    def define_tee(self, node: str, type: str = "unreinforced_tee", pad_thickness: float = 0.0) -> Tee:
        """Explicitly define the Tee type and reinforcement for a node."""
        if node not in self.nodes:
            raise ValueError(f"Node '{node}' does not exist in the model.")
        tee = Tee(node=node, type=type, pad_thickness=pad_thickness)
        self.tees[node] = tee
        return tee

    def add_obstacle(
        self,
        id: str,
        type: str,
        min_point: Optional[List[float]] = None,
        max_point: Optional[List[float]] = None,
        file_path: Optional[str] = None,
        position: Optional[List[float]] = None,
        orientation: Optional[List[float]] = None
    ) -> Dict[str, Any]:
        """Add an obstacle (cuboid, cylinder, or mesh) to the model."""
        obs = {
            "id": id,
            "type": type,
        }
        if type in ("cuboid", "cylinder"):
            obs["min_point"] = min_point
            obs["max_point"] = max_point
        elif type == "mesh":
            obs["file_path"] = file_path
            obs["position"] = position or [0.0, 0.0, 0.0]
            obs["orientation"] = orientation or [1.0, 0.0, 0.0, 0.0] # [qw, qx, qy, qz]
        else:
            raise ValueError(f"Unknown obstacle type: {type}")
        self.obstacles.append(obs)
        return obs

    # -- Builder context manager ---------------------------------------------

    @contextmanager
    def pipe(self, section: str, material: str, route: Optional[str] = None):
        """Context manager that yields a :class:`PipingBuilder`.

        When the block ends, the run it built is remembered on :attr:`pipe_runs`.
        """
        from tuba.builder import PipingBuilder

        builder = PipingBuilder(
            model=self,
            section_name=section,
            material_name=material,
            route_id=route,
        )
        yield builder
        builder.remember_run()

    def place_fragment(self, fragment, coordinate_system, *, name: str):
        """Place a local-coordinate fragment into this model."""
        from tuba.fragments import place_fragment

        return place_fragment(self, fragment, coordinate_system, name=name)

    # -- Placement frames ----------------------------------------------------

    def add_placement_frame(self, frame: PlacementFrame) -> PlacementFrame:
        """Register a named local placement frame."""
        if frame.id in self.placement_frames:
            raise ValueError(f"Placement frame {frame.id!r} already exists.")
        self.placement_frames[frame.id] = frame
        return frame

    def assign_placement(self, assignment: PlacementAssignment) -> PlacementAssignment:
        """Assign an entity to a placement frame."""
        self.placement_assignments.append(assignment)
        return assignment

    def resolve_placement_frame(self, frame: str) -> CoordinateSystem:
        """Resolve a placement frame ref into a model-global coordinate system."""
        frame_id = frame.split(":", 1)[1] if frame.startswith("placement_frame:") else frame
        return resolve_placement_frame(frame_id, self.placement_frames)

    def to_global_point(self, point, frame: str | None = None) -> np.ndarray:
        """Transform a point from a named frame to model-global coordinates."""
        if frame is None:
            return np.asarray(point, dtype=float)
        return self.resolve_placement_frame(frame).to_global_point(point)

    def to_global_vector(self, vector, frame: str | None = None) -> np.ndarray:
        """Transform a vector from a named frame to model-global coordinates."""
        if frame is None:
            return np.asarray(vector, dtype=float)
        return self.resolve_placement_frame(frame).to_global_vector(vector)

    # -- Code_Aster solve ----------------------------------------------------

    def solve(
        self,
        load_case: Optional[str] = None,
        operation: Optional[str] = None,
        pipe_modelization: PipeModelization | str | None = None,
        load_path: Optional[Sequence[str]] = None,
        load_step: float = 0.1,
        volume_element_ids: Optional[Sequence[str]] = None,
        max_element_size: Optional[float] = None,
        force: bool = False,
        **kwargs,
    ) -> AnalysisRun:
        """Run Code_Aster and return its provenance-bearing analysis run.

        Parameters
        ----------
        load_case : str, optional
            Name of the load case to solve.  If *None*, the first defined
            load case is used.
        operation : str, optional
            Name of a uniform operation to solve. Mutually exclusive with
            *load_case*.
        pipe_modelization : str, optional
            TUYAU_3M (unchanged default), POU_D_T for beam piping, or 3D.
            POU_D_T currently rejects pressure and tees/branches.
        load_path : sequence of str, optional
            Ordered absolute load-case endpoints for native POU_D_T shoes.
            Mutually exclusive with load_case and operation. Repeated names
            retain contact history; the last name is the compatibility load case.
        load_step : float, default 0.1
            Maximum requested pseudo-time increment per unit stage, in (0, 1].
            Code_Aster may subdivide further. This is not a physical time step.
        force : bool, default False
            Re-execute Code_Aster even when the solver work directory already
            holds an attested solve for this exact model and operation.

        Returns
        -------
        AnalysisRun
        """
        from tuba.solver.model_solve import solve_model

        return solve_model(
            self,
            load_case=load_case,
            operation=operation,
            pipe_modelization=pipe_modelization,
            load_path=load_path,
            load_step=load_step,
            volume_element_ids=volume_element_ids,
            max_element_size=max_element_size,
            force=force,
            **kwargs,
        )

    def validate(self) -> None:
        """Validate model references and structural invariants."""
        from tuba.validation import validate_model

        validate_model(self)

    def verify(self, **options: Any):
        """Run the one cold-model verification gate; see :func:`tuba.verify.verify_model`."""
        from tuba.verify import verify_model

        return verify_model(self, **options)

    def replace_with(self, other: "TubaModel") -> None:
        """Adopt *other*'s state in place, replacing this model's own.

        The single adopt path for a ``__dict__`` swap: a transaction publishes its
        candidate through this once the candidate validates, and a rollback restores a
        snapshot through it, so neither ever half-replaces the committed model. *other*
        is not copied; callers pass a candidate they own.
        """
        self.__dict__.clear()
        self.__dict__.update(other.__dict__)

    # -- Serialisation -------------------------------------------------------

    def to_dict(self) -> Dict[str, Any]:
        """Serialise to a plain dict matching the Tuba JSON schema."""
        return {
            "meta": {
                "project_name": self.project_name,
                "standard": self.standard,
                "version": MODEL_SERIALIZATION_VERSION,
            },
            "materials": {
                name: {
                    "E": m.E,
                    "nu": m.nu,
                    "rho": m.rho,
                    "alpha": m.alpha,
                    "allowable_stress": {str(k): v for k, v in m.allowable_stress.items()},
                }
                for name, m in self.materials.items()
            },
            "sections": {
                name: (
                    {
                        "type": "pipe",
                        "OD": s.OD,
                        "WT": s.WT,
                        "corrosion_allowance": s.corrosion_allowance,
                    }
                    if isinstance(s, PipeSection)
                    else {
                        "type": "bar",
                        "OD": s.OD,
                        "WT": s.WT,
                    }
                    if isinstance(s, BarSection)
                    else {
                        "type": "cable",
                        "radius": s.radius,
                        "pretension": s.pretension,
                        "compression_modulus_ratio": s.compression_modulus_ratio,
                    }
                    if isinstance(s, CableSection)
                    else {
                        "type": "rectangular",
                        "height_y": s.height_y,
                        "height_z": s.height_z,
                        "thickness_y": s.thickness_y,
                        "thickness_z": s.thickness_z,
                    }
                    if isinstance(s, RectangularSection)
                    else {
                        "type": "ibeam",
                        "profile_name": s.profile_name,
                        "properties": s.properties,
                    }
                    if isinstance(s, IBeamSection)
                    else {}
                )
                for name, s in self.sections.items()
            },
            "nodes": {nid: n.coords.tolist() for nid, n in self.nodes.items()},
            "elements": [e.to_dict() for e in self.elements],
            "supports": [s.to_dict() for s in self.supports],
            "load_cases": {
                name: {
                    "gravity": lc.gravity,
                    "internal_pressure": lc.internal_pressure,
                    "temperature": lc.temperature,
                    "ref_temperature": lc.ref_temperature,
                    **({"fields": [record.to_dict() for record in lc.fields]} if lc.fields else {}),
                    **({"nodal_forces": [force.to_dict() for force in lc.nodal_forces]} if lc.nodal_forces else {}),
                    **({"buckling": resolve_buckling_options(lc.buckling).to_dict()} if lc.buckling is not None else {}),
                   }
                for name, lc in self.load_cases.items()
            },
            "operations": {
                name: {
                    "gravity": op.gravity,
                    "internal_pressure": op.internal_pressure,
                    "temperature": op.temperature,
                    "ref_temperature": op.ref_temperature,
                    "metadata": op.metadata,
                    "fields": [field_record.to_dict() for field_record in op.fields],
                    **({"nodal_forces": [force.to_dict() for force in op.nodal_forces]} if op.nodal_forces else {}),
                    **({"buckling": resolve_buckling_options(op.buckling).to_dict()} if op.buckling is not None else {}),
                   }
                for name, op in self.operations.items()
            },
            "obstacles": copy.deepcopy(self.obstacles),
            "tees": {node: tee.to_dict() for node, tee in self.tees.items()},
            "groups": copy.deepcopy(self.groups),
            "placement_frames": {
                frame_id: frame.to_dict()
                for frame_id, frame in self.placement_frames.items()
            },
            "placement_assignments": [
                assignment.to_dict()
                for assignment in self.placement_assignments
            ],
            "specs": _serialize_specs(self.specs),
            "attributes": [assignment.to_dict() for assignment in self.attributes],
            "cad_assets": {
                asset_id: asset.to_dict()
                for asset_id, asset in self.cad_assets.items()
            },
            "imported_components": {
                component_id: component.to_dict()
                for component_id, component in self.imported_components.items()
            },
            "analysis_regions": {
                region_id: region.to_dict()
                for region_id, region in self.analysis_regions.items()
            },
            "ports": {
                port_id: port.to_dict()
                for port_id, port in self.ports.items()
            },
            "mesh_groups": {
                group_id: mesh_group.to_dict()
                for group_id, mesh_group in self.mesh_groups.items()
            },
            "couplings": {
                coupling_id: coupling.to_dict()
                for coupling_id, coupling in self.couplings.items()
            },
        }

    def to_json(self, path: Optional[str] = None, indent: int = 2) -> str:
        """Serialise to JSON string.  Optionally write to *path*."""
        text = json.dumps(self.to_dict(), indent=indent)
        if path:
            Path(path).write_text(text, encoding="utf-8")
        return text

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "TubaModel":
        """Reconstruct a TubaModel from a dict (inverse of :meth:`to_dict`)."""
        from tuba.schema import validate_model_dict

        validate_model_dict(data)
        meta = data.get("meta", {})
        model = cls(
            project_name=meta.get("project_name", "Untitled"),
            standard=meta.get("standard", ""),
        )

        for name, m in data.get("materials", {}).items():
            model.add_material(
                name=name,
                E=m["E"],
                nu=m["nu"],
                rho=m.get("rho", 7850.0),
                alpha=m.get("alpha", 0.0),
                allowable_stress={float(k): v for k, v in m.get("allowable_stress", {}).items()},
            )

        for name, s in data.get("sections", {}).items():
            t = s.get("type", "pipe")
            if t == "pipe":
                model.add_pipe_section(
                    name=name,
                    OD=s["OD"],
                    WT=s["WT"],
                    corrosion_allowance=s.get("corrosion_allowance", 0.0),
                )
            elif t == "bar":
                model.add_bar_section(
                    name=name,
                    OD=s["OD"],
                    WT=s["WT"],
                )
            elif t == "cable":
                model.add_cable_section(
                    name=name,
                    radius=s["radius"],
                    pretension=s.get("pretension", 0.0),
                    compression_modulus_ratio=s.get("compression_modulus_ratio", 1.0),
                )
            elif t == "rectangular":
                model.add_rectangular_section(
                    name=name,
                    height_y=s["height_y"],
                    height_z=s["height_z"],
                    thickness_y=s.get("thickness_y", 0.0),
                    thickness_z=s.get("thickness_z", 0.0),
                )
            elif t == "ibeam":
                sec = IBeamSection(name=name, profile_name=s["profile_name"], properties=s.get("properties", {}))
                model.sections[name] = sec

        for nid, coords in data.get("nodes", {}).items():
            model.nodes[nid] = Node(id=nid, coords=np.array(coords))
            model._index_node(nid)
            # Keep counter in sync
            num = int(nid.lstrip("N")) if nid.startswith("N") and nid[1:].isdigit() else 0
            model._node_counter = max(model._node_counter, num + 1)

        for e in data.get("elements", []):
            element_data = dict(e)
            if isinstance(element_data.get("bend_geometry"), dict):
                element_data["bend_geometry"] = BendGeometry.from_dict(element_data["bend_geometry"])
            model.add_element(**element_data)

        for s in data.get("supports", []):
            model.add_support(**s)

        for name, lc in data.get("load_cases", {}).items():
            load_case = model.define_load_case(
                name=name,
                gravity=lc.get("gravity", True),
                pressure=lc.get("internal_pressure", 0.0),
                temperature=lc.get("temperature", 20.0),
                ref_temperature=lc.get("ref_temperature", 20.0),
                fields=lc.get("fields", []),
                buckling=lc.get("buckling"),
            )
            for force_data in lc.get("nodal_forces", []):
                load_case.nodal_forces.append(NodalForce.from_dict(force_data))

        for name, op in data.get("operations", {}).items():
            operation = model.define_operation(
                name=name,
                gravity=op.get("gravity", True),
                pressure=op.get("internal_pressure", 0.0),
                temperature=op.get("temperature", 20.0),
                ref_temperature=op.get("ref_temperature", 20.0),
                metadata=op.get("metadata", {}),
                fields=op.get("fields", []),
                buckling=op.get("buckling"),
            )
            for force_data in op.get("nodal_forces", []):
                operation.nodal_forces.append(NodalForce.from_dict(force_data))

        for obs in data.get("obstacles", []):
            model.add_obstacle(**obs)

        for node_id, tee_info in data.get("tees", {}).items():
            model.define_tee(
                node=node_id,
                type=tee_info.get("type", "unreinforced_tee"),
                pad_thickness=tee_info.get("pad_thickness", 0.0)
            )

        model.groups = data.get("groups", {})
        model.placement_frames = {
            frame_id: PlacementFrame.from_dict(frame_data)
            for frame_id, frame_data in data.get("placement_frames", {}).items()
        }
        model.placement_assignments = [
            PlacementAssignment.from_dict(item)
            for item in data.get("placement_assignments", [])
        ]
        model.specs = _deserialize_specs(data.get("specs", {}))
        model.attributes = [
            AttributeAssignment.from_dict(assignment)
            for assignment in data.get("attributes", [])
        ]
        model.cad_assets = {
            asset_id: CadAsset.from_dict(asset)
            for asset_id, asset in data.get("cad_assets", {}).items()
        }
        model.imported_components = {
            component_id: ImportedComponent.from_dict(component)
            for component_id, component in data.get("imported_components", {}).items()
        }
        model.analysis_regions = {
            region_id: AnalysisRegion.from_dict(region)
            for region_id, region in data.get("analysis_regions", {}).items()
        }
        model.ports = {
            port_id: Port.from_dict(port)
            for port_id, port in data.get("ports", {}).items()
        }
        model.mesh_groups = {
            group_id: MeshGroup.from_dict(mesh_group)
            for group_id, mesh_group in data.get("mesh_groups", {}).items()
        }
        model.couplings = {
            coupling_id: CouplingSpec.from_dict(coupling)
            for coupling_id, coupling in data.get("couplings", {}).items()
        }

        return model

    @classmethod
    def from_json(cls, path: str) -> "TubaModel":
        """Load from a JSON file."""
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        return cls.from_dict(data)

    def __repr__(self) -> str:
        return (
            f"TubaModel('{self.project_name}', "
            f"{len(self.nodes)} nodes, "
            f"{len(self.elements)} elements, "
            f"{len(self.supports)} supports)"
        )


_GROUP_MEMBER_KEYS = {
    "node": "nodes",
    "element": "elements",
    "support": "supports",
    "obstacle": "obstacles",
    "assembly": "assemblies",
    "route": "routes",
}


def _serialize_specs(specs: Dict[str, Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    serialized: Dict[str, Dict[str, Any]] = {}
    for kind, entries in specs.items():
        serialized[kind] = {}
        for spec_id, spec in entries.items():
            if hasattr(spec, "to_dict"):
                serialized[kind][spec_id] = spec.to_dict()
            else:
                serialized[kind][spec_id] = spec
    return serialized


def make_bend_geometry(
    *,
    start: Any,
    end: Any,
    radius: float,
    angle: float,
    normal: Any,
    start_tangent: Any,
    end_tangent: Any,
    generation_mode: str,
) -> BendGeometry:
    """Create an explicit circular bend record from endpoints and tangents."""

    start_arr = np.asarray(start, dtype=float)
    end_arr = np.asarray(end, dtype=float)
    normal_arr = _unit_vector(normal, "bend normal")
    start_tangent_arr = _unit_vector(start_tangent, "bend start tangent")
    end_tangent_arr = _unit_vector(end_tangent, "bend end tangent")
    radius_value = float(radius)
    angle_value = float(angle)
    if radius_value <= 0.0:
        raise ValueError("Bend radius must be positive.")

    chord = end_arr - start_arr
    chord_len = float(np.linalg.norm(chord))
    if chord_len <= 1e-12:
        raise ValueError("Bend endpoints must be distinct.")
    if chord_len > 2.0 * radius_value + 1e-9:
        raise ValueError("Bend chord length exceeds the requested radius.")

    chord_dir = chord / chord_len
    half = chord_len / 2.0
    offset_len = math.sqrt(max(radius_value**2 - half**2, 0.0))
    side = np.cross(normal_arr, chord_dir)
    if np.linalg.norm(side) <= 1e-12:
        raise ValueError("Bend normal must not be parallel to the bend chord.")
    side = side / np.linalg.norm(side)
    midpoint = (start_arr + end_arr) / 2.0
    candidates = (midpoint + side * offset_len, midpoint - side * offset_len)

    tangent_normal = normal_arr if angle_value >= 0.0 else -normal_arr

    def tangent_for(center: np.ndarray) -> np.ndarray:
        radial = start_arr - center
        tangent = np.cross(tangent_normal, radial)
        if np.linalg.norm(tangent) <= 1e-12:
            return tangent
        return tangent / np.linalg.norm(tangent)

    center = max(candidates, key=lambda candidate: float(np.dot(tangent_for(candidate), start_tangent_arr)))
    stored_start_tangent = tangent_for(center)
    end_radial = end_arr - center
    stored_end_tangent = np.cross(tangent_normal, end_radial)
    if np.linalg.norm(stored_end_tangent) <= 1e-12:
        stored_end_tangent = end_tangent_arr
    else:
        stored_end_tangent = stored_end_tangent / np.linalg.norm(stored_end_tangent)
    if float(np.dot(stored_end_tangent, end_tangent_arr)) < 0.0:
        stored_end_tangent = -stored_end_tangent
    return BendGeometry(
        center=[float(value) for value in center],
        normal=[float(value) for value in tangent_normal],
        radius=radius_value,
        angle=abs(angle_value),
        start_tangent=[float(value) for value in stored_start_tangent],
        end_tangent=[float(value) for value in stored_end_tangent],
        generation_mode=generation_mode,
    )


def sample_bend_geometry(start: Any, geometry: BendGeometry, *, n_segments: int = 16) -> np.ndarray:
    """Sample a circular bend arc from its explicit geometry record."""

    center = np.asarray(geometry.center, dtype=float)
    normal = _unit_vector(geometry.normal, "bend normal")
    start_arr = np.asarray(start, dtype=float)
    radial = start_arr - center
    radial_norm = float(np.linalg.norm(radial))
    if radial_norm <= 1e-12:
        raise ValueError("Bend start point must not be at the bend center.")
    radial = radial / radial_norm * float(geometry.radius)
    tangent = np.cross(normal, radial)
    start_tangent = _unit_vector(geometry.start_tangent, "bend start tangent")
    if float(np.dot(tangent, start_tangent)) < 0.0:
        normal = -normal
        tangent = -tangent
    steps = max(int(n_segments), 1)
    theta = math.radians(abs(float(geometry.angle)))
    return np.array(
        [
            center + radial * math.cos(theta * i / steps) + tangent * math.sin(theta * i / steps)
            for i in range(steps + 1)
        ],
        dtype=float,
    )


def _unit_vector(values: Any, label: str) -> np.ndarray:
    arr = np.asarray(values, dtype=float)
    if arr.shape != (3,) or not np.all(np.isfinite(arr)):
        raise ValueError(f"{label} must be a finite 3-vector.")
    norm = float(np.linalg.norm(arr))
    if norm <= 1e-12:
        raise ValueError(f"{label} must be non-zero.")
    return arr / norm


def _deserialize_specs(data: Dict[str, Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    specs: Dict[str, Dict[str, Any]] = {}
    for kind, entries in data.items():
        if kind == "insulation":
            specs[kind] = {
                spec_id: InsulationSpec.from_dict(spec_id, spec_data)
                for spec_id, spec_data in entries.items()
            }
        else:
            specs[kind] = dict(entries)
    return specs


def _point_index_key(coords, tol: float = 1e-6) -> Tuple[int, int, int]:
    arr = np.asarray(coords, dtype=float)
    return tuple(int(round(float(value) / tol)) for value in arr)
