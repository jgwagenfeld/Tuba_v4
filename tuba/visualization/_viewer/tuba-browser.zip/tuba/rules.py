"""Composable model rule checks for proxy engineering diagnostics."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol

from tuba.clash import ClashEngine
from tuba.model import TubaModel
from tuba.physical import element_length
from tuba.refs import EntityRef


@dataclass(frozen=True)
class RuleResult:
    rule_id: str
    passed: bool
    severity: str
    message: str
    refs: list[EntityRef] = field(default_factory=list)
    data: dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> dict[str, Any]:
        return {
            "rule_id": self.rule_id,
            "passed": self.passed,
            "severity": self.severity,
            "message": self.message,
            "refs": [ref.to_dict() for ref in self.refs],
            "data": dict(self.data),
        }


@dataclass(frozen=True)
class RuleReport:
    results: list[RuleResult] = field(default_factory=list)

    @property
    def passed(self) -> bool:
        return all(result.passed for result in self.results)

    def to_dict(self) -> dict[str, Any]:
        return {
            "passed": self.passed,
            "results": [result.to_dict() for result in self.results],
        }


class ModelRule(Protocol):
    rule_id: str

    def evaluate(self, model: TubaModel) -> list[RuleResult]:
        ...


class RuleEngine:
    def __init__(self, rules: list[ModelRule]):
        self.rules = rules

    def evaluate(self, model: TubaModel) -> RuleReport:
        results: list[RuleResult] = []
        for rule in self.rules:
            results.extend(rule.evaluate(model))
        return RuleReport(results=results)


@dataclass(frozen=True)
class SupportSpacingRule:
    max_span_m: float
    rule_id: str = "support_spacing"

    def evaluate(self, model: TubaModel) -> list[RuleResult]:
        results: list[RuleResult] = []
        pipes = sorted((elem for elem in model.elements
                        if elem.type in ("pipe_straight", "pipe_bend")), key=lambda elem: elem.id)
        connected = {}
        for elem in pipes:
            for node in (elem.n1, elem.n2):
                connected.setdefault(node, []).append(elem)
        boundaries = {support.node for support in model.supports}
        # ponytail: junctions bound this topology screen; branched load paths need a structural span check.
        boundaries.update(node for node, members in connected.items() if len(members) != 2)
        visited = set()
        for elem in pipes:
            if elem.id in visited:
                continue
            members = [elem]
            visited.add(elem.id)
            # A load or mesh split is not a support. Walk both ends of the seed
            # element to actual supports, branches or endpoints; visited edges
            # also terminate closed loops without a declared support.
            for node in (elem.n1, elem.n2):
                while node not in boundaries:
                    next_elem = next((candidate for candidate in connected[node]
                                      if candidate.id not in visited), None)
                    if next_elem is None:
                        break
                    members.append(next_elem)
                    visited.add(next_elem.id)
                    node = next_elem.n2 if next_elem.n1 == node else next_elem.n1
            members.sort(key=lambda member: member.id)
            length = sum(element_length(model, member) for member in members)
            if length <= self.max_span_m:
                continue
            subject = (f"Element {members[0].id!r}" if len(members) == 1
                       else f"Pipe elements {[member.id for member in members]!r}")
            results.append(
                RuleResult(
                    rule_id=self.rule_id,
                    passed=False,
                    severity="warning",
                    message=f"{subject} span {length:.6g} m exceeds max {self.max_span_m:.6g} m.",
                    refs=[EntityRef("element", member.id) for member in members],
                    data={"span_m": length, "max_span_m": self.max_span_m},
                )
            )
        return results


@dataclass(frozen=True)
class ClashFreeRule:
    clearance_m: float = 0.0
    include_self: bool = True
    include_duplicate_nodes: bool = True
    duplicate_tol_m: float = 0.001
    rule_id: str = "clash_free"

    def evaluate(self, model: TubaModel) -> list[RuleResult]:
        results: list[RuleResult] = []
        engine = ClashEngine()
        for clash in engine.check_all(
            model, clearance_m=self.clearance_m, duplicate_tol_m=self.duplicate_tol_m
        ):
            if clash.right.kind == "obstacle":
                results.append(
                    RuleResult(
                        rule_id=self.rule_id,
                        passed=False,
                        severity="error" if clash.severity == "hard" else "warning",
                        message=(
                            f"{clash.left} clashes with {clash.right}: "
                            f"penetration {clash.penetration_m:.6g} m."
                        ),
                        refs=[clash.left, clash.right],
                        data=clash.to_dict(),
                    )
                )
            elif clash.metadata.get("check") == "duplicate_node":
                if not self.include_duplicate_nodes:
                    continue
                results.append(
                    RuleResult(
                        rule_id=self.rule_id,
                        passed=False,
                        severity="error",
                        message=(
                            f"{clash.left} duplicates {clash.right}: "
                            f"merge to one node ({clash.diagnostics[0] if clash.diagnostics else ''})"
                        ),
                        refs=[clash.left, clash.right],
                        data=clash.to_dict(),
                    )
                )
            else:
                if not self.include_self:
                    continue
                overlap = clash.metadata.get("overlap_type", "crossing")
                results.append(
                    RuleResult(
                        rule_id=self.rule_id,
                        passed=False,
                        severity="error",
                        message=(
                            f"{clash.left} clashes with {clash.right} "
                            f"({overlap}, no shared node/support/coupling): "
                            f"penetration {clash.penetration_m:.6g} m."
                        ),
                        refs=[clash.left, clash.right],
                        data=clash.to_dict(),
                    )
                )
        return results
