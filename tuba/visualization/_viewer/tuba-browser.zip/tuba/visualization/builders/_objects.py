"""Model-object builders: elements, supports, obstacles, envelopes."""

from __future__ import annotations
from dataclasses import asdict, replace
from typing import Any
from tuba.model import Element
from tuba.model import TubaModel
from tuba.geometry.profiles import profile_for_section
from tuba.geometry.section_mesh import straight_section_surface_mesh
from tuba.physical import element_quantities
from tuba.physical import physical_properties_for_element
from tuba.refs import EntityRef
from tuba.visualization.scene import GeometryAsset
from tuba.visualization.scene import Overlay
from tuba.visualization.scene import SceneDiagnostic
from tuba.visualization.scene import SceneObject
from tuba.visualization.builders._contract import SceneBuildOptions, SceneContribution
from tuba.visualization.builders._helpers import _asset_id, _bounds_for_points, _element_kind, _element_points, _groups_for_element, _ifc_source_for_ref, _node_coords, _object_id, _obstacle_bounds, _script_line_fields


_PROFILE_DIMENSION_KEYS = {
    "OD": "outer_diameter_m",
    "WT": "wall_thickness_m",
    "ID": "inner_diameter_m",
    "H": "height_m",
    "B": "width_m",
    "Tw": "web_thickness_m",
    "Tf": "flange_thickness_m",
    "radius": "radius_m",
    "pretension": "pretension_n",
    "height_y": "height_y_m",
    "height_z": "height_z_m",
    "thickness_y": "thickness_y_m",
    "thickness_z": "thickness_z_m",
}
def _profile_metadata(model: TubaModel, elem: Element) -> dict[str, Any]:
    profile = profile_for_section(model.sections[elem.section])
    data: dict[str, Any] = {
        "section": elem.section,
        "kind": profile.kind,
        "area_m2": profile.area_m2,
        "collision_radius_m": profile.collision_radius_m,
    }
    for key, value in profile.dimensions.items():
        data[_PROFILE_DIMENSION_KEYS.get(key, key)] = value
    return data
def _build_element_object(
    model: TubaModel,
    elem: Element,
    options: SceneBuildOptions,
    ifc_guid_map: dict[str, str] | None = None,
    *,
    volume_skin: bool = False,
    tee_surface: dict[str, list] | None = None,
) -> SceneContribution:
    """One element's scene contribution; *volume_skin* hides its display geometry behind the mesh."""
    diagnostics: list[SceneDiagnostic] = []
    entity_ref = EntityRef("element", elem.id)
    asset_id = _asset_id(entity_ref)
    metadata: dict[str, Any] = {
        "element_type": elem.type,
        "section": elem.section,
        "material": elem.material,
        "nodes": [elem.n1, elem.n2],
        "groups": _groups_for_element(model, elem.id),
    }
    metadata["profile"] = _profile_metadata(model, elem)
    if elem.bend_geometry is not None:
        metadata["bend_geometry"] = elem.bend_geometry.to_dict()
    metadata.update(_script_line_fields(elem))
    property_lines: dict[str, Any] = {
        key: line
        for key, line in (
            ("section", getattr(model.sections.get(elem.section), "source_line", None)),
            ("material", getattr(model.materials.get(elem.material), "source_line", None)),
        )
        if line is not None
    }

    if options.include_attributes:
        assignments = model.get_attribute_assignments(entity_ref)
        if assignments:
            metadata["attributes"] = {key: assignment.value for key, assignment in assignments.items()}
        attribute_lines = {
            key: assignment.source_line for key, assignment in assignments.items() if assignment.source_line is not None
        }
        if attribute_lines:
            property_lines["attributes"] = attribute_lines
        insulation = model.get_insulation(entity_ref)
        if insulation is not None:
            metadata["insulation"] = {"id": insulation.id, **insulation.to_dict()}
    if property_lines:
        metadata["property_lines"] = property_lines

    physical: dict[str, Any] = {}
    if options.include_physical:
        try:
            physical = asdict(physical_properties_for_element(model, elem))
        except Exception as exc:  # pragma: no cover - diagnostic path
            diagnostics.append(
                SceneDiagnostic(
                    severity="warning",
                    message=f"Could not compute physical properties for element {elem.id!r}: {exc}",
                    target=str(entity_ref),
                )
            )

    quantities: dict[str, Any] = {}
    if options.include_quantities:
        try:
            quantities = asdict(element_quantities(model, elem))
        except Exception as exc:  # pragma: no cover - diagnostic path
            diagnostics.append(
                SceneDiagnostic(
                    severity="warning",
                    message=f"Could not compute quantities for element {elem.id!r}: {exc}",
                    target=str(entity_ref),
                )
            )

    points = _element_points(model, elem)
    profile = metadata["profile"]
    radius = float(physical.get("bare_radius_m") or profile.get("collision_radius_m") or 0.0)
    generation_config: dict[str, Any] = {
        "source": "tuba.element",
        "entity_ref": str(entity_ref),
        "points": points,
        "radius_m": radius,
    }
    inner_diameter = profile.get("inner_diameter_m")
    if elem.type.startswith("pipe") and inner_diameter is not None:
        generation_config["inner_radius_m"] = float(inner_diameter) / 2.0
    asset_format = "tube"
    asset_bounds = _bounds_for_points(points, radius)
    if tee_surface is not None:
        generation_config.update(tee_surface, source="tuba.tee_wall")
        metadata["display_geometry"] = "Idealized joined tee wall; no manufacturer fillet"
        asset_format = "mesh"
        asset_bounds = _bounds_for_points(tee_surface["vertices"], 0.0)
    if not elem.type.startswith("pipe"):
        surface = straight_section_surface_mesh(
            model.sections[elem.section],
            points[0],
            points[-1],
            twist_angle_deg=float(getattr(elem, "twist_angle", 0.0)),
        )
        generation_config.update(
            vertices=[list(vertex) for vertex in surface.vertices],
            faces=[list(face) for face in surface.faces],
        )
        asset_format = "mesh"
        asset_bounds = _bounds_for_points(generation_config["vertices"], 0.0)
    asset = GeometryAsset(
        id=asset_id,
        format=asset_format,
        bounds=asset_bounds,
        object_ids=[_object_id(entity_ref)],
        generation_config=generation_config,
    )
    scene_object = SceneObject(
        id=_object_id(entity_ref),
        entity_ref=entity_ref,
        kind=_element_kind(elem),
        name=elem.id,
        geometry_asset_id=asset_id,
        group_ids=metadata["groups"],
        metadata=metadata,
        quantities=quantities,
        physical=physical,
        source=_ifc_source_for_ref(model, entity_ref, ifc_guid_map or {}),
    )
    envelope_objects: list[SceneObject] = []
    envelope_assets: list[GeometryAsset] = []
    envelope_overlays: list[Overlay] = []
    if elem.type.startswith("pipe") and physical.get("insulation_thickness_m", 0) > 0:
        envelope_objects, envelope_assets, envelope_overlays = _build_physical_envelopes(
            elem=elem,
            entity_ref=entity_ref,
            points=points,
            physical=physical,
        )
    if volume_skin:
        # The mesh skin replaces this element's surface on screen. The skin is
        # the discretisation of the same VolumeGeometry the element was meshed
        # from, so the scene keeps one solid, not a second display sweep.
        return SceneContribution(
            objects=(replace(scene_object, geometry_asset_id=None, layer_ids=["analysis_mesh:volume_skin"]),),
            diagnostics=tuple(diagnostics),
        )
    return SceneContribution(
        objects=tuple([scene_object, *envelope_objects]),
        assets=tuple([asset, *envelope_assets]),
        diagnostics=tuple(diagnostics),
        overlays=tuple(envelope_overlays),
    )
def _build_physical_envelopes(
    *,
    elem: Element,
    entity_ref: EntityRef,
    points: list[list[float]],
    physical: dict[str, Any],
) -> tuple[list[SceneObject], list[GeometryAsset], list[Overlay]]:
    envelope_specs = _physical_envelope_specs(physical)
    objects: list[SceneObject] = []
    assets: list[GeometryAsset] = []
    overlays: list[Overlay] = []
    for spec in envelope_specs:
        envelope_type = spec["envelope_type"]
        object_id = f"object:physical_envelope:{entity_ref}:{envelope_type}"
        asset_id = f"geometry:physical_envelope:{entity_ref}:{envelope_type}"
        overlay_id = f"overlay:physical_envelope:{entity_ref}:{envelope_type}"
        radius = float(spec["radius_m"])
        assets.append(
            GeometryAsset(
                id=asset_id,
                format="tube_envelope",
                bounds=_bounds_for_points(points, radius),
                object_ids=[object_id],
                generation_config={
                    "source": "tuba.physical_envelope",
                    "entity_ref": str(entity_ref),
                    "envelope_type": envelope_type,
                    "points": points,
                    "radius_m": radius,
                    "source_data": spec["source"],
                    "inner_radius_m": float(physical["bare_radius_m"]),
                    "color": "#a8b5ad",
                    "opacity": 1.0,
                },
            )
        )
        objects.append(
            SceneObject(
                id=object_id,
                kind="physical_envelope",
                name=f"{elem.id} insulation {physical['insulation_thickness_m'] * 1000:g} mm",
                geometry_asset_id=asset_id,
                layer_ids=[f"physical_envelope:{envelope_type}"],
                metadata={
                    "entity_ref": str(entity_ref),
                    "envelope_type": envelope_type,
                    "radius_m": radius,
                    "diameter_m": radius * 2.0,
                    "source": spec["source"],
                },
            )
        )
        overlays.append(
            Overlay(
                id=overlay_id,
                kind="physical_envelope",
                object_ids=[object_id],
                entity_refs=[entity_ref],
                name=f"{elem.id} {envelope_type}",
                data={
                    "entity_ref": str(entity_ref),
                    "envelope_type": envelope_type,
                    "radius_m": radius,
                    "source": spec["source"],
                },
            )
        )
    return objects, assets, overlays
def _groups_for_node(model: TubaModel, node_id: str) -> list[str]:
    return sorted(
        group_name
        for group_name, group in model.groups.items()
        if node_id in group.get("nodes", [])
    )


def _build_support_object(model: TubaModel, support) -> tuple[SceneObject, GeometryAsset]:
    entity_ref = EntityRef("support", support.id)
    coords = _node_coords(model, support.node)
    attached_radii = [
        profile_for_section(model.sections[element.section]).collision_radius_m
        for element in model.elements
        if support.node in (element.n1, element.n2)
    ]
    # Source lines are script links, not restraint properties: object metadata only.
    # Both records come from the one restraint() the DDL and the contact shoe read,
    # so the glyph cannot claim a different restraint than the one compiled.
    restraint = support.restraint()
    support_data = {
        "support_id": support.id,
        "support_type": support.type,
        # The solver's own restraint states, so the viewer renders what Code_Aster compiles.
        "dof_states": list(restraint.states),
        # A prescribed displacement compiles to a penalty spring, not a hard
        # constraint, and the stiffness is what says so. Without it a reader sees
        # a prescribed 4 mm and has no way to know the support is a spring.
        "spring_stiffness": [value for value in restraint.spring_stiffness if value != 0.0],
        **{
            key: value
            for key, value in asdict(support).items()
            if key not in {"id", "node", "type", "source_line", "source_call_line"}
            and value is not None
            and not (key == "gap" and value == 0)
        },
    }
    if support.type == "rest":
        import math
        raw = [float(v) for v in (support.direction or (0.0, 0.0, 1.0))]
        norm = math.hypot(*raw)
        support_data["contact_normal"] = [v / norm for v in raw] if norm > 0 else [0.0, 0.0, 1.0]
    if support.attached_to is not None:
        # Which authored group owns the far end, so the panel can name the
        # structure (e.g. "N3 (rack_A)") without guessing from the scene.
        support_data["attached_to_groups"] = _groups_for_node(model, support.attached_to)
    asset = GeometryAsset(
        id=_asset_id(entity_ref),
        format="point",
        bounds=_bounds_for_points([coords], 0.0),
        object_ids=[_object_id(entity_ref)],
        generation_config={
            "source": "tuba.support",
            "entity_ref": str(entity_ref),
            "point": coords,
            **({"radius_m": max(attached_radii)} if attached_radii else {}),
            **support_data,
        },
    )
    scene_object = SceneObject(
        id=_object_id(entity_ref),
        entity_ref=entity_ref,
        kind="support",
        name=support.id,
        geometry_asset_id=asset.id,
        metadata={
            "node": support.node,
            **support_data,
            **_script_line_fields(support),
            **({"property_lines": {"restraint": support.source_line}} if support.source_line is not None else {}),
        },
    )
    return scene_object, asset


def _build_support_link_object(
    model: TubaModel, support
) -> tuple[SceneObject, GeometryAsset] | None:
    """A thin P->A link for an attached support; None when grounded.

    The DOF glyph at P says *what* is restrained. This says *what it is
    restrained to*. Ground supports need no link: the hatch on the glyph
    (viewer) says ground.
    """
    if support.attached_to is None:
        return None
    if support.attached_to not in model.nodes or support.node not in model.nodes:
        return None
    start = _node_coords(model, support.node)
    end = _node_coords(model, support.attached_to)
    if start == end:
        return None
    object_id = f"object:support_link:{support.id}"
    asset_id = f"geometry:support_link:{support.id}"
    groups = _groups_for_node(model, support.attached_to)
    asset = GeometryAsset(
        id=asset_id,
        format="polyline",
        bounds=_bounds_for_points([start, end], 0.0),
        object_ids=[object_id],
        generation_config={
            "source": "tuba.support_link",
            "entity_ref": f"support:{support.id}",
            "support_id": support.id,
            "node": support.node,
            "attached_to": support.attached_to,
            "attached_to_groups": groups,
            "points": [start, end],
            "color": "#64748b",
        },
    )
    scene_object = SceneObject(
        id=object_id,
        entity_ref=None,
        kind="support_link",
        name=f"{support.id} link",
        geometry_asset_id=asset.id,
        metadata={
            "support_id": support.id,
            "node": support.node,
            "attached_to": support.attached_to,
            "attached_to_groups": groups,
        },
    )
    return scene_object, asset


def _build_obstacle_object(obstacle: dict[str, Any]) -> tuple[SceneObject, GeometryAsset]:
    entity_ref = EntityRef("obstacle", obstacle["id"])
    bounds = _obstacle_bounds(obstacle)
    asset = GeometryAsset(
        id=_asset_id(entity_ref),
        format=obstacle.get("type", "obstacle"),
        bounds=bounds,
        object_ids=[_object_id(entity_ref)],
        generation_config={"source": "tuba.obstacle", "entity_ref": str(entity_ref), "obstacle": dict(obstacle)},
    )
    scene_object = SceneObject(
        id=_object_id(entity_ref),
        entity_ref=entity_ref,
        kind="obstacle",
        name=obstacle["id"],
        geometry_asset_id=asset.id,
        metadata=dict(obstacle),
    )
    return scene_object, asset
def _physical_envelope_specs(physical: dict[str, Any]) -> list[dict[str, Any]]:
    if not physical.get("insulation_spec_id") or physical.get("insulation_thickness_m", 0) <= 0:
        return []
    return [{"envelope_type": "insulation", "radius_m": float(physical["effective_radius_m"]),
             "source": {"type": "insulation", "insulation_id": physical["insulation_spec_id"],
                        "thickness_m": float(physical["insulation_thickness_m"]), "field": "effective_radius_m"}}]
