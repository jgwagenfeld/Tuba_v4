"""IFC export helpers for Tuba pipe systems."""

from __future__ import annotations

from typing import Any

import ifcopenshell.guid
import numpy as np

from tuba.external.ifc_mapping import IfcGuidRegistry, add_property_set, ifc_property
from tuba.external.ifc_placements import create_local_placement, placement_for_target, product_local_points

# Second body representation carrying the solved operating shape. "Body" stays
# the as-built geometry so a viewer that knows only the standard identifier is
# unaffected; a clash run selects this one.
OPERATING_BODY_IDENTIFIER = "OperatingBody"


def export_pipe_products(
    ifc_file: Any,
    model: Any,
    storey: Any,
    project_context: Any,
    registry: IfcGuidRegistry,
    result_state: Any | None = None,
) -> dict[str, Any]:
    created: dict[str, Any] = {}
    pipe_elements = [elem for elem in model.elements if elem.type in ("pipe_straight", "pipe_bend")]
    if not pipe_elements:
        return created

    products = []
    for elem in pipe_elements:
        product = _create_pipe_product(ifc_file, model, elem, project_context, registry, result_state)
        created[elem.id] = product
        products.append(product)

    ifc_file.create_entity(
        "IfcRelContainedInSpatialStructure",
        GlobalId=ifcopenshell.guid.new(),
        RelatingStructure=storey,
        RelatedElements=products,
    )
    system = ifc_file.create_entity(
        "IfcDistributionSystem",
        GlobalId=registry.guid_for(f"pipe-system:{model.project_name}"),
        Name=model.project_name,
        PredefinedType="NOTDEFINED",
    )
    ifc_file.create_entity(
        "IfcRelAssignsToGroup",
        GlobalId=ifcopenshell.guid.new(),
        Name=f"{model.project_name} pipe run",
        RelatedObjects=products,
        RelatingGroup=system,
    )
    ifc_file.create_entity(
        "IfcRelServicesBuildings",
        GlobalId=ifcopenshell.guid.new(),
        Name=f"{model.project_name} services",
        RelatingSystem=system,
        RelatedBuildings=[storey],
    )
    return created


def _create_pipe_product(
    ifc_file: Any,
    model: Any,
    elem: Any,
    context: Any,
    registry: IfcGuidRegistry,
    result_state: Any | None = None,
) -> Any:
    cls_name = "IfcPipeFitting" if elem.type == "pipe_bend" else "IfcPipeSegment"
    kwargs = {}
    if elem.type == "pipe_bend":
        kwargs["PredefinedType"] = "BEND"
    product = ifc_file.create_entity(
        cls_name,
        GlobalId=registry.guid_for(f"element:{elem.id}"),
        Name=elem.id,
        Description=f"Material: {elem.material}, Section: {elem.section}",
        **kwargs,
    )
    frame = placement_for_target(model, f"element:{elem.id}")
    if frame is not None:
        product.ObjectPlacement = create_local_placement(ifc_file, frame)
    section = model.sections[elem.section]
    add_property_set(
        ifc_file,
        product,
        "Pset_TubaPipe",
        [
            ifc_property(ifc_file, "SectionName", elem.section),
            ifc_property(ifc_file, "MaterialName", elem.material),
            ifc_property(ifc_file, "OuterDiameterM", float(section.OD)),
            ifc_property(ifc_file, "WallThicknessM", float(section.WT)),
        ],
    )
    axis_points = product_local_points(_pipe_axis_points(model, elem), frame)
    body = _swept_disk_body(ifc_file, model, elem, axis_points)
    axis = ifc_file.create_entity(
        "IfcShapeRepresentation",
        ContextOfItems=context,
        RepresentationIdentifier="Axis",
        RepresentationType="Curve3D",
        Items=[_polyline(ifc_file, axis_points)],
    )
    body_rep = ifc_file.create_entity(
        "IfcShapeRepresentation",
        ContextOfItems=context,
        RepresentationIdentifier="Body",
        RepresentationType="SweptSolid",
        Items=[body],
    )
    # The cold body is what a viewer draws; the operating body is what a clash
    # run has to see. A hot line grows into space the as-built shape never
    # occupies, and a property saying how far it moved is not something a BIM
    # clash engine can intersect.
    representations = [axis, body_rep]
    operating_body = operating_swept_disk(ifc_file, model, elem, _pipe_axis_points(model, elem), result_state, frame)
    if operating_body is not None:
        representations.append(
            ifc_file.create_entity(
                "IfcShapeRepresentation",
                ContextOfItems=context,
                RepresentationIdentifier=OPERATING_BODY_IDENTIFIER,
                RepresentationType="SweptSolid",
                Items=[operating_body],
            )
        )
    product.Representation = ifc_file.create_entity("IfcProductDefinitionShape", Representations=representations)
    if elem.type == "pipe_bend":
        add_property_set(
            ifc_file,
            product,
            "Pset_TubaPipeBend",
            [
                ifc_property(ifc_file, "BendRadiusM", float(elem.bend_radius or 0.0)),
                ifc_property(ifc_file, "BendAngleDeg", float(elem.bend_angle or 0.0)),
            ],
        )
    return product


def operating_swept_disk(
    ifc_file: Any, model: Any, elem: Any, cold_points: list[np.ndarray], result_state: Any | None,
    frame: Any | None = None,
) -> Any | None:
    """Build the pipe's swept disk on its operating centreline, or None."""
    if result_state is None:
        return None
    from tuba.analysis.projection import displace_polyline

    points = [
        np.asarray(point, dtype=float)
        for point in displace_polyline(element=elem, result_state=result_state, points=cold_points)
    ]
    return _swept_disk_body(ifc_file, model, elem, product_local_points(points, frame))


def _pipe_axis_points(model: Any, elem: Any) -> list[np.ndarray]:
    if elem.type != "pipe_bend" or elem.bend_radius is None or elem.bend_angle is None:
        return [
            np.asarray(model.nodes[elem.n1].coords, dtype=float),
            np.asarray(model.nodes[elem.n2].coords, dtype=float),
        ]

    from tuba.solver.aster import CodeAsterSolver

    center, axis, r1, theta = CodeAsterSolver._get_bend_geometry(model, elem)
    steps = 8
    points = []
    for index in range(steps + 1):
        t = index / steps
        angle = theta * t
        rotated = _rotate_about_axis(r1, axis, angle)
        points.append(center + rotated)
    return points


def _rotate_about_axis(vector: np.ndarray, axis: np.ndarray, angle: float) -> np.ndarray:
    axis = np.asarray(axis, dtype=float)
    axis = axis / np.linalg.norm(axis)
    vector = np.asarray(vector, dtype=float)
    return (
        vector * np.cos(angle)
        + np.cross(axis, vector) * np.sin(angle)
        + axis * np.dot(axis, vector) * (1.0 - np.cos(angle))
    )

def _swept_disk_body(ifc_file: Any, model: Any, elem: Any, axis_points: list[np.ndarray]) -> Any:
    section = model.sections[elem.section]
    radius = float(section.OD / 2.0)
    inner_radius = float(max(section.OD - 2.0 * section.WT, 0.0) / 2.0)
    return ifc_file.create_entity(
        "IfcSweptDiskSolid",
        Directrix=_polyline(ifc_file, axis_points),
        Radius=radius,
        InnerRadius=inner_radius,
    )


def _polyline(ifc_file: Any, points: list[np.ndarray]) -> Any:
    ifc_points = [
        ifc_file.create_entity("IfcCartesianPoint", Coordinates=[float(p[0]), float(p[1]), float(p[2])])
        for p in points
    ]
    return ifc_file.create_entity("IfcPolyline", Points=ifc_points)
