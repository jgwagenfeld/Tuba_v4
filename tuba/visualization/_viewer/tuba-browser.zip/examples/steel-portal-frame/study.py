"""Solve the hall's gravity and wind cases, or import its committed evidence.

The interface is the one every ``examples/`` project uses: ``LOAD_CASES``,
``SOLVER_OPTIONS``, ``VOLUME_EXPORT``, ``ARTIFACT_DIR`` and ``build_review``, so
the studio, the gallery builder and the refresh tooling all load it unchanged.

Evidence lives in ``evidence/<case>/`` and is attested to the model by
``validate_for_publication``, which is what stops a stale folder from being
presented as this hall's result.
"""

from pathlib import Path
from types import SimpleNamespace

import numpy as np

from tuba.analysis import create_visual_deformed_geometry_state
from tuba.analysis.code_aster_artifacts import import_code_aster_artifacts
from tuba.analysis.staged_run import stage_runs
from tuba.project import load_project
from tuba.project.solve import solve_project
from tuba.reporting import build_engineering_review
from tuba.visualization import (
    SceneBuildOptions,
    SceneRequest,
    add_scene_label,
    build_visualization_scene,
    write_engineering_review_with_scene,
)

LOAD_CASES = ("Gravity", "Wind")
SOLVER_OPTIONS = {"line_segments": 1}
VOLUME_EXPORT = None
ARTIFACT_DIR = Path(__file__).resolve().parent / "evidence"

#: The visual exaggeration for the deformed shape. A hall this size deflects a
#: few millimetres under gravity, which is invisible at true scale, so the scene
#: says how far it is scaled rather than letting the number pass unremarked.
GRAVITY_VISUAL_SCALE = 200.0
WIND_VISUAL_SCALE = 4.0


def summarise(model, runs) -> None:
    """Print what Code_Aster actually computed.

    Von Mises is deliberately absent: Tuba requests Code_Aster's ``SIEQ``
    equivalent-stress field only for models containing pipe elements, and this is
    a pure structural frame. An absent number means "not computed", never zero.
    """
    for case, run in runs.items():
        state = run.result_state
        displacements = state.node_displacements
        if not displacements:
            print(f"{case}: no displacement results")
            continue
        values = np.array([np.asarray(v, dtype=float) for v in displacements.values()])
        magnitude = np.linalg.norm(values, axis=1)
        worst = list(displacements.keys())[int(magnitude.argmax())]
        reactions = state.node_reactions
        peak = 0.0
        if reactions:
            peak = float(np.abs(np.array(
                [np.asarray(v, dtype=float) for v in reactions.values()]
            )).max())
        print(f"{case}: {len(displacements)} nodes solved, "
              f"max |u| {magnitude.max() * 1000:.2f} mm at {worst} "
              f"{np.round(model.nodes[worst].coords, 1)}, "
              f"max |reaction| {peak / 1000:.1f} kN")
    print("von Mises stress: not computed (this model has no pipe elements)")


def build_review(namespace, output, *, artifact_dir=None, force=False):
    model = namespace["model"]
    if artifact_dir is None:
        runs = solve_project(
            load_project(Path(namespace["__file__"]).parent), namespace, force=force
        ).runs
    else:
        runs = {
            case: import_code_aster_artifacts(model=model, work_dir=Path(artifact_dir) / case)
            for case in LOAD_CASES
        }
    for run in runs.values():
        run.validate_for_publication(model)

    root = Path(output).resolve() / "review_scene"
    staged = stage_runs(runs, root)
    scales = {"Gravity": GRAVITY_VISUAL_SCALE, "Wind": WIND_VISUAL_SCALE}
    states = [
        create_visual_deformed_geometry_state(
            model=model, result_state=run.result_state,
            visual_scale=scales.get(run.result_state.load_case, 1.0),
        )
        for run in staged.values()
    ]
    solved_at = staged["Gravity"].result_state.metadata["solve_attestation"]["solved_at"]

    scene = build_visualization_scene(SceneRequest(
        model,
        analysis_runs=list(staged.values()),
        geometry_states=states,
        options=SceneBuildOptions(include_loads=True),
        scene_id="scene:steel_portal_frame_hall",
        created_at=solved_at,
    ))
    add_scene_label(
        scene,
        "7 cambered bowstring portal frames - gravity and wind",
        [0.0, 18.0, 15.0], label_id="hall", height=2.2,
    )
    review = build_engineering_review(
        model, analysis_runs=list(staged.values()),
        package_id="review:steel_portal_frame", created_at=solved_at,
    )
    write_engineering_review_with_scene(
        review, root, scene=scene,
        title=model.project_name, source=namespace["__file__"],
    )
    summarise(model, runs)
    return root


if __name__ == "__main__":
    import runpy

    namespace = runpy.run_path(str(Path(__file__).parent / "model.py"), run_name="__main__")
    build_review({**namespace, "__file__": str(Path(__file__).parent / "model.py")},
                 Path(__file__).parent / ".build")
